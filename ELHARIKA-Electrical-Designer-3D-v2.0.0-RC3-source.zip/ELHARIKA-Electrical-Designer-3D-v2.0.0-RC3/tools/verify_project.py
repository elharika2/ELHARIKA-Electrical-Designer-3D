from pathlib import Path
import re, sys, zipfile

root = Path(__file__).resolve().parents[1]
kotlin = list(root.rglob("*.kt"))
errors = []

def balance(text, filename):
    stack=[]
    pairs={')':'(',']':'[','}':'{'}
    in_str=False
    esc=False
    for i,ch in enumerate(text):
        if ch=='"' and not esc:
            in_str=not in_str
        if not in_str:
            if ch in '([{':
                stack.append(ch)
            elif ch in ')]}':
                if not stack or stack[-1] != pairs[ch]:
                    errors.append(f"{filename}: bracket mismatch near {i}")
                    return
                stack.pop()
        esc = ch=='\\' and not esc
        if ch!='\\':
            esc=False
    if stack:
        errors.append(f"{filename}: unclosed brackets")

for f in kotlin:
    balance(f.read_text(encoding="utf-8"), f.name)

models=(root/"app/src/main/java/com/elharika/electricaldesigner3d/Models.kt").read_text(encoding="utf-8")
vm=(root/"app/src/main/java/com/elharika/electricaldesigner3d/EditorViewModel.kt").read_text(encoding="utf-8")
store=(root/"app/src/main/java/com/elharika/electricaldesigner3d/ProjectStore.kt").read_text(encoding="utf-8")
app=(root/"app/src/main/java/com/elharika/electricaldesigner3d/App.kt").read_text(encoding="utf-8")
real3d=(root/"app/src/main/java/com/elharika/electricaldesigner3d/Real3DView.kt").read_text(encoding="utf-8")
scene_builder=(root/"app/src/main/java/com/elharika/electricaldesigner3d/Real3DSceneBuilder.kt").read_text(encoding="utf-8")
gradle=(root/"app/build.gradle.kts").read_text(encoding="utf-8")

required = {
    "two-way switch enum": "TWO_WAY_SWITCH" in models,
    "contactor enum": "CONTACTOR" in models,
    "simulation state": "switchPosition" in models and "coilEnergized" in models,
    "simulation engine": "fun runSimulation()" in vm,
    "wiring validation": "fun wiringIssues()" in vm,
    "wire-link persistence": '"wireLinks"' in store,
    "simulation persistence": '"simulationStates"' in store,
    "simulation UI": 'Text("SIMULATION"' in app,
    "real 3D engine dependency": 'io.github.sceneview:sceneview:2.3.0' in gradle,
    "real 3D renderer": "fun Real3DView" in real3d and "Scene(" in real3d,
    "2D to 3D bridge": "object Real3DSceneBuilder" in scene_builder,
    "real wall openings": "openingsByWall" in scene_builder and "addWallPiece" in scene_builder,
}
for name, ok in required.items():
    if not ok:
        errors.append(f"missing: {name}")

if errors:
    print("VERIFY FAILED")
    for e in errors:
        print("-", e)
    sys.exit(1)

print(f"VERIFY OK: {len(kotlin)} Kotlin files checked")
for name in required:
    print("-", name)
