from pathlib import Path
import json, struct, sys
root=Path(__file__).resolve().parents[1]
manifest_path=root/'app/src/main/assets/models/electrical/asset_manifest.json'
manifest=json.loads(manifest_path.read_text())
asset_root=manifest_path.parent
missing=[]; invalid=[]; present=[]
for a in manifest['assets']:
    p=asset_root/a['file']
    if not p.exists():
        missing.append(a['file']); continue
    data=p.read_bytes()[:12]
    if len(data)<12 or data[:4]!=b'glTF':
        invalid.append(a['file']); continue
    version=struct.unpack('<I',data[4:8])[0]
    if version!=2: invalid.append(a['file']); continue
    present.append(a['file'])
print(f'Electrical GLB assets: {len(present)}/{len(manifest["assets"])} present')
for n in present: print(' OK ',n)
for n in missing: print(' MISS',n)
for n in invalid: print(' BAD ',n)
# Missing assets are allowed because runtime fallback is intentional; invalid bundled GLBs are not.
sys.exit(1 if invalid else 0)
