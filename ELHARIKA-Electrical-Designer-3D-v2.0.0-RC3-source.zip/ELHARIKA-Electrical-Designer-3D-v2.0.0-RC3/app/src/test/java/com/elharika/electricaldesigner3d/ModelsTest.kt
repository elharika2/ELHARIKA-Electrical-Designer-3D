package com.elharika.electricaldesigner3d

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelsTest {
    @Test
    fun pathLengthUsesProjectScale() {
        val project = ElectricalProject(pixelsPerMeter = 100f)
        val length = project.pathMeters(listOf(Point2(0f,0f), Point2(300f,400f)))
        assertEquals(5f, length, 0.001f)
    }

    @Test
    fun cableLengthIncludesVerticalRun() {
        val project = ElectricalProject(pixelsPerMeter = 100f)
        val cable = DesignElement(
            id = 1L,
            kind = ElementKind.CABLE,
            start = Point2(0f,0f),
            end = Point2(100f,0f),
            path = listOf(Point2(0f,0f), Point2(100f,0f)),
            verticalMeters = 2f
        )
        assertEquals(3f, project.cableMeters(cable), 0.001f)
    }

    @Test
    fun simulationDefaultsAreSafe() {
        val state = SimulationState(elementId = 12L)
        assertTrue(!state.switchClosed)
        assertEquals(0, state.switchPosition)
        assertTrue(!state.coilEnergized)
        assertEquals("NONE", state.fault)
    }

    @Test
    fun cableDefaultsContainProtectiveEarth() {
        val cable = DesignElement(1L, ElementKind.CABLE, Point2(0f,0f))
        assertEquals(3, cable.conductorCount)
        assertTrue(cable.hasProtectiveEarth)
        assertEquals(2.5f, cable.conductorSectionMm2, 0.001f)
    }
    @Test(expected = IllegalArgumentException::class)
    fun zeroGridCannotFreezeRendering() { ElectricalProject(gridMeters=0f) }
    @Test(expected = IllegalArgumentException::class)
    fun invalidScaleIsRejected() { ElectricalProject(pixelsPerMeter=Float.NaN) }
    @Test fun csvPreservesQuotesCommasAndBlocksFormulas() {
        assertEquals("\"Living, room\",\"A\"\"B\",\"'=1+1\"",csvRow(listOf("Living, room","A\"B","=1+1")))
    }
}
