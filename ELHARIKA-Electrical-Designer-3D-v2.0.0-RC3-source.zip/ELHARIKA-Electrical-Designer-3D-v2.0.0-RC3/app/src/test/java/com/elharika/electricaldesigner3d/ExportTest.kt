package com.elharika.electricaldesigner3d

import android.app.Application
import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.io.File
import java.util.Locale
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.shadows.ShadowContentResolver

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[34])
class ExportTest {
    private lateinit var vm: EditorViewModel
    private lateinit var provider: DownloadsProvider
    @Before fun setup() {
        val app=RuntimeEnvironment.getApplication()
        app.getSharedPreferences("electrical_designer",0).edit().clear().commit()
        vm=EditorViewModel(app)
        provider=DownloadsProvider(File(app.cacheDir,"exports").apply{mkdirs()})
        ShadowContentResolver.registerProviderInternal(MediaStore.AUTHORITY,provider)
    }
    @Test fun csvWorksWithFrenchLocaleAndQuotedCircuitNames() {
        val old=Locale.getDefault()
        try {
            Locale.setDefault(Locale.FRANCE)
            vm.project.value=ElectricalProject(circuits=listOf(Circuit(1,"Living, room")))
            vm.exportCsv()
            assertTrue(vm.statusMessage.value,vm.statusMessage.value.startsWith("CSV exported"))
            val csv=provider.lastFile!!.readText()
            assertTrue(csv.contains("\"Living, room\"")); assertTrue(csv.contains("\"0.00\""))
        } finally {Locale.setDefault(old)}
    }
    class DownloadsProvider(private val directory:File):ContentProvider() {
        var lastFile:File?=null
        override fun onCreate()=true
        override fun insert(uri:Uri,values:ContentValues?):Uri {
            lastFile=File(directory,values!!.getAsString(MediaStore.Downloads.DISPLAY_NAME))
            val result=uri.buildUpon().appendPath("1").build()
            val resolver=RuntimeEnvironment.getApplication().contentResolver
            org.robolectric.Shadows.shadowOf(resolver).registerOutputStream(result,java.io.FileOutputStream(lastFile!!))
            return result
        }
        override fun openFile(uri:Uri,mode:String):ParcelFileDescriptor = ParcelFileDescriptor.open(lastFile!!,ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE or ParcelFileDescriptor.MODE_READ_WRITE)
        override fun getType(uri:Uri):String?=null
        override fun query(uri:Uri,projection:Array<out String>?,selection:String?,selectionArgs:Array<out String>?,sortOrder:String?):Cursor?=null
        override fun update(uri:Uri,values:ContentValues?,selection:String?,selectionArgs:Array<out String>?)=0
        override fun delete(uri:Uri,selection:String?,selectionArgs:Array<out String>?)=0
    }
}
