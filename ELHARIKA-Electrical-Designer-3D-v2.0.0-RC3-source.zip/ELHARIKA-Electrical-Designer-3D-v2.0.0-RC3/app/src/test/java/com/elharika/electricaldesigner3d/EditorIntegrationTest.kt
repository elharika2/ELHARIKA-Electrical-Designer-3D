package com.elharika.electricaldesigner3d

import android.app.Application
import androidx.compose.ui.geometry.Offset
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class EditorIntegrationTest {
    private lateinit var app: Application
    private lateinit var vm: EditorViewModel
    private fun element(id: Long, kind: ElementKind) = DesignElement(id, kind, Point2(id * 100f, 100f), circuitId = 1L)
    @Before fun setup() {
        app = RuntimeEnvironment.getApplication()
        app.getSharedPreferences("electrical_designer", 0).edit().clear().commit()
        vm = EditorViewModel(app)
    }
    private fun circuit(switchKind: ElementKind? = null) {
        val panel = element(1, ElementKind.PANEL)
        val light = element(3, ElementKind.LIGHT)
        val middle = switchKind?.let { element(2, it) }
        val elements = listOfNotNull(panel, middle, light)
        val edges = if(middle == null) listOf(1L to 3L) else listOf(1L to 2L, 2L to 3L)
        val cables = edges.mapIndexed { i, edge -> DesignElement(10L+i, ElementKind.CABLE, Point2(0f,0f), Point2(100f,0f), circuitId=1, connectedElementIds=listOf(edge.first, edge.second)) }
        vm.project.value = ElectricalProject(elements = elements + cables)
        vm.rebuildTerminalNetwork()
    }
    @Test fun mainActivityCreatesWithoutCrash() {
        Robolectric.buildActivity(MainActivity::class.java).setup().use { controller ->
            assertNotNull(controller.get().window.decorView)
        }
    }
    @Test fun directLightTurnsOn() { circuit(); vm.runSimulation(); assertTrue(3L in vm.lastSimulation.value.litLightIds) }
    @Test fun missingNeutralKeepsLightOff() {
        circuit(); vm.project.value=vm.project.value.copy(wireLinks=vm.project.value.wireLinks.filter{it.role!="N"})
        vm.runSimulation(); assertTrue(vm.lastSimulation.value.litLightIds.isEmpty())
    }
    @Test fun openSwitchBlocksLightAndClosedPasses() {
        circuit(ElementKind.SWITCH); vm.runSimulation(); assertTrue(vm.lastSimulation.value.litLightIds.isEmpty())
        vm.toggleSwitch(2); vm.runSimulation(); assertTrue(3L in vm.lastSimulation.value.litLightIds)
    }
    @Test fun openCableBlocksLight() { circuit(); vm.setFault(10,"OPEN"); vm.runSimulation(); assertTrue(vm.lastSimulation.value.litLightIds.isEmpty()) }
    @Test fun openFaultBlocksLight() { circuit(); vm.setFault(3,"OPEN"); vm.runSimulation(); assertTrue(vm.lastSimulation.value.litLightIds.isEmpty()) }
    @Test fun shortTripsCircuit() { circuit(); vm.setFault(3,"SHORT_LN"); vm.runSimulation(); assertTrue(1L in vm.lastSimulation.value.trippedCircuitIds); assertTrue(vm.lastSimulation.value.litLightIds.isEmpty()) }
    @Test fun clearingFaultRestoresLight() { circuit(); vm.setFault(3,"SHORT_LN"); vm.clearSimulationFaults(); vm.runSimulation(); assertTrue(3L in vm.lastSimulation.value.litLightIds) }
    @Test fun manualContactorCoilControlsLight() {
        circuit(ElementKind.CONTACTOR); vm.runSimulation(); assertTrue(vm.lastSimulation.value.litLightIds.isEmpty())
        vm.toggleContactorCoil(2); vm.runSimulation(); assertTrue(3L in vm.lastSimulation.value.litLightIds)
    }
    @Test fun unpairedTwoWayIsOpen() { circuit(ElementKind.TWO_WAY_SWITCH); vm.runSimulation(); assertTrue(vm.lastSimulation.value.litLightIds.isEmpty()); assertTrue(vm.wiringIssues().any{it.message.contains("not paired")}) }
    @Test fun pairedTwoWayTruthTable() {
        circuit(ElementKind.TWO_WAY_SWITCH)
        vm.project.value=vm.project.value.copy(elements=vm.project.value.elements.map{if(it.id==2L)it.copy(pairedElementId=4L)else it}+element(4,ElementKind.TWO_WAY_SWITCH).copy(pairedElementId=2L))
        for(a in 0..1) for(b in 0..1) {
            vm.project.value=vm.project.value.copy(simulationStates=listOf(SimulationState(2,switchPosition=a),SimulationState(4,switchPosition=b)))
            vm.runSimulation(); assertEquals(a==b,3L in vm.lastSimulation.value.litLightIds)
        }
    }
    @Test fun missingAllEarthLinksIsReported() {
        circuit(); vm.project.value=vm.project.value.copy(elements=vm.project.value.elements.map{if(it.id==3L)it.copy(kind=ElementKind.SOCKET)else it},wireLinks=vm.project.value.wireLinks.filter{it.role!="PE"})
        assertTrue(vm.wiringIssues().any{it.message.contains("missing PE")})
    }
    @Test fun reassignmentClearsFormerPair() {
        vm.project.value=ElectricalProject(elements=(1L..3L).map{element(it,ElementKind.TWO_WAY_SWITCH)})
        vm.selectedId.value=1; vm.pairSelectedTwoWayWith(2); vm.pairSelectedTwoWayWith(3)
        assertNull(vm.project.value.elements.first{it.id==2L}.pairedElementId)
        assertEquals(1L,vm.project.value.elements.first{it.id==3L}.pairedElementId)
    }
    @Test fun unpairClearsBothSides() {
        vm.project.value=ElectricalProject(elements=(1L..2L).map{element(it,ElementKind.TWO_WAY_SWITCH)})
        vm.selectedId.value=1; vm.pairSelectedTwoWayWith(2); vm.pairSelectedTwoWayWith(null)
        assertTrue(vm.project.value.elements.all{it.pairedElementId==null})
    }
    @Test fun persistenceRoundTripKeepsElectricalData() {
        circuit(ElementKind.SWITCH); vm.toggleSwitch(2)
        assertEquals(vm.project.value,ProjectStore(app).load())
    }
    @Test fun corruptStoredJsonDoesNotCrash() {
        app.getSharedPreferences("electrical_designer",0).edit().putString("active_project","broken{").commit()
        assertNull(ProjectStore(app).load())
    }
    @Test fun undoRedoRestoresProject() {
        vm.setTool(EditorTool.SOCKET); vm.onInputDown(Offset(100f,100f),1f,false)
        assertEquals(1,vm.project.value.elements.size); vm.undo(); assertTrue(vm.project.value.elements.isEmpty()); vm.redo(); assertEquals(1,vm.project.value.elements.size)
    }
    @Test fun cancelledWallIsNotCommitted() {
        vm.setTool(EditorTool.WALL); vm.onInputDown(Offset(100f,100f),1f,false); vm.onInputMove(Offset(400f,100f),1f); vm.cancelInput()
        assertTrue(vm.project.value.elements.isEmpty()); assertNull(vm.previewStart.value)
    }
    @Test fun duplicatedFloorRemapsPairReferences() {
        vm.project.value=ElectricalProject(elements=listOf(element(1,ElementKind.TWO_WAY_SWITCH).copy(pairedElementId=2),element(2,ElementKind.TWO_WAY_SWITCH).copy(pairedElementId=1)))
        vm.duplicateActiveFloor(); val copies=vm.project.value.activeElements()
        assertEquals(2,copies.size); assertTrue(copies.all{e->copies.any{it.id==e.pairedElementId}})
    }
    @Test fun deletingFloorRemovesElectricalLinks() {
        circuit(); vm.project.value=vm.project.value.copy(floors=listOf(BuildingFloor(1,"Ground"),BuildingFloor(2,"First")))
        vm.deleteActiveFloor(); assertTrue(vm.project.value.wireLinks.isEmpty())
    }
    @Test fun billOfMaterialsCountsNewDevices() {
        vm.project.value=ElectricalProject(elements=listOf(element(1,ElementKind.CONTACTOR),element(2,ElementKind.TWO_WAY_SWITCH)))
        assertEquals("1",vm.bom().first{it.name=="Contacteurs"}.quantity); assertEquals("1",vm.bom().first{it.name=="Va-et-vient"}.quantity)
    }
}
