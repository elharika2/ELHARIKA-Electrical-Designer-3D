package com.elharika.electricaldesigner3d

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Real3DSceneBuilderTest {

    @Test
    fun wallUsesRealMetricLength() {
        val project = ElectricalProject(
            pixelsPerMeter = 100f,
            elements = listOf(
                DesignElement(
                    id = 1L,
                    kind = ElementKind.WALL,
                    start = Point2(0f, 0f),
                    end = Point2(400f, 0f),
                    wallThicknessMeters = 0.15f
                )
            )
        )
        val scene = Real3DSceneBuilder.build(project)
        val wall = scene.primitives.filterIsInstance<Real3DPrimitive.Box>()
            .first { it.category == Real3DCategory.WALL }
        assertEquals(4f, wall.size.x, 0.001f)
        assertEquals(0.15f, wall.size.z, 0.001f)
        assertEquals(project.ceilingHeightMeters, wall.size.y, 0.001f)
    }

    @Test
    fun hostedDoorCreatesActualOpeningInWallGeometry() {
        val wall = DesignElement(
            id = 10L,
            kind = ElementKind.WALL,
            start = Point2(0f, 0f),
            end = Point2(400f, 0f),
            wallThicknessMeters = 0.15f
        )
        val door = DesignElement(
            id = 11L,
            kind = ElementKind.DOOR,
            start = Point2(150f, 0f),
            end = Point2(250f, 0f),
            hostWallId = 10L
        )
        val project = ElectricalProject(pixelsPerMeter = 100f, elements = listOf(wall, door))
        val pieces = Real3DSceneBuilder.build(project).primitives
            .filterIsInstance<Real3DPrimitive.Box>()
            .filter { it.category == Real3DCategory.WALL }

        // Left full wall + lintel over door + right full wall.
        assertTrue(pieces.size >= 3)
        val fullHeightPieces = pieces.filter { kotlin.math.abs(it.size.y - project.ceilingHeightMeters) < 0.001f }
        assertEquals(2, fullHeightPieces.size)
        assertTrue(pieces.any { it.center.y > 2.1f && it.size.y < project.ceilingHeightMeters })
    }

    @Test
    fun floorElevationIsPreservedAcrossMultipleFloors() {
        val ground = BuildingFloor(1L, "Ground", 0f)
        val upper = BuildingFloor(2L, "Upper", 3f)
        val room1 = DesignElement(1L, ElementKind.ROOM, Point2(0f,0f), Point2(200f,200f), floorId = 1L)
        val room2 = DesignElement(2L, ElementKind.ROOM, Point2(0f,0f), Point2(200f,200f), floorId = 2L)
        val project = ElectricalProject(
            pixelsPerMeter = 100f,
            floors = listOf(ground, upper),
            activeFloorId = 1L,
            elements = listOf(room1, room2)
        )
        val floors = Real3DSceneBuilder.build(project).primitives
            .filterIsInstance<Real3DPrimitive.Box>()
            .filter { it.category == Real3DCategory.FLOOR }
            .sortedBy { it.center.y }
        assertEquals(2, floors.size)
        assertEquals(3f, floors[1].center.y - floors[0].center.y, 0.001f)
    }

    @Test
    fun conduitUsesConfiguredDiameter() {
        val cable = DesignElement(
            id = 4L,
            kind = ElementKind.CABLE,
            start = Point2(0f,0f),
            end = Point2(200f,0f),
            path = listOf(Point2(0f,0f), Point2(200f,0f)),
            conduitDiameterMm = 20f,
            circuitId = 1L
        )
        val project = ElectricalProject(pixelsPerMeter = 100f, elements = listOf(cable))
        val tube = Real3DSceneBuilder.build(project).primitives
            .filterIsInstance<Real3DPrimitive.Tube>()
            .first { it.category == Real3DCategory.CONDUIT }
        assertEquals(0.01f, tube.radiusMeters, 0.0001f)
        assertEquals(2f, tube.end.x - tube.start.x, 0.001f)
    }


    @Test
    fun roundedConduitPathAddsBendSegments() {
        val raw=listOf(
            Real3DVec3(0f,1f,0f),
            Real3DVec3(1f,1f,0f),
            Real3DVec3(1f,1f,1f)
        )
        val rounded=Real3DSceneBuilder.roundedConduitPath(raw,0.08f,6)
        assertTrue(rounded.size > raw.size)
        assertEquals(raw.first(),rounded.first())
        assertEquals(raw.last(),rounded.last())
        assertTrue(rounded.none { it.x==1f && it.z==0f })
    }

    @Test
    fun panelBuildsDinRailsBreakersAndTerminals() {
        val panel=DesignElement(901,ElementKind.PANEL,Point2(100f,100f),heightMeters=1.4f)
        val p=ElectricalProject(elements=listOf(panel))
        val scene=Real3DSceneBuilder.build(p)
        assertEquals(2,scene.primitives.count { it.category==Real3DCategory.DIN_RAIL })
        assertEquals(12,scene.primitives.count { it.category==Real3DCategory.BREAKER })
        assertEquals(2,scene.primitives.count { it.category==Real3DCategory.TERMINAL })
    }

    @Test
    fun conduitBendCreatesFittings() {
        val cable=DesignElement(
            id=777,kind=ElementKind.CABLE,start=Point2(0f,0f),
            path=listOf(Point2(0f,0f),Point2(100f,0f),Point2(100f,100f)),
            circuitId=1L,conduitDiameterMm=20f,bendRadiusMm=80f
        )
        val p=ElectricalProject(elements=listOf(cable))
        val scene=Real3DSceneBuilder.build(p)
        assertTrue(scene.primitives.any { it.category==Real3DCategory.FITTING })
        assertTrue(scene.primitives.count { it.category==Real3DCategory.CONDUIT } > 2)
    }

    @Test
    fun circuitPaletteIsStableAndDifferentAcrossCircuits() {
        assertEquals("circuit-blue", Real3DSceneBuilder.circuitMaterialKey(1L))
        assertEquals(Real3DSceneBuilder.circuitMaterialKey(7L), Real3DSceneBuilder.circuitMaterialKey(1L))
        assertTrue(Real3DSceneBuilder.circuitMaterialKey(1L) != Real3DSceneBuilder.circuitMaterialKey(2L))
    }

    @Test
    fun longCeilingRunCreatesSupportsAndCouplers() {
        val cable=DesignElement(
            id=880,kind=ElementKind.CABLE,start=Point2(0f,0f),end=Point2(500f,0f),
            path=listOf(Point2(0f,0f),Point2(500f,0f)),circuitId=2L,route=CableRoute.CEILING,conduitDiameterMm=20f
        )
        val scene=Real3DSceneBuilder.build(ElectricalProject(pixelsPerMeter=100f,elements=listOf(cable)))
        assertTrue(scene.primitives.any { it.category==Real3DCategory.SUPPORT })
        assertTrue(scene.primitives.any { it.id.startsWith("coupler-") })
    }

    @Test
    fun junctionBoxHasScrewsAndEntryGlands() {
        val wall=DesignElement(1,ElementKind.WALL,Point2(0f,0f),Point2(300f,0f))
        val box=DesignElement(2,ElementKind.JUNCTION_BOX,Point2(150f,0f),hostWallId=1L,circuitId=1L,boxDiameterMm=80f,boxDepthMm=50f,heightMeters=1.4f)
        val scene=Real3DSceneBuilder.build(ElectricalProject(pixelsPerMeter=100f,elements=listOf(wall,box)))
        assertEquals(4,scene.primitives.count { it.category==Real3DCategory.SCREW })
        assertEquals(2,scene.primitives.count { it.category==Real3DCategory.GLAND })
    }


    @Test
    fun bundleOffsetCentersParallelConduits() {
        assertEquals(-0.03f, Real3DSceneBuilder.bundleOffset(0,3,0.03f), 0.0001f)
        assertEquals(0f, Real3DSceneBuilder.bundleOffset(1,3,0.03f), 0.0001f)
        assertEquals(0.03f, Real3DSceneBuilder.bundleOffset(2,3,0.03f), 0.0001f)
    }

    @Test
    fun crossingRoutesCreateAutomaticJunctionHardware() {
        val a=DesignElement(
            id=1001,kind=ElementKind.CABLE,start=Point2(0f,100f),end=Point2(200f,100f),
            path=listOf(Point2(0f,100f),Point2(200f,100f)),circuitId=1L,route=CableRoute.WALL
        )
        val b=DesignElement(
            id=1002,kind=ElementKind.CABLE,start=Point2(100f,0f),end=Point2(100f,200f),
            path=listOf(Point2(100f,0f),Point2(100f,200f)),circuitId=2L,route=CableRoute.WALL
        )
        val scene=Real3DSceneBuilder.build(ElectricalProject(pixelsPerMeter=100f,elements=listOf(a,b)))
        assertTrue(scene.primitives.any { it.id.startsWith("auto-junction-") && it.category==Real3DCategory.DEVICE_BOX })
        assertTrue(scene.primitives.count { it.id.startsWith("auto-junction-gland-") } >= 4)
    }

    @Test
    fun endpointMeetingIsDetectedAsBranch() {
        val hit=Real3DSceneBuilder.segmentIntersectionXZ(
            Real3DVec3(0f,1f,0f), Real3DVec3(2f,1f,0f),
            Real3DVec3(1f,1f,-1f), Real3DVec3(1f,1f,0f)
        )
        assertTrue(hit != null)
        assertTrue(hit!!.second)
    }

    @Test
    fun verticalDropGetsTopAndBottomFittings() {
        val device=DesignElement(
            id=2002,kind=ElementKind.SOCKET,start=Point2(200f,0f),heightMeters=0.30f,circuitId=1L
        )
        val cable=DesignElement(
            id=2001,kind=ElementKind.CABLE,start=Point2(0f,0f),end=Point2(200f,0f),
            path=listOf(Point2(0f,0f),Point2(200f,0f)),circuitId=1L,route=CableRoute.CEILING,
            connectedElementIds=listOf(device.id)
        )
        val scene=Real3DSceneBuilder.build(ElectricalProject(pixelsPerMeter=100f,elements=listOf(cable,device)))
        assertTrue(scene.primitives.any { it.id.startsWith("drop-elbow-") })
        assertTrue(scene.primitives.any { it.id.startsWith("drop-gland-") })
    }



    @Test
    fun electricalAssetCatalogMapsCriticalComponents() {
        assertEquals("models/electrical/junction_box.glb", ElectricalAssetCatalog["junction-box"]!!.assetPath)
        assertEquals("models/electrical/socket_eu.glb", ElectricalAssetCatalog["socket"]!!.assetPath)
        assertTrue(ElectricalAssetCatalog.requiredPaths().contains("models/electrical/distribution_panel.glb"))
    }

    @Test
    fun realisticPrimitivesCarryAssetKeysWithoutRemovingFallbackGeometry() {
        val socket=DesignElement(id=3101,kind=ElementKind.SOCKET,start=Point2(100f,100f),circuitId=1L)
        val panel=DesignElement(id=3102,kind=ElementKind.PANEL,start=Point2(0f,0f),heightMeters=1.4f)
        val scene=Real3DSceneBuilder.build(ElectricalProject(elements=listOf(socket,panel)))
        val socketNode=scene.primitives.filterIsInstance<Real3DPrimitive.Box>().first{it.id=="device-3101"}
        val panelNode=scene.primitives.filterIsInstance<Real3DPrimitive.Box>().first{it.id=="panel-3102"}
        assertEquals("socket", socketNode.assetKey)
        assertEquals("panel", panelNode.assetKey)
        assertTrue(socketNode.size.x > 0f)
        assertTrue(panelNode.size.y > 0f)
    }



    @Test
    fun liveCircuitMaterialUsesSimulationState() {
        val energized = Real3DOptions(
            simulationHighlight = true,
            energizedCableIds = setOf(5L)
        )
        assertEquals("energized-orange", Real3DSceneBuilder.liveCircuitMaterial(1L,5L,energized))

        val tripped = Real3DOptions(
            simulationHighlight = true,
            energizedCableIds = setOf(5L),
            trippedCircuitIds = setOf(1L)
        )
        assertEquals("trip-red", Real3DSceneBuilder.liveCircuitMaterial(1L,5L,tripped))
    }

    @Test
    fun conduitEndpointsCreatePenetrationSleeves() {
        val cable=DesignElement(
            id=3001,kind=ElementKind.CABLE,start=Point2(0f,0f),end=Point2(200f,0f),
            path=listOf(Point2(0f,0f),Point2(200f,0f)),circuitId=1L,route=CableRoute.WALL
        )
        val scene=Real3DSceneBuilder.build(ElectricalProject(pixelsPerMeter=100f,elements=listOf(cable)))
        assertEquals(2,scene.primitives.count { it.id.startsWith("penetration-") })
    }

    @Test
    fun multipleCeilingConduitsCreateSharedBundleRails() {
        val a=DesignElement(
            id=3101,kind=ElementKind.CABLE,start=Point2(0f,0f),end=Point2(500f,0f),
            path=listOf(Point2(0f,0f),Point2(500f,0f)),circuitId=1L,route=CableRoute.CEILING
        )
        val b=DesignElement(
            id=3102,kind=ElementKind.CABLE,start=Point2(0f,10f),end=Point2(500f,10f),
            path=listOf(Point2(0f,10f),Point2(500f,10f)),circuitId=2L,route=CableRoute.CEILING
        )
        val scene=Real3DSceneBuilder.build(ElectricalProject(pixelsPerMeter=100f,elements=listOf(a,b)))
        assertTrue(scene.primitives.any { it.id.startsWith("bundle-rail-") && it.category==Real3DCategory.SUPPORT })
    }



    @Test
    fun assetRotationFollowsHorizontalAndVerticalSegments() {
        val horizontal=Real3DSceneBuilder.zAxisAssetRotation(
            Real3DVec3(0f,0f,0f), Real3DVec3(1f,0f,0f)
        )
        assertTrue(kotlin.math.abs(horizontal.y) > 80f)

        val vertical=Real3DSceneBuilder.zAxisAssetRotation(
            Real3DVec3(0f,0f,0f), Real3DVec3(0f,1f,0f)
        )
        assertTrue(kotlin.math.abs(vertical.x) > 80f)
    }

    @Test
    fun tBranchUsesThreeEntryGlands() {
        val a=DesignElement(
            id=4101,kind=ElementKind.CABLE,start=Point2(0f,100f),end=Point2(200f,100f),
            path=listOf(Point2(0f,100f),Point2(200f,100f)),circuitId=1L,route=CableRoute.WALL
        )
        val b=DesignElement(
            id=4102,kind=ElementKind.CABLE,start=Point2(100f,0f),end=Point2(100f,100f),
            path=listOf(Point2(100f,0f),Point2(100f,100f)),circuitId=2L,route=CableRoute.WALL
        )
        val scene=Real3DSceneBuilder.build(ElectricalProject(pixelsPerMeter=100f,elements=listOf(a,b)))
        assertTrue(scene.primitives.any { it.id.startsWith("auto-junction-") })
        assertEquals(3,scene.primitives.count { it.id.startsWith("auto-junction-gland-") })
    }



    @Test
    fun connectedSocketGetsCableEntryGland() {
        val socket=DesignElement(
            id=5102,kind=ElementKind.SOCKET,start=Point2(200f,0f),heightMeters=0.30f,circuitId=1L
        )
        val cable=DesignElement(
            id=5101,kind=ElementKind.CABLE,start=Point2(0f,0f),end=Point2(200f,0f),
            path=listOf(Point2(0f,0f),Point2(200f,0f)),circuitId=1L,
            connectedElementIds=listOf(socket.id)
        )
        val scene=Real3DSceneBuilder.build(ElectricalProject(pixelsPerMeter=100f,elements=listOf(cable,socket)))
        assertTrue(scene.primitives.any { it.id=="device-gland-${socket.id}-${cable.id}" })
    }

    @Test
    fun connectedPanelGetsCableEntryGland() {
        val panel=DesignElement(
            id=5202,kind=ElementKind.PANEL,start=Point2(0f,0f),heightMeters=1.4f
        )
        val cable=DesignElement(
            id=5201,kind=ElementKind.CABLE,start=Point2(0f,0f),end=Point2(200f,0f),
            path=listOf(Point2(0f,0f),Point2(200f,0f)),circuitId=1L,
            connectedElementIds=listOf(panel.id)
        )
        val scene=Real3DSceneBuilder.build(ElectricalProject(pixelsPerMeter=100f,elements=listOf(cable,panel)))
        assertTrue(scene.primitives.any { it.id=="panel-gland-${panel.id}-${cable.id}" })
    }



    @Test
    fun performanceQualityCreatesFewerDecorativeDetailsThanUltra() {
        val cable=DesignElement(
            id=6101,kind=ElementKind.CABLE,start=Point2(0f,0f),end=Point2(800f,0f),
            path=listOf(Point2(0f,0f),Point2(800f,0f)),circuitId=1L,route=CableRoute.CEILING
        )
        val project=ElectricalProject(pixelsPerMeter=100f,elements=listOf(cable))
        val performance=Real3DSceneBuilder.build(project,Real3DOptions(quality=Real3DQuality.PERFORMANCE))
        val ultra=Real3DSceneBuilder.build(project,Real3DOptions(quality=Real3DQuality.ULTRA))
        val perfDecor=performance.primitives.count { it.category in setOf(Real3DCategory.SUPPORT,Real3DCategory.FITTING) }
        val ultraDecor=ultra.primitives.count { it.category in setOf(Real3DCategory.SUPPORT,Real3DCategory.FITTING) }
        assertTrue(perfDecor < ultraDecor)
        assertEquals(
            performance.primitives.count { it.category==Real3DCategory.CONDUIT },
            ultra.primitives.count { it.category==Real3DCategory.CONDUIT }
        )
    }



    @Test
    fun hiddenCircuitRemovesOnlyThatElectricalNetwork() {
        val c1=DesignElement(
            id=7001,kind=ElementKind.CABLE,start=Point2(0f,0f),end=Point2(200f,0f),
            path=listOf(Point2(0f,0f),Point2(200f,0f)),circuitId=1L
        )
        val c2=DesignElement(
            id=7002,kind=ElementKind.CABLE,start=Point2(0f,100f),end=Point2(200f,100f),
            path=listOf(Point2(0f,100f),Point2(200f,100f)),circuitId=2L
        )
        val wall=DesignElement(7003,ElementKind.WALL,Point2(0f,0f),Point2(300f,0f))
        val scene=Real3DSceneBuilder.build(
            ElectricalProject(pixelsPerMeter=100f,elements=listOf(wall,c1,c2)),
            Real3DOptions(hiddenCircuitIds=setOf(1L))
        )
        assertTrue(scene.primitives.any { it.category==Real3DCategory.WALL })
        assertTrue(scene.primitives.none { it.circuitId==1L })
        assertTrue(scene.primitives.any { it.circuitId==2L })
    }

}
