package com.elharika.electricaldesigner3d

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private object StudioColors {
    val Bg = Color(0xFF090E14)
    val Header = Color(0xFF0D131C)
    val Panel = Color(0xFF101821)
    val PanelAlt = Color(0xFF151F2B)
    val Workspace = Color(0xFF18212B)
    val Border = Color(0xFF263342)
    val Text = Color(0xFFF2F5F8)
    val Muted = Color(0xFF8E9AAA)
    val Blue = Color(0xFF1677FF)
    val BlueDark = Color(0xFF0D5FD3)
    val Green = Color(0xFF2AC66D)
    val Red = Color(0xFFE7484F)
}

@Composable
fun ProfessionalStudioShell(vm: EditorViewModel) {
    val colors = darkColorScheme(
        primary = StudioColors.Blue,
        onPrimary = Color.White,
        background = StudioColors.Bg,
        surface = StudioColors.Panel,
        surfaceVariant = StudioColors.PanelAlt,
        onBackground = StudioColors.Text,
        onSurface = StudioColors.Text,
        outline = StudioColors.Border
    )
    MaterialTheme(colorScheme = colors) {
        Surface(Modifier.fillMaxSize(), color = StudioColors.Bg) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                StudioTopBar(vm)
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val compact = maxWidth < 1000.dp
                    val leftWidth = if (compact) 205.dp else 250.dp
                    val rightWidth = if (compact) 265.dp else 310.dp
                    Row(Modifier.fillMaxSize()) {
                        ComponentLibraryPanel(vm, Modifier.width(leftWidth).fillMaxHeight())
                        StudioWorkspace(vm, Modifier.weight(1f).fillMaxHeight())
                        OperationsPanel(vm, Modifier.width(rightWidth).fillMaxHeight())
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioTopBar(vm: EditorViewModel) {
    Surface(color = StudioColors.Header, shadowElevation = 5.dp) {
        Row(
            Modifier.fillMaxWidth().height(74.dp).padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                Modifier.size(36.dp).background(StudioColors.Blue, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) { Text("⚡", fontSize = 20.sp) }
            Column(Modifier.widthIn(min = 250.dp)) {
                Text("ELHARIKA Electrical Designer 3D", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("v2.0.0 RC3 • Real 3D Electrical", color = StudioColors.Muted, fontSize = 10.sp)
            }

            Spacer(Modifier.weight(1f))
            TopModeButton("Design", selected = !vm.simulationEnabled.value) { vm.setSimulationEnabled(false) }
            TopModeButton("Simulate", selected = vm.simulationEnabled.value) { vm.setSimulationEnabled(true) }
            TopModeButton("Document", selected = false) { vm.exportPdf() }
            Spacer(Modifier.weight(1f))

            CompactAction("3D", vm.viewMode.value == ViewMode.VIEW_3D) { vm.setViewMode(ViewMode.VIEW_3D) }
            CompactAction("2D", vm.viewMode.value == ViewMode.PLAN_2D) { vm.setViewMode(ViewMode.PLAN_2D) }
            CompactAction("Plans", false) { vm.setTool(EditorTool.SELECT); vm.setViewMode(ViewMode.PLAN_2D) }
            CompactAction("BOM", false) { vm.exportCsv() }
            CompactAction("Démo", false) { vm.loadElectricalShowcase() }
            CompactAction("Export", false) { vm.exportPdf() }
            OutlinedButton(onClick = vm::undo, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)) { Text("Undo", fontSize = 10.sp) }
            OutlinedButton(onClick = vm::redo, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)) { Text("Redo", fontSize = 10.sp) }
        }
    }
}

@Composable
private fun TopModeButton(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) StudioColors.BlueDark else StudioColors.PanelAlt,
        shape = RoundedCornerShape(8.dp),
        border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, StudioColors.Border),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(label, Modifier.padding(horizontal = 18.dp, vertical = 10.dp), fontSize = 11.sp)
    }
}

@Composable
private fun CompactAction(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) StudioColors.BlueDark else Color.Transparent,
        shape = RoundedCornerShape(7.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) StudioColors.Blue else StudioColors.Border),
        modifier = Modifier.clickable(onClick = onClick)
    ) { Text(label, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontSize = 10.sp) }
}

@Composable
private fun ComponentLibraryPanel(vm: EditorViewModel, modifier: Modifier = Modifier) {
    val search = remember { mutableStateOf("") }
    Surface(modifier, color = StudioColors.Panel) {
        Column(Modifier.fillMaxSize().padding(12.dp)) {
            Text("Composants", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = search.value,
                onValueChange = { search.value = it },
                placeholder = { Text("Rechercher...", fontSize = 10.sp) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(fontSize = 10.sp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = StudioColors.PanelAlt,
                    unfocusedContainerColor = StudioColors.PanelAlt,
                    focusedBorderColor = StudioColors.Blue,
                    unfocusedBorderColor = StudioColors.Border
                )
            )
            Spacer(Modifier.height(12.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                LibrarySection(
                    "Gaines & Raccords",
                    listOf(
                        StudioItem("Gaine", EditorTool.CABLE, R.drawable.ui_conduit),
                        StudioItem("Coude 90°", EditorTool.CABLE, R.drawable.ui_elbow),
                        StudioItem("Manchon", EditorTool.CABLE, R.drawable.ui_coupler),
                        StudioItem("T dérivation", EditorTool.CABLE, R.drawable.ui_t_branch),
                        StudioItem("Collier", EditorTool.CABLE, R.drawable.ui_clamp),
                        StudioItem("Traversée", EditorTool.CABLE, R.drawable.ui_coupler)
                    ), vm, search.value
                )
                LibrarySection(
                    "Boîtes & Appareillages",
                    listOf(
                        StudioItem("Boîte dérivation", EditorTool.JUNCTION_BOX, R.drawable.ui_junction_box),
                        StudioItem("Boîte encastrée", EditorTool.JUNCTION_BOX, R.drawable.ui_recessed_box),
                        StudioItem("Prise 16A", EditorTool.SOCKET, R.drawable.ui_socket),
                        StudioItem("Interrupteur", EditorTool.SWITCH, R.drawable.ui_switch),
                        StudioItem("Va-et-vient", EditorTool.TWO_WAY_SWITCH, R.drawable.ui_two_way),
                        StudioItem("Point lumineux", EditorTool.LIGHT, null, "✦")
                    ), vm, search.value
                )
                LibrarySection(
                    "Tableau & Protection",
                    listOf(
                        StudioItem("Tableau", EditorTool.PANEL, R.drawable.ui_panel),
                        StudioItem("Disjoncteur", EditorTool.PANEL, R.drawable.ui_breaker),
                        StudioItem("Contacteur", EditorTool.CONTACTOR, R.drawable.ui_contactor),
                        StudioItem("Rail DIN", EditorTool.PANEL, R.drawable.ui_din_rail),
                        StudioItem("Barre N", EditorTool.PANEL, R.drawable.ui_terminal_n),
                        StudioItem("Barre PE", EditorTool.PANEL, R.drawable.ui_terminal_pe)
                    ), vm, search.value
                )
            }
        }
    }
}

private data class StudioItem(val label: String, val tool: EditorTool, val drawableRes: Int? = null, val glyph: String = "")

@Composable
private fun LibrarySection(title: String, items: List<StudioItem>, vm: EditorViewModel, query: String = "") {
    val visibleItems = if (query.isBlank()) items else items.filter { it.label.contains(query, ignoreCase = true) }
    if (visibleItems.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, color = Color(0xFF9EC6FF), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        visibleItems.chunked(3).forEach { rowItems ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                rowItems.forEach { item ->
                    Surface(
                        modifier = Modifier.weight(1f).height(84.dp).clickable {
                            vm.setTool(item.tool)
                            if (item.tool != EditorTool.SELECT) vm.setViewMode(ViewMode.PLAN_2D)
                        },
                        color = if (vm.tool.value == item.tool) Color(0xFF173B67) else StudioColors.PanelAlt,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StudioColors.Border)
                    ) {
                        Column(
                            Modifier.fillMaxSize().padding(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            if (item.drawableRes != null) {
                                Image(
                                    painter = painterResource(item.drawableRes),
                                    contentDescription = item.label,
                                    modifier = Modifier.size(44.dp),
                                    contentScale = ContentScale.Fit
                                )
                            } else {
                                Text(item.glyph, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(5.dp))
                            Text(item.label, fontSize = 8.sp, lineHeight = 9.sp)
                        }
                    }
                }
                repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun StudioWorkspace(vm: EditorViewModel, modifier: Modifier = Modifier) {
    Box(modifier.background(StudioColors.Workspace).padding(7.dp)) {
        if (vm.viewMode.value == ViewMode.PLAN_2D) {
            PlanEditor(vm)
        } else if (vm.real3DEnabled.value) {
            Real3DView(vm, showControls = false, workspaceBackground = StudioColors.Workspace)
        } else {
            Isometric3DView(vm)
        }

        Surface(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp),
            color = StudioColors.Header.copy(alpha = 0.94f),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, StudioColors.Border)
        ) {
            Row(Modifier.padding(horizontal = 8.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                WorkspaceToggle("Gaines", vm.showConduits3D.value) { vm.setShowConduits3D(!vm.showConduits3D.value) }
                WorkspaceToggle("Fils L/N/PE", vm.showConductors3D.value) { vm.setShowConductors3D(!vm.showConductors3D.value) }
                WorkspaceToggle("Boîtes", vm.showBoxes3D.value) { vm.setShowBoxes3D(!vm.showBoxes3D.value) }
                WorkspaceToggle("Cutaway", vm.cutaway3D.value) { vm.setCutaway3D(!vm.cutaway3D.value) }
            }
        }
    }
}

@Composable
private fun WorkspaceToggle(label: String, selected: Boolean, onClick: () -> Unit) {
    TextButton(onClick = onClick, colors = ButtonDefaults.textButtonColors(contentColor = if (selected) Color(0xFF7CB5FF) else StudioColors.Muted)) {
        Text(label, fontSize = 9.sp)
    }
}

@Composable
private fun OperationsPanel(vm: EditorViewModel, modifier: Modifier = Modifier) {
    val project = vm.project.value
    val loads = remember(project) { vm.circuitLoads() }
    val totalWatts = loads.sumOf { it.watts.toDouble() }.toFloat()
    val totalAmps = loads.sumOf { it.amps.toDouble() }.toFloat()
    val sim = vm.lastSimulation.value

    Surface(modifier, color = StudioColors.Panel) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            RightSection("Couches") {
                project.layers.forEach { layer ->
                    PanelRow(
                        title = layer.name,
                        subtitle = if (layer.locked) "Verrouillée" else "Visible",
                        active = project.activeLayerId == layer.id,
                        onClick = { vm.setActiveLayer(layer.id) },
                        trailing = {
                            Switch(checked = layer.visible, onCheckedChange = { vm.toggleLayerVisibility(layer.id) })
                        }
                    )
                }
                val virtualLayers = listOf(
                    "Gaines" to vm.showConduits3D.value,
                    "Boîtes" to vm.showBoxes3D.value,
                    "Fils L/N/PE" to vm.showConductors3D.value,
                    "Tableau" to true
                )
                virtualLayers.forEach { (name, enabled) ->
                    PanelRow(name, if (enabled) "Affiché" else "Masqué", active = name == "Gaines", onClick = {
                        when (name) {
                            "Gaines" -> vm.setShowConduits3D(!vm.showConduits3D.value)
                            "Boîtes" -> vm.setShowBoxes3D(!vm.showBoxes3D.value)
                            "Fils L/N/PE" -> vm.setShowConductors3D(!vm.showConductors3D.value)
                        }
                    })
                }
            }

            RightSection("Circuits") {
                project.circuits.forEachIndexed { index, circuit ->
                    val dot = listOf(
                        Color(0xFFFFD233), Color(0xFFF04444), Color(0xFF2784FF),
                        Color(0xFF37C86B), Color(0xFFC052F1), Color(0xFFFF8A2A)
                    )[index % 6]
                    Row(
                        Modifier.fillMaxWidth().clickable { vm.setIsolatedCircuit3D(circuit.id) }.padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(11.dp).background(dot, RoundedCornerShape(99.dp)))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(circuit.name, fontSize = 10.sp)
                            Text("${circuit.breaker} • ${circuit.cableSpec}", fontSize = 8.sp, color = StudioColors.Muted)
                        }
                        Switch(
                            checked = circuit.id !in vm.hiddenCircuitIds3D.value,
                            onCheckedChange = { vm.toggleCircuitVisibility3D(circuit.id) }
                        )
                    }
                }
                OutlinedButton(onClick = vm::showAllCircuits3D, modifier = Modifier.fillMaxWidth()) { Text("Afficher tous les circuits", fontSize = 9.sp) }
            }

            RightSection("Simulation") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = if (sim.trippedCircuitIds.isEmpty()) Color(0xFF143A29) else Color(0xFF4A1D21), shape = RoundedCornerShape(8.dp)) {
                        Text(if (sim.trippedCircuitIds.isEmpty()) "● Normal" else "● Défaut", Modifier.padding(horizontal = 8.dp, vertical = 4.dp), color = if (sim.trippedCircuitIds.isEmpty()) StudioColors.Green else StudioColors.Red, fontSize = 9.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Text(if (vm.simulationEnabled.value) "LIVE" else "OFF", color = StudioColors.Muted, fontSize = 9.sp)
                }
                StatLine("Tension", "${project.supplyVoltage.toInt()} V")
                StatLine("Courant total", "${"%.1f".format(totalAmps)} A")
                StatLine("Puissance", "${"%.1f".format(totalWatts / 1000f)} kW")
                Button(onClick = { vm.setSimulationEnabled(!vm.simulationEnabled.value) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (vm.simulationEnabled.value) "Arrêter la simulation" else "Lancer la simulation", fontSize = 9.sp)
                }
            }

            RightSection("Affichage 3D") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Real3DQuality.entries.forEach { quality ->
                        Surface(
                            modifier = Modifier.weight(1f).clickable { vm.setReal3DQuality(quality) },
                            color = if (vm.real3DQuality.value == quality) StudioColors.BlueDark else StudioColors.PanelAlt,
                            shape = RoundedCornerShape(7.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, StudioColors.Border)
                        ) {
                            Text(quality.label, Modifier.padding(vertical = 8.dp), fontSize = 8.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        }
                    }
                }
                ToggleLine("Construction", vm.constructionMode3D.value) { vm.setConstructionMode3D(it) }
                ToggleLine("Toutes les gaines", vm.showConduits3D.value) { vm.setShowConduits3D(it) }
                ToggleLine("Conducteurs", vm.showConductors3D.value) { vm.setShowConductors3D(it) }
                ToggleLine("Cutaway", vm.cutaway3D.value) { vm.setCutaway3D(it) }
            }

            RightSection("Étapes chantier") {
                val stages = listOf("Tableau", "Saignées", "Gaines", "Boîtes", "Fils", "Appareils")
                stages.forEachIndexed { index, stage ->
                    Surface(
                        modifier = Modifier.fillMaxWidth().clickable { vm.setInstallationStage3D(index) },
                        color = if (vm.installationStage3D.intValue == index) Color(0xFF173B67) else Color.Transparent,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("${index + 1}. $stage", Modifier.padding(horizontal = 8.dp, vertical = 6.dp), fontSize = 9.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun RightSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        HorizontalDivider(color = StudioColors.Border)
        content()
    }
}

@Composable
private fun PanelRow(
    title: String,
    subtitle: String,
    active: Boolean,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        color = if (active) Color(0xFF12335A) else Color.Transparent,
        shape = RoundedCornerShape(6.dp)
    ) {
        Row(Modifier.padding(horizontal = 7.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (active) "◉" else "○", color = if (active) Color(0xFF64A7FF) else StudioColors.Muted, fontSize = 10.sp)
            Spacer(Modifier.width(7.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 10.sp)
                Text(subtitle, fontSize = 8.sp, color = StudioColors.Muted)
            }
            trailing?.invoke()
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 10.sp, color = StudioColors.Muted)
        Text(value, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ToggleLine(label: String, checked: Boolean, onChanged: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 9.sp)
        Switch(checked = checked, onCheckedChange = onChanged)
    }
}
