package com.elharika.electricaldesigner3d

import android.graphics.Paint
import android.view.MotionEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.roundToInt
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI
import kotlinx.coroutines.delay

@Composable
fun ElectricalDesignerApp(vm: EditorViewModel = viewModel()) {
    ProfessionalStudioShell(vm)
}

@Composable private fun TopBar(vm:EditorViewModel){
    Surface(tonalElevation=2.dp){
        Row(Modifier.fillMaxWidth().padding(horizontal=14.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)){
            Text("ELHARIKA Electrical Designer 3D",style=MaterialTheme.typography.titleMedium)
            AssistChip(onClick={},label={Text("v2.0 Real3D α")})
            Spacer(Modifier.weight(1f))
            AssistChip(onClick={},label={Text("Cable ${"%.1f".format(vm.totalCableMeters())} m")})
            FilterChip(selected=vm.viewMode.value==ViewMode.PLAN_2D,onClick={vm.setViewMode(ViewMode.PLAN_2D)},label={Text("2D")})
            FilterChip(selected=vm.viewMode.value==ViewMode.VIEW_3D,onClick={vm.setViewMode(ViewMode.VIEW_3D)},label={Text("3D")})
            TextButton(onClick=vm::exportPdf){Text("Export PDF")}; TextButton(onClick=vm::exportCsv){Text("CSV")}; TextButton(onClick=vm::undo){Text("Undo")}; TextButton(onClick=vm::redo){Text("Redo")}
        }
    }
}

@Composable private fun ToolRail(vm:EditorViewModel,modifier:Modifier=Modifier){
    Surface(modifier,tonalElevation=1.dp){
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(8.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(6.dp)){
            Text("TOOLS",fontSize=11.sp,color=Color.Gray)
            EditorTool.entries.forEach{t->
                FilledTonalButton(
                    onClick={vm.setTool(t);if(t!=EditorTool.SELECT)vm.setViewMode(ViewMode.PLAN_2D)},
                    modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(horizontal=4.dp,vertical=7.dp),
                    colors=if(vm.tool.value==t)ButtonDefaults.filledTonalButtonColors(containerColor=MaterialTheme.colorScheme.primaryContainer)else ButtonDefaults.filledTonalButtonColors()
                ){Text(t.label,fontSize=10.sp)}
            }
            HorizontalDivider(Modifier.padding(vertical=5.dp)); FloorManager(vm); HorizontalDivider(); Text("CIRCUIT",fontSize=11.sp,color=Color.Gray)
            vm.project.value.circuits.forEach{c-> FilterChip(selected=vm.project.value.activeCircuitId==c.id,onClick={vm.setActiveCircuit(c.id)},label={Text(c.name,fontSize=10.sp)},modifier=Modifier.fillMaxWidth()) }
            HorizontalDivider(); CircuitManager(vm)
            HorizontalDivider()
            Text("WIRING",fontSize=11.sp,color=Color.Gray)
            val wiringIssues=vm.wiringIssues()
            Text("${vm.project.value.wireLinks.size} conductor links",fontSize=10.sp)
            Text("${wiringIssues.count{it.severity=="ERROR"}} errors • ${wiringIssues.count{it.severity=="WARN"}} warnings",fontSize=10.sp,color=if(wiringIssues.any{it.severity=="ERROR"})Color(0xFFB3261E)else Color.Gray)
            Button(onClick=vm::autoBuildAndValidateWiring,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("Build + Validate",fontSize=10.sp)}
            if(wiringIssues.isNotEmpty()){
                wiringIssues.take(4).forEach{issue->Text("• ${issue.message}",fontSize=8.sp,color=if(issue.severity=="ERROR")Color(0xFFB3261E)else Color(0xFF9A6700))}
            }
            HorizontalDivider()
            Text("SIMULATION",fontSize=11.sp,color=Color.Gray)
            Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=vm.simulationEnabled.value,onCheckedChange=vm::setSimulationEnabled);Spacer(Modifier.width(4.dp));Text("Run",fontSize=10.sp)}
            if(vm.simulationEnabled.value){
                val sim=vm.lastSimulation.value
                Text("${sim.litLightIds.size} lights ON • ${sim.trippedCircuitIds.size} trips",fontSize=9.sp)
                sim.messages.take(3).forEach{Text("• $it",fontSize=8.sp,color=Color(0xFFB3261E))}
                OutlinedButton(onClick=vm::clearSimulationFaults,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(3.dp)){Text("Clear faults",fontSize=9.sp)}
            }
            HorizontalDivider(); LayerManager(vm); HorizontalDivider(); TextButton(onClick=vm::clearProject){Text("Clear")}
        }
    }
}

@Composable private fun FloorManager(vm:EditorViewModel){
    val p=vm.project.value
    Text("FLOORS",fontSize=11.sp,color=Color.Gray)
    p.floors.forEach{f-> FilterChip(selected=p.activeFloorId==f.id,onClick={vm.setActiveFloor(f.id)},label={Text(f.name,fontSize=10.sp)},modifier=Modifier.fillMaxWidth()) }
    OutlinedButton(onClick={vm.addFloor()},modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("+ Floor",fontSize=10.sp)}
    OutlinedButton(onClick=vm::duplicateActiveFloor,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("Duplicate floor",fontSize=10.sp)}
    if(p.floors.size>1) TextButton(onClick=vm::deleteActiveFloor,modifier=Modifier.fillMaxWidth()){Text("Delete floor",fontSize=10.sp)}
    Row(verticalAlignment=Alignment.CenterVertically){ Switch(checked=vm.smartInkEnabled.value,onCheckedChange=vm::setSmartInk); Spacer(Modifier.width(4.dp)); Text("Smart Pen",fontSize=10.sp) }
    Row(verticalAlignment=Alignment.CenterVertically){ Switch(checked=vm.sketchPlanMode.value,onCheckedChange=vm::setSketchPlanMode); Spacer(Modifier.width(4.dp)); Text("Sketch Plan",fontSize=10.sp) }
    if(vm.sketchPlanMode.value){ Text("${vm.sketchStrokeCount.intValue} strokes",fontSize=10.sp,color=Color.Gray); Button(onClick=vm::convertSketchPlan,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("Convert Sketch",fontSize=10.sp)}; TextButton(onClick=vm::clearSketchBuffer,modifier=Modifier.fillMaxWidth()){Text("Clear sketch",fontSize=10.sp)} }
    Row(verticalAlignment=Alignment.CenterVertically){ Switch(checked=vm.showDimensions.value,onCheckedChange=vm::setShowDimensions); Spacer(Modifier.width(4.dp)); Text("CAD dimensions",fontSize=10.sp) }
    Row(verticalAlignment=Alignment.CenterVertically){ Switch(checked=vm.multiSelectMode.value,onCheckedChange=vm::setMultiSelectMode); Spacer(Modifier.width(4.dp)); Text("Multi-select",fontSize=10.sp) }
    if(vm.tool.value==EditorTool.SELECT){
        OutlinedButton(onClick=vm::selectAllOnFloor,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("Select all",fontSize=10.sp)}
        Text("Selected: ${vm.selectedIds.value.size}",fontSize=10.sp,color=Color.Gray)
    }
}

@Composable private fun LayerManager(vm:EditorViewModel){
    val p=vm.project.value
    Text("LAYERS",fontSize=11.sp,color=Color.Gray)
    p.layers.forEach{l->
        Surface(color=if(p.activeLayerId==l.id)MaterialTheme.colorScheme.primaryContainer else Color.Transparent,shape=RoundedCornerShape(8.dp)){
            Column(Modifier.fillMaxWidth().padding(4.dp)){
                TextButton(onClick={vm.setActiveLayer(l.id)},modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(2.dp)){Text(l.name,fontSize=10.sp)}
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(2.dp)){
                    OutlinedButton(onClick={vm.toggleLayerVisibility(l.id)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(2.dp)){Text(if(l.visible)"Hide" else "Show",fontSize=8.sp)}
                    OutlinedButton(onClick={vm.toggleLayerLock(l.id)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(2.dp)){Text(if(l.locked)"Unlock" else "Lock",fontSize=8.sp)}
                }
            }
        }
    }
    OutlinedButton(onClick={vm.addLayer()},modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("+ Layer",fontSize=10.sp)}
    TextButton(onClick=vm::unhideAllOnFloor,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(2.dp)){Text("Show all elements",fontSize=9.sp)}
}

@Composable private fun CircuitManager(vm:EditorViewModel){
    val active=vm.project.value.circuit(vm.project.value.activeCircuitId) ?: return
    var name by remember(active.id,active.name){ mutableStateOf(active.name) }
    var cable by remember(active.id,active.cableSpec){ mutableStateOf(active.cableSpec) }
    var breaker by remember(active.id,active.breaker){ mutableStateOf(active.breaker) }
    var route by remember(active.id,active.route){ mutableStateOf(active.route) }
    Text("MANAGE",fontSize=11.sp,color=Color.Gray)
    OutlinedTextField(name,{name=it},label={Text("Circuit")},singleLine=true,modifier=Modifier.fillMaxWidth())
    OutlinedTextField(cable,{cable=it},label={Text("Cable")},singleLine=true,modifier=Modifier.fillMaxWidth())
    OutlinedTextField(breaker,{breaker=it},label={Text("Breaker")},singleLine=true,modifier=Modifier.fillMaxWidth())
    CableRoute.entries.forEach{r-> FilterChip(selected=route==r,onClick={route=r},label={Text(r.label,fontSize=10.sp)},modifier=Modifier.fillMaxWidth())}
    Button(onClick={vm.updateCircuit(active.id,name,cable,breaker,route)},modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("Save circuit",fontSize=10.sp)}
    OutlinedButton(onClick={vm.addCircuit("CIR-${vm.project.value.circuits.size+1}","3×2.5 mm²","C20",CableRoute.WALL)},modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("+ Circuit",fontSize=10.sp)}
    TextButton(onClick={vm.deleteCircuit(active.id)},modifier=Modifier.fillMaxWidth()){Text("Delete",fontSize=10.sp)}
}

@Composable private fun PropertiesPanel(vm:EditorViewModel,modifier:Modifier=Modifier){
    val p=vm.project.value; val selected=p.elements.firstOrNull{it.id==vm.selectedId.value}
    Surface(modifier,tonalElevation=1.dp){
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
            Text("PROPERTIES",fontSize=11.sp,color=Color.Gray)
            if(vm.selectedIds.value.isNotEmpty()){
                Text("SELECTION • ${vm.selectedIds.value.size}",fontSize=11.sp,color=Color.Gray)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                    OutlinedButton(onClick=vm::copySelected,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Copy",fontSize=10.sp)}
                    OutlinedButton(onClick=vm::cutSelected,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Cut",fontSize=10.sp)}
                    OutlinedButton(onClick=vm::pasteClipboard,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Paste",fontSize=10.sp)}
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                    OutlinedButton(onClick=vm::rotateSelected90,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Rotate 90°",fontSize=9.sp)}
                    OutlinedButton(onClick=vm::clearSelection,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Clear sel.",fontSize=9.sp)}
                }
                if(vm.selectedIds.value.size>=2){
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                        OutlinedButton(onClick=vm::alignSelectedLeft,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Align left",fontSize=9.sp)}
                        OutlinedButton(onClick=vm::alignSelectedTop,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Align top",fontSize=9.sp)}
                    }
                }
                if(vm.selectedIds.value.size>=3) OutlinedButton(onClick=vm::distributeSelectedHorizontally,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("Distribute horizontally",fontSize=9.sp)}
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                    OutlinedButton(onClick=vm::groupSelected,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Group",fontSize=9.sp)}
                    OutlinedButton(onClick=vm::ungroupSelected,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Ungroup",fontSize=9.sp)}
                }
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                    OutlinedButton(onClick=vm::toggleSelectedLocked,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Lock / unlock",fontSize=8.sp)}
                    OutlinedButton(onClick={vm.setSelectedHidden(true)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Hide",fontSize=9.sp)}
                }
                Text("Move to layer",fontSize=10.sp,color=Color.Gray)
                p.layers.forEach{l->FilterChip(selected=selected?.layerId==l.id,onClick={vm.moveSelectedToLayer(l.id)},label={Text(l.name,fontSize=9.sp)},modifier=Modifier.fillMaxWidth())}
                HorizontalDivider()
            }
            if(selected==null){
                Text("Project",style=MaterialTheme.typography.titleMedium)
                Stat("Floor",p.floor(p.activeFloorId)?.name ?: "Ground floor"); Stat("Floors",p.floors.size.toString())
                Stat("Scale","1 m = ${p.pixelsPerMeter.roundToInt()} px"); Stat("Grid","${p.gridMeters} m"); Stat("Ceiling","${p.ceilingHeightMeters} m"); Stat("Wall default","${p.defaultWallThicknessMeters} m")
                Text("Supply ${"%.0f".format(p.supplyVoltage)} V",fontSize=12.sp); Slider(value=p.supplyVoltage,onValueChange=vm::setSupplyVoltage,valueRange=110f..400f)
                Text("Electrical intelligence",style=MaterialTheme.typography.titleSmall)
                Button(onClick=vm::autoWireActiveCircuit,modifier=Modifier.fillMaxWidth()){Text("Auto-wire active circuit")}
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                    OutlinedButton(onClick=vm::validateElectricalProject,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Validate",fontSize=9.sp)}
                    OutlinedButton(onClick=vm::renumberElectricalPoints,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Renumber",fontSize=9.sp)}
                }
                vm.circuitChecks().forEach{check->
                    val text=if(check.warnings.isEmpty()) "${check.circuitName}: OK" else "${check.circuitName}: ${check.warnings.joinToString()}"
                    Text(text,fontSize=10.sp,color=if(check.warnings.isEmpty()) Color(0xFF2E7D32) else Color(0xFFB26A00))
                }
                Text("Load analysis",style=MaterialTheme.typography.titleSmall)
                vm.circuitLoads().forEach{load->
                    Surface(color=Color(0xFFF4F6F9),shape=RoundedCornerShape(8.dp)){
                        Column(Modifier.fillMaxWidth().padding(7.dp)){
                            Text("${load.circuitName} • ${"%.0f".format(load.watts)} W • ${"%.2f".format(load.amps)} A",fontSize=10.sp)
                            Text("Breaker ${load.breakerAmps}A • utilization ${"%.0f".format(load.utilizationPercent)}%",fontSize=9.sp,color=if(load.utilizationPercent>80f)Color(0xFFB26A00) else Color.Gray)
                            TextButton(onClick={vm.applyRecommendedCircuit(load.circuitId)},contentPadding=PaddingValues(1.dp)){Text("Apply ${load.recommendedBreaker} / ${load.recommendedCable}",fontSize=9.sp)}
                        }
                    }
                }
                HorizontalDivider(); Text("Bill of materials",style=MaterialTheme.typography.titleSmall)
                vm.bom().forEach{Stat(it.name,it.quantity)}
                AutomaticPanel(vm)
            } else {
                Text(selected.label.ifBlank{selected.kind.name},style=MaterialTheme.typography.titleMedium); Stat("Type",selected.kind.name); Stat("Layer",p.layer(selected.layerId)?.name ?: "Default"); Stat("Locked",if(p.isLocked(selected))"Yes" else "No"); Stat("Group",selected.groupId?.toString() ?: "—")
                val pts=selected.geometryPoints(); if(pts.size>=2) Stat("Length","${"%.2f".format(p.pathMeters(pts))} m")
                if(selected.kind==ElementKind.CABLE){
                    Stat("Cable",selected.cableSpec); Stat("Route",selected.route.label); Stat("Segments",(selected.geometryPoints().size-1).coerceAtLeast(1).toString()); Stat("Connections",selected.connectedElementIds.size.toString()); Stat("Horizontal","${"%.2f".format(p.pathMeters(selected.geometryPoints()))} m"); Stat("Vertical","${"%.2f".format(selected.verticalMeters)} m"); Stat("Total","${"%.2f".format(p.cableMeters(selected))} m")
                    Text("Montée / descente ${"%.2f".format(selected.verticalMeters)} m",fontSize=12.sp); Slider(value=selected.verticalMeters,onValueChange=vm::updateSelectedVerticalMeters,valueRange=0f..12f)
                    Text("Conduit Ø ${selected.conduitDiameterMm.roundToInt()} mm",fontSize=12.sp); Slider(value=selected.conduitDiameterMm,onValueChange=vm::updateSelectedConduitDiameter,valueRange=10f..50f,steps=7)
                    Text("Saignée ${selected.chaseWidthMm.roundToInt()} × ${selected.chaseDepthMm.roundToInt()} mm",fontSize=12.sp)
                    Slider(value=selected.chaseWidthMm,onValueChange=vm::updateSelectedChaseWidth,valueRange=20f..80f,steps=11)
                    Slider(value=selected.chaseDepthMm,onValueChange=vm::updateSelectedChaseDepth,valueRange=10f..60f,steps=9)
                    Text("Conductors ${selected.conductorCount}",fontSize=12.sp)
                    Slider(value=selected.conductorCount.toFloat(),onValueChange={vm.updateSelectedConductorCount(it.roundToInt())},valueRange=2f..7f,steps=4)
                    Text("Section ${"%.1f".format(selected.conductorSectionMm2)} mm²",fontSize=12.sp)
                    Slider(value=selected.conductorSectionMm2,onValueChange=vm::updateSelectedConductorSection,valueRange=.5f..16f)
                    Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=selected.hasProtectiveEarth,onCheckedChange=vm::setSelectedProtectiveEarth);Spacer(Modifier.width(6.dp));Text("Protective earth (PE)",fontSize=11.sp)}
                    Text("Bend radius ${selected.bendRadiusMm.roundToInt()} mm",fontSize=12.sp)
                    Slider(value=selected.bendRadiusMm,onValueChange=vm::updateSelectedBendRadius,valueRange=20f..150f,steps=12)
                    if(selected.route==CableRoute.WALL){
                        OutlinedButton(onClick=vm::conformSelectedCableToWalls,modifier=Modifier.fillMaxWidth()){Text("Conform route to walls")}
                    }
                    Text("Route",fontSize=12.sp,color=Color.Gray)
                    CableRoute.entries.forEach{r-> FilterChip(selected=selected.route==r,onClick={vm.updateSelectedRoute(r)},label={Text(r.label)},modifier=Modifier.fillMaxWidth()) }
                    Text("Circuit",fontSize=12.sp,color=Color.Gray)
                    p.circuits.forEach{c-> FilterChip(selected=selected.circuitId==c.id,onClick={vm.assignSelectedCircuit(c.id)},label={Text("${c.name} • ${c.breaker}")},modifier=Modifier.fillMaxWidth()) }
                }
                if(selected.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT,ElementKind.PANEL,ElementKind.JUNCTION_BOX)){
                    Text("Height ${"%.2f".format(selected.heightMeters)} m"); Slider(value=selected.heightMeters,onValueChange=vm::updateSelectedHeight,valueRange=0f..4f)
                    if(selected.kind!=ElementKind.PANEL){
                        Text("Boîte Ø ${selected.boxDiameterMm.roundToInt()} mm • depth ${selected.boxDepthMm.roundToInt()} mm",fontSize=11.sp)
                        Slider(value=selected.boxDiameterMm,onValueChange=vm::updateSelectedBoxDiameter,valueRange=40f..100f,steps=11)
                        Slider(value=selected.boxDepthMm,onValueChange=vm::updateSelectedBoxDepth,valueRange=25f..100f,steps=14)
                        if(selected.hostWallId!=null){
                            Text("Embedded ${selected.embeddedDepthMm.roundToInt()} mm in wall",fontSize=11.sp)
                            Slider(value=selected.embeddedDepthMm,onValueChange=vm::updateSelectedEmbeddedDepth,valueRange=5f..80f,steps=14)
                        }
                    }
                    if(selected.kind==ElementKind.SOCKET || selected.kind==ElementKind.LIGHT){
                        val shownPower=if(selected.ratedPowerWatts>0f)selected.ratedPowerWatts else if(selected.kind==ElementKind.SOCKET)200f else 80f
                        Text("Estimated load ${"%.0f".format(shownPower)} W",fontSize=12.sp)
                        Slider(value=shownPower.coerceIn(0f,3000f),onValueChange=vm::updateSelectedPower,valueRange=0f..3000f)
                    }
                    if(selected.kind!=ElementKind.PANEL) {
                        p.circuits.forEach{c-> FilterChip(selected=selected.circuitId==c.id,onClick={vm.assignSelectedCircuit(c.id)},label={Text(c.name)},modifier=Modifier.fillMaxWidth()) }
                        Button(onClick=vm::autoRouteSelectedToPanel,modifier=Modifier.fillMaxWidth()){Text("Auto route to panel")}
                    }
                }
                if(selected.kind==ElementKind.DOOR || selected.kind==ElementKind.WINDOW) Stat("Attached wall",selected.hostWallId?.toString() ?: "Free")
                if(selected.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.LIGHT,ElementKind.JUNCTION_BOX,ElementKind.PANEL)){
                    val incoming=p.wireLinks.filter{it.toElementId==selected.id||it.fromElementId==selected.id}
                    if(incoming.isNotEmpty()){
                        Text("TERMINALS",style=MaterialTheme.typography.titleSmall)
                        incoming.groupBy{it.role}.forEach{(role,links)->Text("$role • ${links.size} link(s)",fontSize=11.sp)}
                    }
                }
                if(selected.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT,ElementKind.JUNCTION_BOX)){
                    Text("SIMULATION",style=MaterialTheme.typography.titleSmall)
                    if(selected.kind==ElementKind.SWITCH){
                        val swState=p.simulationStates.firstOrNull{it.elementId==selected.id} ?: SimulationState(selected.id)
                        Button(onClick={vm.toggleSwitch(selected.id)},modifier=Modifier.fillMaxWidth()){Text(if(swState.switchClosed)"Switch: CLOSED" else "Switch: OPEN")}
                    }
                    if(selected.kind==ElementKind.TWO_WAY_SWITCH){
                        val swState=p.simulationStates.firstOrNull{it.elementId==selected.id} ?: SimulationState(selected.id)
                        Button(onClick={vm.toggleTwoWaySwitch(selected.id)},modifier=Modifier.fillMaxWidth()){Text("Position ${swState.switchPosition+1}")}
                        val peers=p.elements.filter{it.kind==ElementKind.TWO_WAY_SWITCH&&it.id!=selected.id&&it.floorId==selected.floorId}
                        Text("Pair with",fontSize=11.sp,color=Color.Gray)
                        FilterChip(selected=selected.pairedElementId==null,onClick={vm.pairSelectedTwoWayWith(null)},label={Text("None")},modifier=Modifier.fillMaxWidth())
                        peers.forEach{peer->FilterChip(selected=selected.pairedElementId==peer.id,onClick={vm.pairSelectedTwoWayWith(peer.id)},label={Text(peer.label.ifBlank{"Va-et-vient ${peer.id}"})},modifier=Modifier.fillMaxWidth())}
                    }
                    if(selected.kind==ElementKind.CONTACTOR){
                        val cState=p.simulationStates.firstOrNull{it.elementId==selected.id} ?: SimulationState(selected.id)
                        Button(onClick={vm.toggleContactorCoil(selected.id)},modifier=Modifier.fillMaxWidth()){Text(if(cState.coilEnergized)"Coil: ON" else "Coil: OFF")}
                        val controls=p.elements.filter{it.kind in listOf(ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH)&&it.floorId==selected.floorId}
                        Text("Control switch",fontSize=11.sp,color=Color.Gray)
                        FilterChip(selected=selected.controlElementId==null,onClick={vm.setSelectedContactorControl(null)},label={Text("Manual coil")},modifier=Modifier.fillMaxWidth())
                        controls.forEach{ctrl->FilterChip(selected=selected.controlElementId==ctrl.id,onClick={vm.setSelectedContactorControl(ctrl.id)},label={Text(ctrl.label.ifBlank{ctrl.kind.name})},modifier=Modifier.fillMaxWidth())}
                    }
                    val currentFault=p.simulationStates.firstOrNull{it.elementId==selected.id}?.fault ?: "NONE"
                    Text("Fault injection",fontSize=11.sp,color=Color.Gray)
                    listOf("NONE","OPEN","SHORT_LN","SHORT_LE","SHORT_NE").forEach{f->
                        FilterChip(selected=currentFault==f,onClick={vm.setFault(selected.id,f)},label={Text(f,fontSize=9.sp)},modifier=Modifier.fillMaxWidth())
                    }
                    if(vm.simulationEnabled.value){
                        val voltage=vm.lastSimulation.value.terminalVoltages["${selected.id}:L"] ?: 0f
                        Text("L-N voltage ${"%.0f".format(voltage)} V",fontSize=12.sp)
                        if(selected.kind==ElementKind.LIGHT) Text(if(selected.id in vm.lastSimulation.value.litLightIds)"Lamp: ON" else "Lamp: OFF",fontSize=12.sp)
                    }
                }
                if(selected.kind==ElementKind.WALL){
                    Text("Wall thickness ${"%.2f".format(selected.wallThicknessMeters)} m"); Slider(value=selected.wallThicknessMeters,onValueChange=vm::updateSelectedWallThickness,valueRange=.05f..0.50f)
                    Text("Wall CAD",style=MaterialTheme.typography.titleSmall)
                    var lengthText by remember(selected.id){ mutableStateOf("%.2f".format(p.pathMeters(selected.geometryPoints()))) }
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                        OutlinedTextField(value=lengthText,onValueChange={lengthText=it},label={Text("Length m")},singleLine=true,modifier=Modifier.weight(1f))
                        Button(onClick={lengthText.replace(',','.').toFloatOrNull()?.let(vm::setSelectedWallLengthMeters)},modifier=Modifier.weight(1f)){Text("Apply",fontSize=9.sp)}
                    }
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){
                        OutlinedButton(onClick=vm::splitSelectedWall,modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Split",fontSize=9.sp)}
                        OutlinedButton(onClick={vm.offsetSelectedWall(.15f)},modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)){Text("Offset 15cm",fontSize=8.sp)}
                    }
                    OutlinedButton(onClick=vm::trimExtendSelectedWallToNearest,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("Trim / Extend to nearest wall",fontSize=9.sp)}
                    if(vm.selectedIds.value.size==2) OutlinedButton(onClick=vm::joinSelectedWalls,modifier=Modifier.fillMaxWidth(),contentPadding=PaddingValues(4.dp)){Text("Join selected walls",fontSize=9.sp)}
                }
                if(selected.kind==ElementKind.ROOM){
                    var roomName by remember(selected.id, selected.label){ mutableStateOf(selected.label) }; OutlinedTextField(value=roomName,onValueChange={roomName=it},label={Text("Room name")},singleLine=true,modifier=Modifier.fillMaxWidth()); Button(onClick={vm.renameSelected(roomName)},modifier=Modifier.fillMaxWidth()){Text("Save room name")}
                    Stat("Linked walls",selected.roomWallIds.size.toString()); OutlinedButton(onClick=vm::repairRoomWallLinks,modifier=Modifier.fillMaxWidth()){Text("Repair room-wall links")}
                }
                if(selected.kind==ElementKind.PANEL) AutomaticPanel(vm)
                if(selected.kind==ElementKind.STAIRCASE || selected.kind==ElementKind.RISER){
                    Text("Connect to floor",fontSize=12.sp,color=Color.Gray)
                    p.floors.filter{it.id!=selected.floorId}.forEach{f-> FilterChip(selected=selected.targetFloorId==f.id,onClick={vm.setSelectedTargetFloor(f.id)},label={Text(f.name)},modifier=Modifier.fillMaxWidth()) }
                }
                Text("Select + drag to move",fontSize=11.sp,color=Color.Gray)
            }
            if(vm.statusMessage.value.isNotBlank()) Text(vm.statusMessage.value,fontSize=11.sp,color=MaterialTheme.colorScheme.primary); Spacer(Modifier.height(4.dp)); HorizontalDivider(); Text("S Pen: pressure ink • snap • auto route • PDF",fontSize=11.sp,color=Color.Gray)
        }
    }
}

@Composable private fun AutomaticPanel(vm:EditorViewModel){
    HorizontalDivider(); Text("Tableau TD01 • automatic",style=MaterialTheme.typography.titleSmall)
    vm.panelLines().forEach{line->
        Surface(color=Color(0xFFF1F3F8),shape=RoundedCornerShape(8.dp)){
            Column(Modifier.fillMaxWidth().padding(8.dp)){
                Text("${line.breaker}  ${line.circuitName}",fontSize=12.sp)
                Text("${line.cable} • ${line.loadCount} points • ${"%.1f".format(line.cableMeters)} m",fontSize=10.sp,color=Color.Gray)
            }
        }
    }
}

@Composable private fun Stat(name:String,value:String){ Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(name,color=Color.DarkGray,fontSize=12.sp);Text(value,fontSize=12.sp)} }

@OptIn(ExperimentalComposeUiApi::class)
@Composable fun PlanEditor(vm:EditorViewModel){
    val p=vm.project.value; val visible=p.visibleActiveElements(); val a=vm.previewStart.value; val b=vm.previewEnd.value; val routePreview=vm.previewPath.value; val selected=vm.selectedId.value; val selectedSet=vm.selectedIds.value
    Box(Modifier.fillMaxSize().background(Color.White,RoundedCornerShape(12.dp)).border(1.dp,Color(0xFFE2E4E9),RoundedCornerShape(12.dp)).pointerInteropFilter{e->
        val pos=Offset(e.x,e.y); val stylus=e.getToolType(0)==MotionEvent.TOOL_TYPE_STYLUS
        when(e.actionMasked){MotionEvent.ACTION_DOWN->vm.onInputDown(pos,e.pressure,stylus);MotionEvent.ACTION_MOVE->vm.onInputMove(pos,e.pressure);MotionEvent.ACTION_UP->vm.onInputUp(pos,e.pressure);MotionEvent.ACTION_CANCEL->vm.cancelInput()};true
    }){
        Canvas(Modifier.fillMaxSize()){
            val step=p.pixelsPerMeter*p.gridMeters; var x=0f;while(x<size.width){drawLine(Color(0xFFF0F1F4),Offset(x,0f),Offset(x,size.height),1f);x+=step};var y=0f;while(y<size.height){drawLine(Color(0xFFF0F1F4),Offset(0f,y),Offset(size.width,y),1f);y+=step}
            visible.filter{it.kind==ElementKind.ROOM}.forEach{drawRoom2D(it,p)}
            p.ink.forEach{s->for(i in 1 until s.points.size){val p0=s.points[i-1];val p1=s.points[i];drawLine(Color(0xFF20242B),Offset(p0.x,p0.y),Offset(p1.x,p1.y),1.5f+p1.pressure*2.2f,StrokeCap.Round)}}
            visible.filter{it.kind!=ElementKind.ROOM}.forEach{drawElement2D(it,it.id==selected || it.id in selectedSet,p)}
            visible.firstOrNull{it.id==selected && it.end!=null && it.kind in listOf(ElementKind.WALL,ElementKind.DOOR,ElementKind.WINDOW,ElementKind.STAIRCASE)}?.let{ drawEditHandles(it) }
            vm.sketchPreview().forEach{s->for(i in 1 until s.points.size){val p0=s.points[i-1];val p1=s.points[i];drawLine(Color(0xFF6B5B95),Offset(p0.x,p0.y),Offset(p1.x,p1.y),2.4f,StrokeCap.Round)}}
            if(vm.showDimensions.value) visible.filter{it.kind==ElementKind.WALL || it.kind==ElementKind.DOOR || it.kind==ElementKind.WINDOW}.forEach{drawCadDimension(it,p)}
            if(a!=null&&b!=null){
                if(vm.tool.value==EditorTool.ROOM){
                    drawRect(Color(0x102457D6),topLeft=Offset(minOf(a.x,b.x),minOf(a.y,b.y)),size=androidx.compose.ui.geometry.Size(kotlin.math.abs(b.x-a.x),kotlin.math.abs(b.y-a.y)))
                    drawRect(Color(0xFF2457D6),topLeft=Offset(minOf(a.x,b.x),minOf(a.y,b.y)),size=androidx.compose.ui.geometry.Size(kotlin.math.abs(b.x-a.x),kotlin.math.abs(b.y-a.y)),style=Stroke(3f))
                } else {
                    val c=when(vm.tool.value){EditorTool.WALL->Color(0xFF49515D);EditorTool.DOOR->Color(0xFF8B5E3C);EditorTool.WINDOW->Color(0xFF3A93B8);EditorTool.STAIRCASE->Color(0xFF6B5B95);else->Color(0xFF2457D6)}
                    drawLine(c,a,b,if(vm.tool.value==EditorTool.WALL)9f else 5f,StrokeCap.Round)
                }
            }
            if(routePreview.size>=2) routePreview.zipWithNext().forEach{(q0,q1)->drawLine(Color(0xFF2457D6),q0.offset(),q1.offset(),5f,StrokeCap.Round)}
            val sb0=vm.selectionBoxStart.value; val sb1=vm.selectionBoxEnd.value
            if(sb0!=null&&sb1!=null){ val left=minOf(sb0.x,sb1.x); val top=minOf(sb0.y,sb1.y); val w=kotlin.math.abs(sb1.x-sb0.x); val h=kotlin.math.abs(sb1.y-sb0.y); drawRect(Color(0x142457D6),Offset(left,top),androidx.compose.ui.geometry.Size(w,h)); drawRect(Color(0xFF2457D6),Offset(left,top),androidx.compose.ui.geometry.Size(w,h),style=Stroke(2f)) }
        }
        Text("${p.floor(p.activeFloorId)?.name} • ${if(vm.sketchPlanMode.value) "Sketch Plan (${vm.sketchStrokeCount.intValue})" else vm.tool.value.label} • grid ${p.gridMeters} m • ${p.circuit(p.activeCircuitId)?.name}",Modifier.align(Alignment.BottomStart).padding(12.dp).background(Color.White.copy(alpha=.92f),RoundedCornerShape(8.dp)).padding(8.dp),fontSize=12.sp)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRoom2D(e:DesignElement,p:ElectricalProject){
    val b=e.end?:return; val left=minOf(e.start.x,b.x); val top=minOf(e.start.y,b.y); val w=kotlin.math.abs(b.x-e.start.x); val h=kotlin.math.abs(b.y-e.start.y)
    drawRect(Color(0xFFF8FAFC),Offset(left,top),androidx.compose.ui.geometry.Size(w,h))
    drawContext.canvas.nativeCanvas.drawText(e.label.ifBlank{"Room"},left+w/2,top+h/2-14f,Paint().apply{color=android.graphics.Color.DKGRAY;textSize=23f;textAlign=Paint.Align.CENTER;isFakeBoldText=true}); drawContext.canvas.nativeCanvas.drawText("${"%.1f".format(w/p.pixelsPerMeter)} × ${"%.1f".format(h/p.pixelsPerMeter)} m",left+w/2,top+h/2+16f,Paint().apply{color=android.graphics.Color.GRAY;textSize=20f;textAlign=Paint.Align.CENTER})
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawElement2D(e:DesignElement,selected:Boolean,p:ElectricalProject){
    val accent=if(selected)Color(0xFFE78A1C)else Color(0xFF2457D6)
    when(e.kind){
        ElementKind.WALL->{ val width=(e.wallThicknessMeters*p.pixelsPerMeter).coerceIn(6f,28f)+(if(selected)3f else 0f); drawLine(if(selected)accent else Color(0xFF3B4048),e.start.offset(),e.end!!.offset(),width,StrokeCap.Square);drawLengthLabel(e,p)}
        ElementKind.DOOR->{drawLine(Color.White,e.start.offset(),e.end!!.offset(),13f);drawLine(Color(0xFF8B5E3C),e.start.offset(),e.end!!.offset(),5f);drawDoorArc(e);drawLengthLabel(e,p)}
        ElementKind.WINDOW->{drawLine(Color.White,e.start.offset(),e.end!!.offset(),13f);drawLine(Color(0xFF3A93B8),e.start.offset(),e.end!!.offset(),5f);drawLengthLabel(e,p)}
        ElementKind.CABLE->{
            val color=when(e.route){CableRoute.WALL->accent;CableRoute.CEILING->Color(0xFF6F4BD8);CableRoute.FLOOR->Color(0xFF2B8A6E);CableRoute.SURFACE->Color(0xFFD36C2F)}
            e.geometryPoints().zipWithNext().forEach{(a,b)->drawLine(color,a.offset(),b.offset(),if(selected)6f else 4f,StrokeCap.Round)}
            drawPathLengthLabel(e,p)
        }
        ElementKind.SOCKET->{drawCircle(Color.White,13f,e.start.offset());drawCircle(accent,13f,e.start.offset(),style=Stroke(3f));drawCircle(accent,2.5f,e.start.offset()+Offset(-4f,0f));drawCircle(accent,2.5f,e.start.offset()+Offset(4f,0f))}
        ElementKind.SWITCH->{drawCircle(Color.White,13f,e.start.offset());drawCircle(accent,13f,e.start.offset(),style=Stroke(3f));drawLine(accent,e.start.offset()+Offset(-5f,5f),e.start.offset()+Offset(6f,-5f),3f)}
        ElementKind.TWO_WAY_SWITCH->{drawCircle(Color.White,14f,e.start.offset());drawCircle(accent,14f,e.start.offset(),style=Stroke(3f));drawLine(accent,e.start.offset()+Offset(-6f,0f),e.start.offset()+Offset(6f,-6f),2.5f);drawLine(accent,e.start.offset()+Offset(-6f,0f),e.start.offset()+Offset(6f,6f),2.5f)}
        ElementKind.CONTACTOR->{drawRect(Color.White,e.start.offset()+Offset(-15f,-18f),androidx.compose.ui.geometry.Size(30f,36f));drawRect(accent,e.start.offset()+Offset(-15f,-18f),androidx.compose.ui.geometry.Size(30f,36f),style=Stroke(3f));drawCircle(accent,5f,e.start.offset()+Offset(0f,-7f),style=Stroke(2f));drawLine(accent,e.start.offset()+Offset(-8f,8f),e.start.offset()+Offset(8f,8f),2f)}
        ElementKind.LIGHT->{drawCircle(Color.White,14f,e.start.offset());drawCircle(accent,14f,e.start.offset(),style=Stroke(3f));drawLine(accent,e.start.offset()+Offset(-8f,-8f),e.start.offset()+Offset(8f,8f),2f);drawLine(accent,e.start.offset()+Offset(8f,-8f),e.start.offset()+Offset(-8f,8f),2f)}
        ElementKind.JUNCTION_BOX->{drawRect(Color.White,e.start.offset()+Offset(-12f,-12f),androidx.compose.ui.geometry.Size(24f,24f));drawRect(accent,e.start.offset()+Offset(-12f,-12f),androidx.compose.ui.geometry.Size(24f,24f),style=Stroke(3f));drawLine(accent,e.start.offset()+Offset(-7f,0f),e.start.offset()+Offset(7f,0f),2f);drawLine(accent,e.start.offset()+Offset(0f,-7f),e.start.offset()+Offset(0f,7f),2f)}
        ElementKind.PANEL->{drawRect(Color.White,e.start.offset()+Offset(-18f,-24f),androidx.compose.ui.geometry.Size(36f,48f));drawRect(accent,e.start.offset()+Offset(-18f,-24f),androidx.compose.ui.geometry.Size(36f,48f),style=Stroke(4f));drawLine(accent,e.start.offset()+Offset(-10f,-10f),e.start.offset()+Offset(10f,-10f),2f);drawLine(accent,e.start.offset()+Offset(-10f,0f),e.start.offset()+Offset(10f,0f),2f);drawLine(accent,e.start.offset()+Offset(-10f,10f),e.start.offset()+Offset(10f,10f),2f)}
        ElementKind.STAIRCASE->{ val b=e.end?:return; drawRect(Color(0xFFF5F1FA),topLeft=Offset(minOf(e.start.x,b.x),minOf(e.start.y,b.y)),size=androidx.compose.ui.geometry.Size(kotlin.math.abs(b.x-e.start.x),kotlin.math.abs(b.y-e.start.y))); val steps=7; for(i in 0..steps){val t=i/steps.toFloat(); val x=e.start.x+(b.x-e.start.x)*t; val y=e.start.y+(b.y-e.start.y)*t; drawCircle(if(selected)accent else Color(0xFF6B5B95),4f,Offset(x,y))}; drawLine(if(selected)accent else Color(0xFF6B5B95),e.start.offset(),b.offset(),4f)}
        ElementKind.RISER->{drawCircle(Color.White,15f,e.start.offset());drawCircle(if(selected)accent else Color(0xFFB35C44),15f,e.start.offset(),style=Stroke(4f));drawLine(if(selected)accent else Color(0xFFB35C44),e.start.offset()+Offset(0f,8f),e.start.offset()+Offset(0f,-8f),3f);drawLine(if(selected)accent else Color(0xFFB35C44),e.start.offset()+Offset(0f,-8f),e.start.offset()+Offset(-5f,-2f),3f);drawLine(if(selected)accent else Color(0xFFB35C44),e.start.offset()+Offset(0f,-8f),e.start.offset()+Offset(5f,-2f),3f)}
        ElementKind.ROOM->Unit
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawEditHandles(e:DesignElement){
    val b=e.end?:return; val c=Color(0xFFE78A1C)
    listOf(e.start.offset(),b.offset()).forEach{q->drawCircle(Color.White,11f,q);drawCircle(c,11f,q,style=Stroke(3f));drawCircle(c,3f,q)}
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCadDimension(e:DesignElement,p:ElectricalProject){
    val b=e.end?:return
    val dx=b.x-e.start.x; val dy=b.y-e.start.y; val len=kotlin.math.hypot(dx.toDouble(),dy.toDouble()).toFloat()
    if(len<20f)return
    val nx=-dy/len; val ny=dx/len; val gap=22f
    val a=Offset(e.start.x+nx*gap,e.start.y+ny*gap); val q=Offset(b.x+nx*gap,b.y+ny*gap)
    val c=Color(0xFF5D6673)
    drawLine(c,e.start.offset(),a,1f); drawLine(c,b.offset(),q,1f); drawLine(c,a,q,1.6f)
    val tick=5f
    drawLine(c,a+Offset(-nx*tick,-ny*tick),a+Offset(nx*tick,ny*tick),1.6f)
    drawLine(c,q+Offset(-nx*tick,-ny*tick),q+Offset(nx*tick,ny*tick),1.6f)
    val mid=Offset((a.x+q.x)/2f,(a.y+q.y)/2f)-Offset(nx*7f,ny*7f)
    drawContext.canvas.nativeCanvas.drawText("${"%.2f".format(p.metersBetween(e.start,b))} m",mid.x,mid.y,Paint().apply{color=android.graphics.Color.rgb(70,78,89);textSize=18f;textAlign=Paint.Align.CENTER;isFakeBoldText=true})
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawDoorArc(e:DesignElement){
    val b=e.end?:return; val r=kotlin.math.hypot((b.x-e.start.x).toDouble(),(b.y-e.start.y).toDouble()).toFloat()
    if(r<10f)return
    val p=Path().apply{moveTo(e.start.x,e.start.y);lineTo(e.start.x,e.start.y-r*.55f);quadraticTo(e.start.x+r*.45f,e.start.y-r*.55f,b.x,b.y)}
    drawPath(p,Color(0x668B5E3C),style=Stroke(1.5f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawLengthLabel(e:DesignElement,p:ElectricalProject){ val end=e.end?:return;val mid=Offset((e.start.x+end.x)/2f,(e.start.y+end.y)/2f-8f);drawContext.canvas.nativeCanvas.drawText("${"%.2f".format(p.metersBetween(e.start,end))} m",mid.x,mid.y,Paint().apply{color=android.graphics.Color.DKGRAY;textSize=22f;textAlign=Paint.Align.CENTER}) }
private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawPathLengthLabel(e:DesignElement,p:ElectricalProject){ val pts=e.geometryPoints(); if(pts.size<2)return; val mid=pts[pts.size/2].offset()+Offset(0f,-8f);drawContext.canvas.nativeCanvas.drawText("${"%.2f".format(p.cableMeters(e))} m",mid.x,mid.y,Paint().apply{color=android.graphics.Color.DKGRAY;textSize=22f;textAlign=Paint.Align.CENTER}) }

@OptIn(ExperimentalLayoutApi::class)
@Composable fun Isometric3DView(vm:EditorViewModel){
    val p=vm.project.value
    val baseModel=if(vm.showAllFloors3D.value)p.visibleElements() else p.visibleActiveElements()
    val isolated=vm.isolatedCircuit3D.value
    val model=if(isolated==null) baseModel else baseModel.filter{it.kind !in listOf(ElementKind.CABLE,ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.JUNCTION_BOX,ElementKind.LIGHT) || it.circuitId==isolated}
    val yaw=vm.cameraYaw.floatValue; val pitch=vm.cameraPitch.floatValue; val zoom=vm.cameraZoom.floatValue
    val animatedCircuit=isolated ?: p.activeCircuitId
    LaunchedEffect(vm.routeAnimationRunning.value, animatedCircuit){
        if(vm.routeAnimationRunning.value){
            vm.setRouteAnimationProgress(0f)
            while(vm.routeAnimationRunning.value && vm.routeAnimationProgress.floatValue < 1f){ delay(32); vm.setRouteAnimationProgress(vm.routeAnimationProgress.floatValue+.014f) }
            if(vm.routeAnimationProgress.floatValue>=1f) vm.setRouteAnimationRunning(false)
        }
    }
    Box(Modifier.fillMaxSize().background(if(vm.constructionMode3D.value) Color(0xFFE9ECEF) else Color(0xFFF1F3F6),RoundedCornerShape(12.dp)).border(1.dp,Color(0xFFE2E4E9),RoundedCornerShape(12.dp)).pointerInput(Unit){
        detectTransformGestures { _, pan, gestureZoom, rotation -> vm.rotateCamera(rotation, -pan.y*.08f); vm.zoomCamera(gestureZoom); vm.panCamera(pan.x,pan.y) }
    }){
        Canvas(Modifier.fillMaxSize()){
            val origin=Offset(size.width*.50f+vm.cameraPanX.floatValue,size.height*.42f+vm.cameraPanY.floatValue)
            val yr=(yaw/180f*PI).toFloat(); val pr=(pitch/180f*PI).toFloat(); val c=cos(yr); val sn=sin(yr); val cp=cos(pr); val sp=sin(pr); val scale=.50f*zoom
            fun proj(q:Point2,z:Float=0f):Offset{ val x=q.x*scale; val y=q.y*scale; val rzX=x*c-y*sn; val rzY=x*sn+y*c; return Offset(origin.x+rzX, origin.y+rzY*sp-z*65f*cp*zoom) }
            fun circuitColor(id:Long?):Color = when(((id?:0L)%6).toInt()){0->Color(0xFF2457D6);1->Color(0xFFE67E22);2->Color(0xFF2E9D57);3->Color(0xFFD13C59);4->Color(0xFF7D4BC2);else->Color(0xFF008C95)}
            fun conductorColor(index:Int,count:Int):Color = when(index){
                0->Color(0xFF8B4513)   // phase
                1->Color(0xFF1E5AA8)   // neutral
                2->Color(0xFF2D8A45)   // protective earth
                3->Color(0xFF303030)
                4->Color(0xFF7A3E9D)
                5->Color(0xFFCC6B00)
                else->Color(0xFF666666)
            }
            fun drawWireBundle(a:Offset,b:Offset,count:Int,width:Float){
                val dx=b.x-a.x; val dy=b.y-a.y; val len=kotlin.math.sqrt(dx*dx+dy*dy).coerceAtLeast(.001f)
                val nx=-dy/len; val ny=dx/len
                val spacing=(width*1.7f).coerceIn(2.4f,5.5f)
                val center=(count-1)/2f
                for(i in 0 until count.coerceIn(2,7)){
                    val off=(i-center)*spacing
                    val d=Offset(nx*off,ny*off)
                    drawLine(conductorColor(i,count),a+d,b+d,width,StrokeCap.Round)
                }
            }
            fun drawRoundedPolyline(points:List<Offset>,color:Color,width:Float,radiusPx:Float){
                if(points.size<2)return
                if(points.size==2){drawLine(color,points[0],points[1],width,StrokeCap.Round);return}
                val path=Path()
                path.moveTo(points.first().x,points.first().y)
                for(i in 1 until points.lastIndex){
                    val prev=points[i-1]; val cur=points[i]; val next=points[i+1]
                    val d1=kotlin.math.sqrt((cur.x-prev.x)*(cur.x-prev.x)+(cur.y-prev.y)*(cur.y-prev.y)).coerceAtLeast(.001f)
                    val d2=kotlin.math.sqrt((next.x-cur.x)*(next.x-cur.x)+(next.y-cur.y)*(next.y-cur.y)).coerceAtLeast(.001f)
                    val r=minOf(radiusPx,d1*.42f,d2*.42f)
                    val a=Offset(cur.x-(cur.x-prev.x)/d1*r,cur.y-(cur.y-prev.y)/d1*r)
                    val b=Offset(cur.x+(next.x-cur.x)/d2*r,cur.y+(next.y-cur.y)/d2*r)
                    path.lineTo(a.x,a.y)
                    path.quadraticTo(cur.x,cur.y,b.x,b.y)
                }
                path.lineTo(points.last().x,points.last().y)
                drawPath(path,color,style=Stroke(width=width,cap=StrokeCap.Round))
            }
            fun drawRoundedWireBundle(points:List<Offset>,count:Int,width:Float,radiusPx:Float){
                if(points.size<2)return
                val first=points.first();val last=points.last()
                val dx=last.x-first.x;val dy=last.y-first.y;val len=kotlin.math.sqrt(dx*dx+dy*dy).coerceAtLeast(.001f)
                val nx=-dy/len;val ny=dx/len
                val spacing=(width*1.8f).coerceIn(2.4f,5.8f);val center=(count-1)/2f
                for(i in 0 until count.coerceIn(2,7)){
                    val off=(i-center)*spacing;val shift=Offset(nx*off,ny*off)
                    drawRoundedPolyline(points.map{it+shift},conductorColor(i,count),width,radiusPx)
                }
            }
            fun drawDim(a:Offset,b:Offset,label:String){ drawLine(Color(0xFF5E6875),a,b,1.2f); drawLine(Color(0xFF5E6875),a+Offset(-5f,0f),a+Offset(5f,0f),1.2f); drawLine(Color(0xFF5E6875),b+Offset(-5f,0f),b+Offset(5f,0f),1.2f); val m=(a+b)/2f; drawContext.canvas.nativeCanvas.drawText(label,m.x+7f,m.y,Paint().apply{color=android.graphics.Color.DKGRAY;textSize=16f}) }
            val midY=model.map{it.start.y}.average().takeIf{!it.isNaN()}?.toFloat()?:0f
            if(!vm.constructionMode3D.value) model.filter{it.kind==ElementKind.ROOM}.forEach{r->val b=r.end?:return@forEach;val base=p.floor(r.floorId)?.elevationMeters?:0f;val p1=proj(r.start,base);val p2=proj(Point2(b.x,r.start.y),base);val p3=proj(b,base);val p4=proj(Point2(r.start.x,b.y),base);val path=Path().apply{moveTo(p1.x,p1.y);lineTo(p2.x,p2.y);lineTo(p3.x,p3.y);lineTo(p4.x,p4.y);close()};drawPath(path,Color(0xFFF9FAFB));drawPath(path,Color(0xFFD8DCE2),style=Stroke(1f))}
            if(vm.wallView3D.value!=WallView3D.HIDDEN) model.filter{it.kind==ElementKind.WALL}.forEach{w->
                val b=w.end?:return@forEach; if(vm.cutaway3D.value && (w.start.y+b.y)/2f>midY) return@forEach
                val base=p.floor(w.floorId)?.elevationMeters?:0f;val a0=proj(w.start,base);val b0=proj(b,base);val a1=proj(w.start,base+p.ceilingHeightMeters);val b1=proj(b,base+p.ceilingHeightMeters)
                val path=Path().apply{moveTo(a0.x,a0.y);lineTo(b0.x,b0.y);lineTo(b1.x,b1.y);lineTo(a1.x,a1.y);close()}
                val fill=when{vm.wallView3D.value==WallView3D.TRANSPARENT->Color(0x33C8CDD4);vm.constructionMode3D.value->Color(0xFFCED3D8);else->Color(0xFFE2E5E9)}
                drawPath(path,fill);drawPath(path,Color(0xFF8B939D),style=Stroke(1.2f))
            }
            model.filter{it.kind==ElementKind.DOOR||it.kind==ElementKind.WINDOW}.forEach{o->
                val b=o.end?:return@forEach; val top=if(o.kind==ElementKind.DOOR)2.10f else 2.00f; val bottom=if(o.kind==ElementKind.WINDOW).90f else 0f; val base=p.floor(o.floorId)?.elevationMeters?:0f
                val a0=proj(o.start,base+bottom);val b0=proj(b,base+bottom);val a1=proj(o.start,base+top);val b1=proj(b,base+top);val cut=Path().apply{moveTo(a0.x,a0.y);lineTo(b0.x,b0.y);lineTo(b1.x,b1.y);lineTo(a1.x,a1.y);close()}
                drawPath(cut,if(o.kind==ElementKind.WINDOW)Color(0xFFBFDDE9) else Color(0xFFE7EAEE));drawPath(cut,if(o.kind==ElementKind.WINDOW)Color(0xFF3A93B8) else Color(0xFF8B5E3C),style=Stroke(2f))
            }
            model.filter{it.kind==ElementKind.STAIRCASE}.forEach{e->val b=e.end?:return@forEach; val base=p.floor(e.floorId)?.elevationMeters?:0f; val target=e.targetFloorId?.let(p::floor)?.elevationMeters ?: (base+p.ceilingHeightMeters+.3f); val steps=10; for(i in 0 until steps){ val t0=i/steps.toFloat(); val t1=(i+1)/steps.toFloat(); val a=Point2(e.start.x+(b.x-e.start.x)*t0,e.start.y+(b.y-e.start.y)*t0); val q=Point2(e.start.x+(b.x-e.start.x)*t1,e.start.y+(b.y-e.start.y)*t1); drawLine(Color(0xFF6B5B95),proj(a,base+(target-base)*t0),proj(q,base+(target-base)*t1),6f,StrokeCap.Round)} }
            model.filter{it.kind==ElementKind.RISER}.forEach{e-> val base=p.floor(e.floorId)?.elevationMeters?:0f; val target=e.targetFloorId?.let(p::floor)?.elevationMeters ?: (base+p.ceilingHeightMeters+.3f); drawLine(Color(0xFFB35C44),proj(e.start,base),proj(e.start,target),if(vm.showConduits3D.value)10f else 5f,StrokeCap.Round) }
            val cables=model.filter{it.kind==ElementKind.CABLE}; val animCables=cables.filter{it.circuitId==animatedCircuit}
            cables.forEach{cable->
                val z=when(cable.route){CableRoute.FLOOR->.05f;CableRoute.CEILING->p.ceilingHeightMeters-.1f;CableRoute.WALL->1.0f;CableRoute.SURFACE->1.5f}; val base=p.floor(cable.floorId)?.elevationMeters?:0f; val energizedCable=vm.simulationEnabled.value&&p.wireLinks.any{it.cableId==cable.id&&it.id in vm.lastSimulation.value.energizedWireLinkIds}; val col=if(energizedCable)Color(0xFFFF8A00)else circuitColor(cable.circuitId)
                val conduitWidth=(cable.conduitDiameterMm/3.0f*zoom).coerceIn(5f,24f); val coreWidth=(conduitWidth*.36f).coerceAtLeast(2.5f)
                val localProgress=if(vm.routeAnimationRunning.value && cable.circuitId==animatedCircuit){ val idx=animCables.indexOfFirst{it.id==cable.id}.coerceAtLeast(0); (vm.routeAnimationProgress.floatValue*animCables.size-idx).coerceIn(0f,1f) } else 1f
                val segs=cable.geometryPoints().zipWithNext(); val total=segs.sumOf{(a,b)->p.metersBetween(a,b).toDouble()}.toFloat().coerceAtLeast(.001f); var consumed=0f
                segs.forEach{(a,b)-> val len=p.metersBetween(a,b); val allowed=(localProgress*total-consumed).coerceIn(0f,len); if(allowed>0f){ val t=allowed/len.coerceAtLeast(.001f); val q=Point2(a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t); if(vm.installation3DMode.value && vm.showChases3D.value && vm.installationStage3D.intValue>=1 && cable.route==CableRoute.WALL){
                            val chaseWidth=(cable.chaseWidthMm*.20f*zoom).coerceIn(8f,30f)
                            drawLine(Color(0xFF8F7D6B).copy(alpha=.65f),proj(a,base+z),proj(q,base+z),chaseWidth,StrokeCap.Square)
                        }
                        val pa=proj(a,base+z); val pq=proj(q,base+z)
                        if(localProgress<.99f && vm.installation3DMode.value && vm.showConduits3D.value && vm.installationStage3D.intValue>=2)drawLine(if(energizedCable)col else Color(0xFF858C95),pa,pq,conduitWidth,StrokeCap.Round)
                        if(localProgress<.99f && vm.showConductors3D.value && vm.installationStage3D.intValue>=4)drawWireBundle(pa,pq,cable.conductorCount,(coreWidth*.55f).coerceAtLeast(1.5f)); if(vm.showMeasurements3D.value && localProgress>=1f){
                            val m=(proj(a,base+z)+proj(b,base+z))/2f
                            val linkCount=p.wireLinks.count{it.cableId==cable.id}
                            drawContext.canvas.nativeCanvas.drawText("${"%.2f".format(len)}m • Ø${cable.conduitDiameterMm.roundToInt()} • ${cable.conductorCount}×${"%.1f".format(cable.conductorSectionMm2)}mm² • $linkCount links",m.x+5f,m.y-4f,Paint().apply{color=android.graphics.Color.DKGRAY;textSize=14f})
                        }}; consumed+=len }
                if(localProgress>=.99f){
                    val roundedPts=cable.geometryPoints().map{proj(it,base+z)}
                    val radiusPx=(cable.bendRadiusMm*.08f*zoom).coerceIn(4f,24f)
                    if(vm.installation3DMode.value&&vm.showConduits3D.value&&vm.installationStage3D.intValue>=2)
                        drawRoundedPolyline(roundedPts,if(energizedCable)col else Color(0xFF858C95),conduitWidth,radiusPx)
                    if(vm.showConductors3D.value&&vm.installationStage3D.intValue>=4)
                        drawRoundedWireBundle(roundedPts,cable.conductorCount,(coreWidth*.50f).coerceAtLeast(1.4f),radiusPx*.8f)
                }
                if(localProgress>=.99f && vm.showConduits3D.value && vm.installationStage3D.intValue>=2){
                    val pts=cable.geometryPoints()
                    pts.drop(1).dropLast(1).forEach{corner->
                        val qc=proj(corner,base+z)
                        val r=(conduitWidth*.58f).coerceIn(4f,15f)
                        drawCircle(Color(0xFF737A83),r,qc)
                        if(vm.showConductors3D.value&&vm.installationStage3D.intValue>=4){
                            drawCircle(circuitColor(cable.circuitId),(r*.34f).coerceAtLeast(2f),qc)
                        }
                    }
                }
                if(localProgress>=.92f) cable.connectedElementIds.mapNotNull{id->model.firstOrNull{it.id==id}}.forEach{device->
                    val db=p.floor(device.floorId)?.elevationMeters?:base
                    if(vm.installation3DMode.value&&vm.showChases3D.value&&vm.installationStage3D.intValue>=1&&cable.route==CableRoute.WALL){
                        val chaseWidth=(cable.chaseWidthMm*.20f*zoom).coerceIn(8f,30f)
                        drawLine(Color(0xFF8F7D6B).copy(alpha=.65f),proj(device.start,db+z),proj(device.start,db+device.heightMeters),chaseWidth,StrokeCap.Square)
                    }
                    val va=proj(device.start,db+z); val vb=proj(device.start,db+device.heightMeters)
                    if(vm.installation3DMode.value&&vm.showConduits3D.value&&vm.installationStage3D.intValue>=2)drawLine(Color(0xFF858C95),va,vb,conduitWidth,StrokeCap.Round)
                    if(vm.showConductors3D.value&&vm.installationStage3D.intValue>=4)drawWireBundle(va,vb,cable.conductorCount,(coreWidth*.55f).coerceAtLeast(1.5f))
                }
            }
            model.filter{it.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT,ElementKind.JUNCTION_BOX)}.forEach{e->
                val base=p.floor(e.floorId)?.elevationMeters?:0f;val floorQ=proj(e.start,base);val q=proj(e.start,base+e.heightMeters);val lit=vm.simulationEnabled.value&&e.id in vm.lastSimulation.value.litLightIds;val col=if(lit)Color(0xFFF5B400)else circuitColor(e.circuitId)
                val terminalLinks=p.wireLinks.filter{it.fromElementId==e.id||it.toElementId==e.id}
                if(vm.installationStage3D.intValue>=4 && terminalLinks.isNotEmpty()){
                    terminalLinks.map{it.role}.distinct().forEachIndexed{idx,role->
                        val tq=q+Offset(-10f+idx*10f,13f)
                        val tc=when(role){"L"->Color(0xFF8B4513);"N"->Color(0xFF1E5AA8);"PE"->Color(0xFF2D8A45);else->Color(0xFF555555)}
                        drawCircle(Color.White,4.5f,tq);drawCircle(tc,4.5f,tq,style=Stroke(2f))
                    }
                }
                if(vm.showBoxes3D.value && vm.installationStage3D.intValue>=3){
                    val box=(e.boxDiameterMm*.16f*zoom*(if(e.kind==ElementKind.JUNCTION_BOX)1.25f else 1f)).coerceIn(9f,30f)
                    val recess=(e.embeddedDepthMm*.045f*zoom).coerceIn(1.5f,7f)
                    if(e.hostWallId!=null){
                        drawRect(Color(0xFF5C5550).copy(alpha=.72f),q+Offset(-box/2+recess,-box/2+recess),androidx.compose.ui.geometry.Size(box,box))
                    }
                    drawRect(Color(0xFFBFC4CA),q+Offset(-box/2,-box/2),androidx.compose.ui.geometry.Size(box,box))
                    drawRect(Color(0xFF6F7781),q+Offset(-box/2,-box/2),androidx.compose.ui.geometry.Size(box,box),style=Stroke(2f))
                }
                if(vm.installationStage3D.intValue>=5){
                    when(e.kind){
                        ElementKind.JUNCTION_BOX->{drawRect(Color.White,q+Offset(-9f,-9f),androidx.compose.ui.geometry.Size(18f,18f));drawRect(col,q+Offset(-9f,-9f),androidx.compose.ui.geometry.Size(18f,18f),style=Stroke(3f))}
                        ElementKind.CONTACTOR->{drawRect(Color.White,q+Offset(-12f,-16f),androidx.compose.ui.geometry.Size(24f,32f));drawRect(col,q+Offset(-12f,-16f),androidx.compose.ui.geometry.Size(24f,32f),style=Stroke(3f))}
                        else->{drawCircle(if(lit)Color(0xFFFFF3B0) else Color.White,10f,q);drawCircle(col,10f,q,style=Stroke(3f))}
                    }
                }; if(vm.showMeasurements3D.value)drawDim(floorQ,q,"H ${"%.2f".format(e.heightMeters)}m")
                if(vm.showDeviceLabels3D.value){drawContext.canvas.nativeCanvas.drawText("${e.label.ifBlank{e.kind.name}} • Ø${e.boxDiameterMm.roundToInt()}×${e.boxDepthMm.roundToInt()}mm${if(e.hostWallId!=null)" • enc.${e.embeddedDepthMm.roundToInt()}mm" else ""}",q.x+15f,q.y-10f,Paint().apply{color=android.graphics.Color.DKGRAY;textSize=16f})}
            }
            model.filter{it.kind==ElementKind.PANEL}.forEach{e->val base=p.floor(e.floorId)?.elevationMeters?:0f;val q=proj(e.start,base+e.heightMeters);drawRect(Color.White,q+Offset(-16f,-22f),androidx.compose.ui.geometry.Size(32f,44f));drawRect(Color(0xFF2457D6),q+Offset(-16f,-22f),androidx.compose.ui.geometry.Size(32f,44f),style=Stroke(3f));if(vm.showDeviceLabels3D.value)drawContext.canvas.nativeCanvas.drawText(e.label.ifBlank{"TD"},q.x+20f,q.y,Paint().apply{color=android.graphics.Color.DKGRAY;textSize=20f})}
        }
        Column(Modifier.align(Alignment.TopStart).padding(14.dp).widthIn(max=350.dp).background(Color.White.copy(alpha=.96f),RoundedCornerShape(10.dp)).padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
            Text(if(vm.installation3DMode.value)"Legacy 3D Electrical View" else "Legacy 3D Architectural View",style=MaterialTheme.typography.titleSmall)
            Button(onClick={vm.setReal3DEnabled(true)},contentPadding=PaddingValues(horizontal=8.dp,vertical=4.dp)){Text("Open Real 3D",fontSize=9.sp)}
            Text("${p.floors.size} floors • rotate / pinch zoom / pan",fontSize=11.sp,color=Color.Gray)
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){FilterChip(selected=vm.installation3DMode.value,onClick={vm.setInstallation3DMode(true)},label={Text("Installation",fontSize=9.sp)});FilterChip(selected=!vm.installation3DMode.value,onClick={vm.setInstallation3DMode(false)},label={Text("Architecture",fontSize=9.sp)})}
            Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=vm.constructionMode3D.value,onCheckedChange=vm::setConstructionMode3D);Spacer(Modifier.width(4.dp));Text("Construction mode",fontSize=10.sp)}
            Text("Execution stage",fontSize=10.sp,color=Color.Gray)
            val stageNames=listOf("Tableau","Saignées","Gaines","Boîtes","Fils","Appareils")
            FlowRow(horizontalArrangement=Arrangement.spacedBy(3.dp)){stageNames.forEachIndexed{i,n->FilterChip(selected=vm.installationStage3D.intValue==i,onClick={vm.setInstallationStage3D(i)},label={Text(n,fontSize=8.sp)})}}
            Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=vm.showChases3D.value,onCheckedChange=vm::setShowChases3D);Spacer(Modifier.width(4.dp));Text("Saignées",fontSize=10.sp)}
            Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=vm.showConductors3D.value,onCheckedChange=vm::setShowConductors3D);Spacer(Modifier.width(4.dp));Text("Individual conductors / fils",fontSize=10.sp)}
            Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=vm.cutaway3D.value,onCheckedChange=vm::setCutaway3D);Spacer(Modifier.width(4.dp));Text("Cutaway front walls",fontSize=10.sp)}
            Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=vm.showConduits3D.value,onCheckedChange=vm::setShowConduits3D);Spacer(Modifier.width(4.dp));Text("Conduits + realistic bends",fontSize=10.sp)}
            Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=vm.showBoxes3D.value,onCheckedChange=vm::setShowBoxes3D);Spacer(Modifier.width(4.dp));Text("Embedded boxes",fontSize=10.sp)}
            Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=vm.showMeasurements3D.value,onCheckedChange=vm::setShowMeasurements3D);Spacer(Modifier.width(4.dp));Text("3D measurements",fontSize=10.sp)}
            Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=vm.showDeviceLabels3D.value,onCheckedChange=vm::setShowDeviceLabels3D);Spacer(Modifier.width(4.dp));Text("Device labels",fontSize=10.sp)}
            Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=vm.showAllFloors3D.value,onCheckedChange=vm::setShowAllFloors3D);Spacer(Modifier.width(4.dp));Text("All floors",fontSize=10.sp)}
            Text("Circuit / route animation",fontSize=10.sp,color=Color.Gray)
            FlowRow(horizontalArrangement=Arrangement.spacedBy(3.dp)){FilterChip(selected=vm.isolatedCircuit3D.value==null,onClick={vm.setIsolatedCircuit3D(null)},label={Text("All",fontSize=9.sp)});p.circuits.forEach{cct->FilterChip(selected=vm.isolatedCircuit3D.value==cct.id,onClick={vm.setIsolatedCircuit3D(cct.id)},label={Text(cct.name,fontSize=9.sp)})}}
            Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){Button(onClick={vm.setRouteAnimationRunning(!vm.routeAnimationRunning.value)},contentPadding=PaddingValues(horizontal=10.dp,vertical=5.dp)){Text(if(vm.routeAnimationRunning.value)"Stop" else "▶ Animate",fontSize=9.sp)};Text("${(vm.routeAnimationProgress.floatValue*100).roundToInt()}%",fontSize=10.sp,modifier=Modifier.padding(top=9.dp))}
            Row(horizontalArrangement=Arrangement.spacedBy(3.dp)){WallView3D.entries.forEach{m->FilterChip(selected=vm.wallView3D.value==m,onClick={vm.setWallView3D(m)},label={Text(m.name.lowercase(),fontSize=9.sp)})}}
            Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){OutlinedButton(onClick={vm.rotateCamera(-15f,0f)},contentPadding=PaddingValues(6.dp)){Text("↶")};OutlinedButton(onClick={vm.rotateCamera(15f,0f)},contentPadding=PaddingValues(6.dp)){Text("↷")};OutlinedButton(onClick={vm.zoomCamera(1.15f)},contentPadding=PaddingValues(6.dp)){Text("+")};OutlinedButton(onClick={vm.zoomCamera(.87f)},contentPadding=PaddingValues(6.dp)){Text("−")};TextButton(onClick=vm::resetCamera){Text("Reset")}}
            Text("Yaw ${yaw.roundToInt()}° • Pitch ${pitch.roundToInt()}° • Zoom ${"%.2f".format(zoom)}×",fontSize=9.sp,color=Color.Gray)
        }
    }
}

