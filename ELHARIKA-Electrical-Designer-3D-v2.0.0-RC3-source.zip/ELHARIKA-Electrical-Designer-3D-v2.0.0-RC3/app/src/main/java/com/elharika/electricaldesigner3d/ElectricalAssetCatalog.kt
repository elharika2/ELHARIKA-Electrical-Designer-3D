package com.elharika.electricaldesigner3d

/**
 * Central registry for photoreal electrical GLB assets.
 *
 * The renderer always prefers a model when it exists in app/src/main/assets and falls back to
 * procedural Real3D geometry if it is absent or fails to load. This lets the asset library grow
 * without breaking projects or forcing all models to be bundled on day one.
 */
data class ElectricalAssetSpec(
    val key: String,
    val assetPath: String,
    val scaleToUnitsMeters: Float,
    val bottomAligned: Boolean = false,
    val yawOffsetDegrees: Float = 0f,
    val source: String,
    val license: String
)

object ElectricalAssetCatalog {
    const val ROOT = "models/electrical"

    private fun spec(
        key: String,
        file: String,
        size: Float,
        bottomAligned: Boolean = false,
        yawOffset: Float = 0f,
        source: String = "Project asset library",
        license: String = "See assets/licenses/ASSET_LICENSES.md"
    ) = ElectricalAssetSpec(key, "$ROOT/$file", size, bottomAligned, yawOffset, source, license)

    val all: Map<String, ElectricalAssetSpec> = listOf(
        spec("conduit-elbow", "conduit_elbow_90.glb", 0.12f, source="ELHARIKA generated mobile GLB", license="Project-generated asset"),
        spec("conduit-coupler", "conduit_coupler.glb", 0.08f, source="ELHARIKA generated mobile GLB", license="Project-generated asset"),
        spec("conduit-t", "conduit_t_branch.glb", 0.14f, source="ELHARIKA generated mobile GLB", license="Project-generated asset"),
        spec("conduit-clamp", "conduit_clamp.glb", 0.08f, source="ELHARIKA generated mobile GLB", license="Project-generated asset"),
        spec("junction-box", "junction_box.glb", 0.14f, source="ELHARIKA generated mobile GLB"),
        spec("recessed-box", "recessed_box_67.glb", 0.085f, source="ELHARIKA generated mobile GLB"),
        spec("socket", "socket_eu.glb", 0.09f, source="ELHARIKA generated mobile GLB"),
        spec("switch", "switch_1gang.glb", 0.09f, source="ELHARIKA generated mobile GLB"),
        spec("two-way-switch", "switch_two_way.glb", 0.09f, source="ELHARIKA generated mobile GLB"),
        spec("contactor", "contactor_din.glb", 0.18f, source="ELHARIKA generated mobile GLB"),
        spec("panel", "distribution_panel.glb", 0.72f, bottomAligned=true, source="ELHARIKA generated mobile GLB", license="Project-generated asset"),
        spec("breaker", "breaker_1p.glb", 0.10f, source="ELHARIKA generated mobile GLB"),
        spec("din-rail", "din_rail.glb", 0.40f, source="ELHARIKA generated mobile GLB"),
        spec("terminal-n", "terminal_bar_n.glb", 0.20f, source="ELHARIKA generated mobile GLB"),
        spec("terminal-pe", "terminal_bar_pe.glb", 0.20f, source="ELHARIKA generated mobile GLB")
    ).associateBy { it.key }

    operator fun get(key: String?): ElectricalAssetSpec? = key?.let(all::get)
    fun requiredPaths(): List<String> = all.values.map { it.assetPath }.sorted()
}
