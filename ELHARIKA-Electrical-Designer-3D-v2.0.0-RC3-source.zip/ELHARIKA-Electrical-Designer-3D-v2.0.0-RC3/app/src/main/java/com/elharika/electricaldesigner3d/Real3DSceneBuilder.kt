package com.elharika.electricaldesigner3d

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.sqrt

/**
 * Pure-Kotlin bridge between the existing 2D electrical project model and a real 3D renderer.
 *
 * All output dimensions are in metres. The renderer (SceneView/Filament) consumes these
 * primitives, while the existing 2D editor remains the single source of truth.
 */
data class Real3DVec3(val x: Float, val y: Float, val z: Float)

enum class Real3DCategory {
    FLOOR, WALL, DOOR_FRAME, WINDOW_FRAME, CHASE, CONDUIT, CONDUCTOR,
    DEVICE_BOX, DEVICE, PANEL, FITTING, SUPPORT, GLAND, SCREW, DIN_RAIL, BREAKER, TERMINAL, RISER, STAIR
}

enum class Real3DQuality(
    val label: String,
    val detailSpacingMultiplier: Float,
    val bendArcSteps: Int
) {
    PERFORMANCE("Performance", 1.8f, 4),
    BALANCED("Balanced", 1.25f, 6),
    ULTRA("Ultra", 1.0f, 8)
}

sealed interface Real3DPrimitive {
    val id: String
    val category: Real3DCategory
    val circuitId: Long?

    data class Box(
        override val id: String,
        override val category: Real3DCategory,
        override val circuitId: Long? = null,
        val center: Real3DVec3,
        val size: Real3DVec3,
        val yawDegrees: Float = 0f,
        val materialKey: String = "neutral",
        val assetKey: String? = null
    ) : Real3DPrimitive

    data class Tube(
        override val id: String,
        override val category: Real3DCategory,
        override val circuitId: Long? = null,
        val start: Real3DVec3,
        val end: Real3DVec3,
        val radiusMeters: Float,
        val materialKey: String = "conduit",
        val assetKey: String? = null
    ) : Real3DPrimitive

    data class Sphere(
        override val id: String,
        override val category: Real3DCategory,
        override val circuitId: Long? = null,
        val center: Real3DVec3,
        val radiusMeters: Float,
        val materialKey: String = "device",
        val assetKey: String? = null,
        val rotationXDegrees: Float = 0f,
        val rotationYDegrees: Float = 0f,
        val rotationZDegrees: Float = 0f
    ) : Real3DPrimitive
}

data class Real3DOptions(
    val showAllFloors: Boolean = true,
    val wallView: WallView3D = WallView3D.OPAQUE,
    val cutaway: Boolean = false,
    val installationMode: Boolean = true,
    val constructionMode: Boolean = false,
    val installationStage: Int = 5,
    val showChases: Boolean = true,
    val showConduits: Boolean = true,
    val showConductors: Boolean = true,
    val showBoxes: Boolean = true,
    val isolatedCircuitId: Long? = null,
    val hiddenCircuitIds: Set<Long> = emptySet(),
    val simulationHighlight: Boolean = false,
    val energizedCableIds: Set<Long> = emptySet(),
    val energizedElementIds: Set<Long> = emptySet(),
    val trippedCircuitIds: Set<Long> = emptySet(),
    val quality: Real3DQuality = Real3DQuality.BALANCED
)

data class Real3DScene(
    val primitives: List<Real3DPrimitive>,
    val center: Real3DVec3,
    val widthMeters: Float,
    val depthMeters: Float,
    val heightMeters: Float
)

object Real3DSceneBuilder {

    /** Stable BIM-style circuit palette inspired by the reference installation video. */
    internal fun circuitMaterialKey(circuitId: Long?): String {
        if (circuitId == null) return "conduit"
        return when (((circuitId % 6L) + 6L) % 6L) {
            0L -> "circuit-red"
            1L -> "circuit-blue"
            2L -> "circuit-yellow"
            3L -> "circuit-green"
            4L -> "circuit-orange"
            else -> "circuit-violet"
        }
    }

    internal fun liveCircuitMaterial(
        circuitId: Long?,
        cableId: Long?,
        options: Real3DOptions
    ): String {
        if (!options.simulationHighlight) return circuitMaterialKey(circuitId)
        if (circuitId != null && circuitId in options.trippedCircuitIds) return "trip-red"
        if (cableId != null && cableId in options.energizedCableIds) return "energized-orange"
        return circuitMaterialKey(circuitId)
    }

    /** Returns evenly spaced support points along a 3D segment. */
    internal fun supportPoints(a: Real3DVec3, b: Real3DVec3, spacingMeters: Float = 1.20f): List<Real3DVec3> {
        val dx=b.x-a.x; val dy=b.y-a.y; val dz=b.z-a.z
        val length=sqrt(dx*dx+dy*dy+dz*dz)
        if (length < spacingMeters * 0.75f) return emptyList()
        val count=(length/spacingMeters).toInt().coerceAtLeast(1)
        return (1..count).mapNotNull { i ->
            val t=i.toFloat()/(count+1f)
            if (t <= 0.05f || t >= 0.95f) null else Real3DVec3(a.x+dx*t,a.y+dy*t,a.z+dz*t)
        }
    }

    /**
     * Returns a rounded polyline suitable for realistic conduit rendering.
     * Corners are replaced with short arc segments using the cable bend radius.
     * The algorithm is intentionally pure Kotlin so it can be unit-tested without a GPU.
     */
    internal fun roundedConduitPath(points: List<Real3DVec3>, bendRadiusMeters: Float, arcSteps: Int = 6): List<Real3DVec3> {
        if (points.size < 3 || bendRadiusMeters <= 0f) return points
        val out = mutableListOf(points.first())
        fun len(x: Float, y: Float, z: Float) = sqrt(x*x + y*y + z*z)
        for (i in 1 until points.lastIndex) {
            val prev=points[i-1]; val cur=points[i]; val next=points[i+1]
            val ax=prev.x-cur.x; val ay=prev.y-cur.y; val az=prev.z-cur.z
            val bx=next.x-cur.x; val by=next.y-cur.y; val bz=next.z-cur.z
            val la=len(ax,ay,az); val lb=len(bx,by,bz)
            if (la < 0.001f || lb < 0.001f) { out += cur; continue }
            val ua=Real3DVec3(ax/la,ay/la,az/la); val ub=Real3DVec3(bx/lb,by/lb,bz/lb)
            val trim=minOf(bendRadiusMeters, la*0.35f, lb*0.35f).coerceAtLeast(0.005f)
            val start=Real3DVec3(cur.x+ua.x*trim,cur.y+ua.y*trim,cur.z+ua.z*trim)
            val end=Real3DVec3(cur.x+ub.x*trim,cur.y+ub.y*trim,cur.z+ub.z*trim)
            out += start
            // Quadratic Bezier gives a smooth, fabrication-like elbow while remaining cheap.
            repeat(arcSteps.coerceIn(2,12)-1) { step ->
                val t=(step+1f)/arcSteps.coerceIn(2,12)
                val omt=1f-t
                out += Real3DVec3(
                    omt*omt*start.x + 2f*omt*t*cur.x + t*t*end.x,
                    omt*omt*start.y + 2f*omt*t*cur.y + t*t*end.y,
                    omt*omt*start.z + 2f*omt*t*cur.z + t*t*end.z
                )
            }
            out += end
        }
        out += points.last()
        return out
    }

    private data class P2m(val x: Float, val z: Float)
    private data class Opening(
        val startMeters: Float,
        val endMeters: Float,
        val bottomMeters: Float,
        val topMeters: Float,
        val element: DesignElement
    )


    internal data class RouteIntersection(
        val point: Real3DVec3,
        val firstCableId: Long,
        val secondCableId: Long,
        val isBranch: Boolean,
        val yawDegrees: Float = 0f
    )

    /** 2D XZ segment intersection used for automatic junction/branch hardware. */
    internal fun segmentIntersectionXZ(
        a: Real3DVec3, b: Real3DVec3, c: Real3DVec3, d: Real3DVec3,
        tolerance: Float = 0.015f
    ): Pair<Real3DVec3, Boolean>? {
        val rX=b.x-a.x; val rZ=b.z-a.z
        val sX=d.x-c.x; val sZ=d.z-c.z
        val den=rX*sZ-rZ*sX
        if (kotlin.math.abs(den) < 1e-5f) return null
        val qpx=c.x-a.x; val qpz=c.z-a.z
        val t=(qpx*sZ-qpz*sX)/den
        val u=(qpx*rZ-qpz*rX)/den
        if (t < -tolerance || t > 1f+tolerance || u < -tolerance || u > 1f+tolerance) return null
        val tc=t.coerceIn(0f,1f); val uc=u.coerceIn(0f,1f)
        val p=Real3DVec3(a.x+rX*tc,(a.y+b.y+c.y+d.y)/4f,a.z+rZ*tc)
        val endpointA=tc < 0.06f || tc > 0.94f
        val endpointB=uc < 0.06f || uc > 0.94f
        return p to (endpointA.xor(endpointB))
    }

    internal data class AssetRotation(val x: Float, val y: Float, val z: Float)

    /** Rotation for GLB fittings authored along local +Z so they follow a conduit segment. */
    internal fun zAxisAssetRotation(a: Real3DVec3, b: Real3DVec3): AssetRotation {
        val dx=b.x-a.x; val dy=b.y-a.y; val dz=b.z-a.z
        val horizontal=sqrt(dx*dx+dz*dz)
        if (horizontal < 0.0001f && kotlin.math.abs(dy) < 0.0001f) return AssetRotation(0f,0f,0f)
        val yaw=Math.toDegrees(atan2(dx.toDouble(), dz.toDouble())).toFloat()
        val pitch=-Math.toDegrees(atan2(dy.toDouble(), horizontal.toDouble())).toFloat()
        return AssetRotation(pitch,yaw,0f)
    }

    /** Constant lateral bundle offset. Keeps parallel conduits visibly separated like a real MEP bundle. */
    internal fun bundleOffset(index: Int, count: Int, spacing: Float): Float {
        if (count <= 1) return 0f
        return (index - (count - 1) / 2f) * spacing
    }

    private fun shiftedBundlePath(points: List<Real3DVec3>, offset: Float): List<Real3DVec3> {
        if (points.size < 2 || kotlin.math.abs(offset) < 0.0001f) return points
        val a=points.first(); val b=points.last()
        val dx=b.x-a.x; val dz=b.z-a.z
        val len=sqrt(dx*dx+dz*dz).coerceAtLeast(0.001f)
        val nx=-dz/len; val nz=dx/len
        return points.map { it.copy(x=it.x+nx*offset,z=it.z+nz*offset) }
    }

    fun build(project: ElectricalProject, options: Real3DOptions = Real3DOptions()): Real3DScene {
        val all = if (options.showAllFloors) project.visibleElements() else project.visibleActiveElements()
        val isolatedFiltered = options.isolatedCircuitId?.let { isolated ->
            all.filter { e ->
                e.kind !in setOf(
                    ElementKind.CABLE, ElementKind.SOCKET, ElementKind.SWITCH,
                    ElementKind.TWO_WAY_SWITCH, ElementKind.CONTACTOR,
                    ElementKind.JUNCTION_BOX, ElementKind.LIGHT
                ) || e.circuitId == isolated
            }
        } ?: all
        val filtered = isolatedFiltered.filter { e ->
            e.circuitId == null || e.circuitId !in options.hiddenCircuitIds
        }

        val boundsPoints = filtered.flatMap { e -> e.geometryPoints().ifEmpty { listOf(e.start) } }
        val minXpx = boundsPoints.minOfOrNull { it.x } ?: 0f
        val maxXpx = boundsPoints.maxOfOrNull { it.x } ?: project.pixelsPerMeter * 6f
        val minZpx = boundsPoints.minOfOrNull { it.y } ?: 0f
        val maxZpx = boundsPoints.maxOfOrNull { it.y } ?: project.pixelsPerMeter * 6f
        val centerXpx = (minXpx + maxXpx) / 2f
        val centerZpx = (minZpx + maxZpx) / 2f

        fun point(p: Point2): P2m = P2m(
            x = (p.x - centerXpx) / project.pixelsPerMeter,
            z = (p.y - centerZpx) / project.pixelsPerMeter
        )
        fun floorBase(floorId: Long): Float = project.floor(floorId)?.elevationMeters ?: 0f

        val primitives = mutableListOf<Real3DPrimitive>()

        // Floor slabs are generated from ROOM bounds. They are true 3D boxes, not 2D fills.
        filtered.filter { it.kind == ElementKind.ROOM }.forEach { room ->
            val end = room.end ?: return@forEach
            val a = point(room.start)
            val b = point(end)
            val width = abs(b.x - a.x).coerceAtLeast(0.05f)
            val depth = abs(b.z - a.z).coerceAtLeast(0.05f)
            val base = floorBase(room.floorId)
            primitives += Real3DPrimitive.Box(
                id = "floor-${room.id}",
                category = Real3DCategory.FLOOR,
                center = Real3DVec3((a.x + b.x) / 2f, base - 0.04f, (a.z + b.z) / 2f),
                size = Real3DVec3(width, 0.08f, depth),
                materialKey = if (options.constructionMode) "concrete" else "floor"
            )
        }

        // Hosted openings are used to split walls into real geometry around doors/windows.
        val openingsByWall = filtered
            .filter { it.kind == ElementKind.DOOR || it.kind == ElementKind.WINDOW }
            .filter { it.hostWallId != null && it.end != null }
            .groupBy { it.hostWallId!! }

        if (options.wallView != WallView3D.HIDDEN) {
            val walls = filtered.filter { it.kind == ElementKind.WALL && it.end != null }
            val cutawayThreshold = walls.map { w ->
                val a = point(w.start); val b = point(w.end!!); (a.z + b.z) / 2f
            }.average().takeIf { !it.isNaN() }?.toFloat() ?: Float.MAX_VALUE

            walls.forEach { wall ->
                val end = wall.end ?: return@forEach
                val a = point(wall.start)
                val b = point(end)
                val dx = b.x - a.x
                val dz = b.z - a.z
                val length = hypot(dx.toDouble(), dz.toDouble()).toFloat()
                if (length < 0.01f) return@forEach
                val wallMidZ = (a.z + b.z) / 2f
                if (options.cutaway && wallMidZ > cutawayThreshold) return@forEach

                val ux = dx / length
                val uz = dz / length
                val base = floorBase(wall.floorId)
                val height = project.ceilingHeightMeters
                val thickness = wall.wallThicknessMeters.coerceIn(0.05f, 0.60f)
                val yaw = Math.toDegrees(atan2(dz.toDouble(), dx.toDouble())).toFloat()

                val openings = openingsByWall[wall.id].orEmpty().mapNotNull { opening ->
                    val oe = opening.end ?: return@mapNotNull null
                    val os = point(opening.start)
                    val ox = point(oe)
                    fun scalar(q: P2m): Float = (q.x - a.x) * ux + (q.z - a.z) * uz
                    val s0 = scalar(os).coerceIn(0f, length)
                    val s1 = scalar(ox).coerceIn(0f, length)
                    val lo = minOf(s0, s1)
                    val hi = maxOf(s0, s1)
                    if (hi - lo < 0.05f) return@mapNotNull null
                    val (bottom, top) = if (opening.kind == ElementKind.DOOR) {
                        0f to 2.10f.coerceAtMost(height)
                    } else {
                        0.90f.coerceAtMost(height) to 2.00f.coerceAtMost(height)
                    }
                    Opening(lo, hi, bottom, top, opening)
                }.sortedBy { it.startMeters }

                fun addWallPiece(idSuffix: String, from: Float, to: Float, bottom: Float, top: Float) {
                    val segLength = (to - from).coerceAtLeast(0f)
                    val segHeight = (top - bottom).coerceAtLeast(0f)
                    if (segLength < 0.015f || segHeight < 0.015f) return
                    val mid = (from + to) / 2f
                    val cx = a.x + ux * mid
                    val cz = a.z + uz * mid
                    primitives += Real3DPrimitive.Box(
                        id = "wall-${wall.id}-$idSuffix",
                        category = Real3DCategory.WALL,
                        center = Real3DVec3(cx, base + bottom + segHeight / 2f, cz),
                        size = Real3DVec3(segLength, segHeight, thickness),
                        yawDegrees = -yaw,
                        materialKey = when (options.wallView) {
                            WallView3D.TRANSPARENT -> "wall-transparent"
                            else -> if (options.constructionMode) "concrete" else "wall"
                        }
                    )
                }

                var cursor = 0f
                openings.forEachIndexed { index, opening ->
                    if (opening.startMeters > cursor) {
                        addWallPiece("full-$index", cursor, opening.startMeters, 0f, height)
                    }
                    if (opening.bottomMeters > 0f) {
                        addWallPiece("below-$index", opening.startMeters, opening.endMeters, 0f, opening.bottomMeters)
                    }
                    if (opening.topMeters < height) {
                        addWallPiece("above-$index", opening.startMeters, opening.endMeters, opening.topMeters, height)
                    }
                    cursor = maxOf(cursor, opening.endMeters)
                }
                if (cursor < length) addWallPiece("tail", cursor, length, 0f, height)
            }
        }

        // Visible frames mark actual door/window openings without blocking the hole.
        filtered.filter { it.kind == ElementKind.DOOR || it.kind == ElementKind.WINDOW }.forEach { opening ->
            val end = opening.end ?: return@forEach
            val a = point(opening.start)
            val b = point(end)
            val dx = b.x - a.x
            val dz = b.z - a.z
            val width = hypot(dx.toDouble(), dz.toDouble()).toFloat().coerceAtLeast(0.05f)
            val base = floorBase(opening.floorId)
            val yaw = -Math.toDegrees(atan2(dz.toDouble(), dx.toDouble())).toFloat()
            val isDoor = opening.kind == ElementKind.DOOR
            val bottom = if (isDoor) 0f else 0.90f
            val top = if (isDoor) 2.10f else 2.00f
            val frame = 0.035f
            val material = if (isDoor) "door" else "window"
            val category = if (isDoor) Real3DCategory.DOOR_FRAME else Real3DCategory.WINDOW_FRAME
            val cx = (a.x + b.x) / 2f
            val cz = (a.z + b.z) / 2f
            primitives += Real3DPrimitive.Box("opening-${opening.id}-top", category, center = Real3DVec3(cx, base + top, cz), size = Real3DVec3(width, frame, frame), yawDegrees = yaw, materialKey = material)
            listOf(-1f, 1f).forEachIndexed { idx, side ->
                val sx = cx + (dx / width) * (width / 2f) * side
                val sz = cz + (dz / width) * (width / 2f) * side
                primitives += Real3DPrimitive.Box(
                    "opening-${opening.id}-side-$idx", category,
                    center = Real3DVec3(sx, base + (bottom + top) / 2f, sz),
                    size = Real3DVec3(frame, top - bottom, frame),
                    yawDegrees = yaw,
                    materialKey = material
                )
            }
        }

        if (options.installationMode) {
            val cables = filtered.filter { it.kind == ElementKind.CABLE }
            val bundleGroups = cables.groupBy { it.floorId to it.route }
            val bundleIndex = mutableMapOf<Long, Pair<Int,Int>>()
            bundleGroups.values.forEach { group ->
                group.sortedBy { it.id }.forEachIndexed { index, cable -> bundleIndex[cable.id]=index to group.size }
            }
            val cableWorldRaw = mutableMapOf<Long,List<Real3DVec3>>()
            cables.forEach { cable ->
                val base = floorBase(cable.floorId)
                val routeHeight = when (cable.route) {
                    CableRoute.FLOOR -> 0.06f
                    CableRoute.CEILING -> (project.ceilingHeightMeters - 0.10f).coerceAtLeast(0.10f)
                    CableRoute.WALL -> 1.00f
                    CableRoute.SURFACE -> 1.50f
                }
                val pts = cable.geometryPoints()
                val unshiftedWorld = pts.map { q ->
                    val p2 = point(q)
                    Real3DVec3(p2.x, base + routeHeight, p2.z)
                }
                val (bi,bc)=bundleIndex[cable.id] ?: (0 to 1)
                val bundleSpacing=((cable.conduitDiameterMm/1000f).coerceIn(0.012f,0.05f)+0.012f)
                val worldRaw = shiftedBundlePath(unshiftedWorld, bundleOffset(bi,bc,bundleSpacing))
                cableWorldRaw[cable.id]=worldRaw
                val radius = (cable.conduitDiameterMm / 2000f).coerceIn(0.005f, 0.05f)
                val bendRadius = (cable.bendRadiusMm / 1000f).coerceIn(radius * 2f, 0.30f)
                val world = roundedConduitPath(worldRaw, bendRadius, options.quality.bendArcSteps)
                world.zipWithNext().forEachIndexed { index, (a, b) ->
                    if (options.showChases && options.installationStage >= 1 && cable.route == CableRoute.WALL) {
                        primitives += Real3DPrimitive.Tube(
                            id = "chase-${cable.id}-$index",
                            category = Real3DCategory.CHASE,
                            circuitId = cable.circuitId,
                            start = a,
                            end = b,
                            radiusMeters = (cable.chaseWidthMm / 2000f).coerceAtLeast(radius * 1.3f),
                            materialKey = "chase"
                        )
                    }
                    if (options.showConduits && options.installationStage >= 2) {
                        primitives += Real3DPrimitive.Tube(
                            id = "conduit-${cable.id}-$index",
                            category = Real3DCategory.CONDUIT,
                            circuitId = cable.circuitId,
                            start = a,
                            end = b,
                            radiusMeters = radius,
                            materialKey = liveCircuitMaterial(cable.circuitId, cable.id, options)
                        )
                    }
                    if (options.showConductors && options.installationStage >= 4) {
                        val count = cable.conductorCount.coerceIn(2, 7)
                        val conductorRadius = (kotlin.math.sqrt(cable.conductorSectionMm2.coerceAtLeast(0.5f).toDouble()).toFloat() / 2500f).coerceIn(0.0012f, 0.004f)
                        repeat(count) { conductor ->
                            val offset = (conductor - (count - 1) / 2f) * conductorRadius * 2.2f
                            val role = when (conductor) { 0 -> "phase"; 1 -> "neutral"; 2 -> if (cable.hasProtectiveEarth) "earth" else "phase"; else -> "phase" }
                            primitives += Real3DPrimitive.Tube(
                                id = "wire-${cable.id}-$index-$conductor",
                                category = Real3DCategory.CONDUCTOR,
                                circuitId = cable.circuitId,
                                start = a.copy(y = a.y + offset),
                                end = b.copy(y = b.y + offset),
                                radiusMeters = conductorRadius,
                                materialKey = role
                            )
                        }
                    }
                }

                // Ceiling/surface supports: small hanger rods and clamps make the scene read like BIM/MEP, not floating tubes.
                if (options.showConduits && options.installationStage >= 2 && cable.route in setOf(CableRoute.CEILING, CableRoute.SURFACE)) {
                    world.zipWithNext().forEachIndexed { segIndex, (a,b) ->
                        supportPoints(a,b,1.20f*options.quality.detailSpacingMultiplier).forEachIndexed { supportIndex, q ->
                            val ceilingY=base + project.ceilingHeightMeters
                            val topY=maxOf(q.y+0.03f, ceilingY)
                            if (topY-q.y > 0.04f) {
                                primitives += Real3DPrimitive.Tube(
                                    id="hanger-${cable.id}-$segIndex-$supportIndex", category=Real3DCategory.SUPPORT, circuitId=cable.circuitId,
                                    start=Real3DVec3(q.x,q.y+radius*1.3f,q.z), end=Real3DVec3(q.x,topY,q.z),
                                    radiusMeters=0.0035f, materialKey="support-metal"
                                )
                            }
                            val clampRot=zAxisAssetRotation(a,b)
                            primitives += Real3DPrimitive.Sphere(
                                id="clamp-${cable.id}-$segIndex-$supportIndex", category=Real3DCategory.SUPPORT, circuitId=cable.circuitId,
                                center=q, radiusMeters=radius*1.23f, materialKey="support-clamp", assetKey="conduit-clamp",
                                rotationXDegrees=clampRot.x, rotationYDegrees=clampRot.y, rotationZDegrees=clampRot.z
                            )
                        }
                    }
                }

                // Visible sleeves/couplers at joins make the conduit network read like a real installation.
                if (options.showConduits && options.installationStage >= 2 && world.size > 2) {
                    val fittingStride=when(options.quality){ Real3DQuality.PERFORMANCE->5; Real3DQuality.BALANCED->3; Real3DQuality.ULTRA->2 }
                    (1 until world.lastIndex).filter { it % fittingStride == 1 }.forEachIndexed { index, wi ->
                        val joint=world[wi]
                        val rot=zAxisAssetRotation(world[wi],world[wi+1])
                        primitives += Real3DPrimitive.Sphere(
                            id = "fitting-${cable.id}-$index",
                            category = Real3DCategory.FITTING,
                            circuitId = cable.circuitId,
                            center = joint,
                            radiusMeters = radius * 1.18f,
                            materialKey = liveCircuitMaterial(cable.circuitId, cable.id, options),
                            assetKey = "conduit-elbow",
                            rotationXDegrees=rot.x, rotationYDegrees=rot.y, rotationZDegrees=rot.z
                        )
                    }
                }

                // Straight-run couplers every ~1.5 m, similar to visible sleeves in real installations.
                if (options.showConduits && options.installationStage >= 2) {
                    world.zipWithNext().forEachIndexed { segIndex, (a,b) ->
                        val dx=b.x-a.x; val dy=b.y-a.y; val dz=b.z-a.z
                        val len=sqrt(dx*dx+dy*dy+dz*dz)
                        val count=(len/(1.5f*options.quality.detailSpacingMultiplier)).toInt()
                        repeat(count) { k ->
                            val t=(k+1f)/(count+1f)
                            val couplerRot=zAxisAssetRotation(a,b)
                            primitives += Real3DPrimitive.Sphere(
                                id="coupler-${cable.id}-$segIndex-$k", category=Real3DCategory.FITTING, circuitId=cable.circuitId,
                                center=Real3DVec3(a.x+dx*t,a.y+dy*t,a.z+dz*t), radiusMeters=radius*1.12f,
                                materialKey=liveCircuitMaterial(cable.circuitId, cable.id, options), assetKey="conduit-coupler",
                                rotationXDegrees=couplerRot.x, rotationYDegrees=couplerRot.y, rotationZDegrees=couplerRot.z
                            )
                        }
                    }
                }


                // Entry/exit sleeves at cable ends: visible collars/grommets where a conduit penetrates a wall/box.
                if (options.showConduits && options.installationStage >= 2 && worldRaw.size >= 2) {
                    listOf(worldRaw.first(), worldRaw.last()).forEachIndexed { endpointIndex, q ->
                        val sa=if(endpointIndex==0) worldRaw[0] else worldRaw[worldRaw.lastIndex-1]
                        val sb=if(endpointIndex==0) worldRaw[1] else worldRaw.last()
                        val sleeveRot=zAxisAssetRotation(sa,sb)
                        primitives += Real3DPrimitive.Sphere(
                            id="penetration-${cable.id}-$endpointIndex",
                            category=Real3DCategory.FITTING,
                            circuitId=cable.circuitId,
                            center=q,
                            radiusMeters=radius*1.28f,
                            materialKey=liveCircuitMaterial(cable.circuitId,cable.id,options),
                            assetKey="conduit-coupler",
                            rotationXDegrees=sleeveRot.x, rotationYDegrees=sleeveRot.y, rotationZDegrees=sleeveRot.z
                        )
                    }
                }

                // Vertical drops/rises from route height to connected electrical devices.
                cable.connectedElementIds.mapNotNull { id -> filtered.firstOrNull { it.id == id } }
                    .filter { it.kind !in setOf(ElementKind.PANEL, ElementKind.CABLE) }
                    .forEachIndexed { index, device ->
                        val d = point(device.start)
                        val y0 = base + routeHeight
                        val y1 = floorBase(device.floorId) + device.heightMeters
                        val lo = minOf(y0, y1)
                        val hi = maxOf(y0, y1)
                        if (hi - lo > 0.02f && options.showConduits && options.installationStage >= 2) {
                            val dropStart=Real3DVec3(d.x, lo, d.z)
                            val dropEnd=Real3DVec3(d.x, hi, d.z)
                            primitives += Real3DPrimitive.Tube(
                                id = "drop-${cable.id}-${device.id}-$index",
                                category = Real3DCategory.CONDUIT,
                                circuitId = cable.circuitId,
                                start = dropStart,
                                end = dropEnd,
                                radiusMeters = radius,
                                materialKey = liveCircuitMaterial(cable.circuitId, cable.id, options)
                            )
                            primitives += Real3DPrimitive.Sphere(
                                id="drop-elbow-${cable.id}-${device.id}-$index", category=Real3DCategory.FITTING,
                                circuitId=cable.circuitId, center=Real3DVec3(d.x,y0,d.z),
                                radiusMeters=radius*1.22f, materialKey=liveCircuitMaterial(cable.circuitId, cable.id, options), assetKey="conduit-elbow"
                            )
                            primitives += Real3DPrimitive.Sphere(
                                id="drop-gland-${cable.id}-${device.id}-$index", category=Real3DCategory.GLAND,
                                circuitId=cable.circuitId, center=Real3DVec3(d.x,y1,d.z),
                                radiusMeters=radius*1.15f, materialKey=liveCircuitMaterial(cable.circuitId, cable.id, options)
                            )
                        }
                    }
            }


            // Shared support rails for conduit bundles. This looks closer to real MEP installation than independent floating clamps.
            bundleGroups.values.filter { it.size >= 2 }.forEachIndexed { groupIndex, group ->
                val representative=group.sortedBy { it.id }.firstOrNull() ?: return@forEachIndexed
                val path=cableWorldRaw[representative.id].orEmpty()
                if(path.size >= 2 && representative.route in setOf(CableRoute.CEILING,CableRoute.SURFACE)){
                    val count=group.size.coerceAtMost(12)
                    val spacing=((representative.conduitDiameterMm/1000f).coerceIn(0.012f,0.05f)+0.012f)
                    val width=(count-1)*spacing + 0.07f
                    path.zipWithNext().forEachIndexed { segIndex,(a,b) ->
                        val dx=b.x-a.x; val dz=b.z-a.z
                        val len=sqrt(dx*dx+dz*dz).coerceAtLeast(0.001f)
                        val nx=-dz/len; val nz=dx/len
                        supportPoints(a,b,1.25f*options.quality.detailSpacingMultiplier).forEachIndexed { supportIndex,q ->
                            val left=Real3DVec3(q.x-nx*width/2f,q.y-0.018f,q.z-nz*width/2f)
                            val right=Real3DVec3(q.x+nx*width/2f,q.y-0.018f,q.z+nz*width/2f)
                            primitives += Real3DPrimitive.Tube(
                                id="bundle-rail-$groupIndex-$segIndex-$supportIndex",
                                category=Real3DCategory.SUPPORT,
                                circuitId=null,
                                start=left,end=right,
                                radiusMeters=0.006f,
                                materialKey="bundle-rail"
                            )
                        }
                    }
                }
            }

            // Automatic junction/branch hardware at real route intersections.
            val existingBoxes = filtered.filter { it.kind==ElementKind.JUNCTION_BOX }
            val autoJunctions = mutableListOf<RouteIntersection>()
            val cablePairs = cables.indices.flatMap { i -> ((i+1) until cables.size).map { j -> cables[i] to cables[j] } }
            cablePairs.forEach { (ca,cb) ->
                if (ca.floorId!=cb.floorId) return@forEach
                val pa=cableWorldRaw[ca.id].orEmpty(); val pb=cableWorldRaw[cb.id].orEmpty()
                pa.zipWithNext().forEach { (a,b) ->
                    pb.zipWithNext().forEach { (c,d) ->
                        val hit=segmentIntersectionXZ(a,b,c,d) ?: return@forEach
                        if (kotlin.math.abs(a.y-c.y) > 0.10f) return@forEach
                        val nearExisting=existingBoxes.any { box ->
                            if(box.floorId!=ca.floorId) false else {
                                val bp=point(box.start); val dx=bp.x-hit.first.x; val dz=bp.z-hit.first.z
                                sqrt(dx*dx+dz*dz) < 0.25f
                            }
                        }
                        if(!nearExisting && autoJunctions.none { j ->
                            val dx=j.point.x-hit.first.x; val dz=j.point.z-hit.first.z
                            sqrt(dx*dx+dz*dz) < 0.12f
                        }) {
                            val yaw=-Math.toDegrees(atan2((b.z-a.z).toDouble(),(b.x-a.x).toDouble())).toFloat()
                            autoJunctions += RouteIntersection(hit.first,ca.id,cb.id,hit.second,yaw)
                        }
                    }
                }
            }
            if(options.showBoxes && options.installationStage>=3){
                autoJunctions.forEachIndexed { idx,j ->
                    val size=if(j.isBranch)0.085f else 0.10f
                    primitives += Real3DPrimitive.Box(
                        id="auto-junction-$idx", category=Real3DCategory.DEVICE_BOX,
                        center=j.point, size=Real3DVec3(size,size,0.055f), yawDegrees=j.yawDegrees,
                        materialKey=if(j.isBranch)"branch-box" else "junction-box",
                        assetKey=if(j.isBranch)"conduit-t" else "junction-box"
                    )
                    val glandOffsets=if(j.isBranch) listOf(
                        Real3DVec3(size*0.58f,0f,0f),Real3DVec3(-size*0.58f,0f,0f),
                        Real3DVec3(0f,0f,size*0.58f)
                    ) else listOf(
                        Real3DVec3(size*0.58f,0f,0f),Real3DVec3(-size*0.58f,0f,0f),
                        Real3DVec3(0f,0f,size*0.58f),Real3DVec3(0f,0f,-size*0.58f)
                    )
                    glandOffsets.forEachIndexed { gi,o ->
                        primitives += Real3DPrimitive.Sphere(
                            id="auto-junction-gland-$idx-$gi", category=Real3DCategory.GLAND,
                            center=Real3DVec3(j.point.x+o.x,j.point.y+o.y,j.point.z+o.z),
                            radiusMeters=0.010f, materialKey="junction-gland"
                        )
                    }
                }
            }
        }

        // Electrical boxes and final apparatus are real volumetric geometry.
        filtered.filter { it.kind in setOf(
            ElementKind.SOCKET, ElementKind.SWITCH, ElementKind.TWO_WAY_SWITCH,
            ElementKind.CONTACTOR, ElementKind.JUNCTION_BOX, ElementKind.LIGHT
        ) }.forEach { e ->
            val q = point(e.start)
            val base = floorBase(e.floorId)
            val y = base + e.heightMeters
            if (options.showBoxes && options.installationStage >= 3 && e.kind != ElementKind.LIGHT) {
                val width = (e.boxDiameterMm / 1000f).coerceIn(0.04f, 0.15f)
                val depth = (e.boxDepthMm / 1000f).coerceIn(0.025f, 0.12f)
                val host = e.hostWallId?.let { id -> filtered.firstOrNull { it.id == id && it.kind == ElementKind.WALL && it.end != null } }
                val hostYaw = host?.let { w ->
                    val wa=point(w.start); val wb=point(w.end!!)
                    -Math.toDegrees(atan2((wb.z-wa.z).toDouble(), (wb.x-wa.x).toDouble())).toFloat()
                } ?: 0f
                val normal = host?.let { w ->
                    val wa=point(w.start); val wb=point(w.end!!); val dx=wb.x-wa.x; val dz=wb.z-wa.z
                    val l=hypot(dx.toDouble(),dz.toDouble()).toFloat().coerceAtLeast(0.001f)
                    Real3DVec3(-dz/l,0f,dx/l)
                } ?: Real3DVec3(0f,0f,1f)
                val embed=(e.embeddedDepthMm/1000f).coerceIn(0f,depth)
                val boxCenter=Real3DVec3(q.x-normal.x*embed*0.5f,y,q.z-normal.z*embed*0.5f)
                primitives += Real3DPrimitive.Box(
                    id = "box-${e.id}",
                    category = Real3DCategory.DEVICE_BOX,
                    circuitId = e.circuitId,
                    center = boxCenter,
                    size = Real3DVec3(width, width, depth),
                    yawDegrees = hostYaw,
                    materialKey = if(e.kind==ElementKind.JUNCTION_BOX) "junction-box" else "recessed-box",
                    assetKey = if(e.kind==ElementKind.JUNCTION_BOX) "junction-box" else "recessed-box"
                )
                // Thin rim/lid gives the box a recognisable chantier appearance.
                primitives += Real3DPrimitive.Box(
                    id = "box-rim-${e.id}", category = Real3DCategory.FITTING, circuitId = e.circuitId,
                    center = Real3DVec3(q.x+normal.x*0.006f,y,q.z+normal.z*0.006f),
                    size = Real3DVec3(width*1.08f,width*1.08f,0.008f), yawDegrees = hostYaw,
                    materialKey = if(e.kind==ElementKind.JUNCTION_BOX) "junction-box" else "box-rim"
                )
                val tangent=Real3DVec3(normal.z,0f,-normal.x)
                val enteringCables=filtered.filter {
                    it.kind==ElementKind.CABLE && e.id in it.connectedElementIds
                }.take(4)
                enteringCables.forEachIndexed { cableIndex,c ->
                    val lateral=(cableIndex-(enteringCables.size-1)/2f)*0.018f
                    primitives += Real3DPrimitive.Sphere(
                        id="device-gland-${e.id}-${c.id}",
                        category=Real3DCategory.GLAND,
                        circuitId=c.circuitId,
                        center=Real3DVec3(
                            q.x+tangent.x*lateral,
                            y+width*0.53f,
                            q.z+tangent.z*lateral
                        ),
                        radiusMeters=(c.conduitDiameterMm/2000f*1.20f).coerceIn(0.008f,0.018f),
                        materialKey=liveCircuitMaterial(c.circuitId,c.id,options),
                        assetKey="conduit-coupler",
                        rotationXDegrees=90f,
                        rotationYDegrees=hostYaw
                    )
                }
                // Lid screws and conduit entry glands are separate geometry for close-up chantier views.
                listOf(-1f,1f).forEach { sx ->
                    listOf(-1f,1f).forEach { sy ->
                        primitives += Real3DPrimitive.Sphere(
                            id="box-screw-${e.id}-$sx-$sy", category=Real3DCategory.SCREW, circuitId=e.circuitId,
                            center=Real3DVec3(
                                q.x + tangent.x*sx*width*0.34f + normal.x*0.011f,
                                y + sy*width*0.34f,
                                q.z + tangent.z*sx*width*0.34f + normal.z*0.011f
                            ),
                            radiusMeters=0.004f, materialKey="screw-metal"
                        )
                    }
                }
                if (e.kind==ElementKind.JUNCTION_BOX) {
                    listOf(-1f,1f).forEach { side ->
                        val gc=Real3DVec3(q.x+tangent.x*side*width*0.56f,y,q.z+tangent.z*side*width*0.56f)
                        primitives += Real3DPrimitive.Tube(
                            id="gland-${e.id}-$side", category=Real3DCategory.GLAND, circuitId=e.circuitId,
                            start=Real3DVec3(gc.x-tangent.x*0.018f,gc.y,gc.z-tangent.z*0.018f),
                            end=Real3DVec3(gc.x+tangent.x*0.018f,gc.y,gc.z+tangent.z*0.018f),
                            radiusMeters=(width*0.11f).coerceIn(0.008f,0.018f), materialKey=circuitMaterialKey(e.circuitId)
                        )
                    }
                }
            }
            if (options.installationStage >= 5) {
                when (e.kind) {
                    ElementKind.LIGHT -> primitives += Real3DPrimitive.Sphere(
                        id = "device-${e.id}", category = Real3DCategory.DEVICE,
                        circuitId = e.circuitId,
                        center = Real3DVec3(q.x, y, q.z), radiusMeters = 0.07f,
                        materialKey = if(options.simulationHighlight && e.id in options.energizedElementIds) "energized-device" else "light"
                    )
                    ElementKind.CONTACTOR -> primitives += Real3DPrimitive.Box(
                        id = "device-${e.id}", category = Real3DCategory.DEVICE,
                        circuitId = e.circuitId,
                        center = Real3DVec3(q.x, y, q.z), size = Real3DVec3(0.12f, 0.18f, 0.08f),
                        materialKey = if(options.simulationHighlight && e.id in options.energizedElementIds) "energized-device" else "contactor", assetKey = "contactor"
                    )
                    else -> primitives += Real3DPrimitive.Box(
                        id = "device-${e.id}", category = Real3DCategory.DEVICE,
                        circuitId = e.circuitId,
                        center = Real3DVec3(q.x, y, q.z), size = Real3DVec3(0.085f, 0.085f, 0.025f),
                        materialKey = "device",
                        assetKey = when(e.kind){
                            ElementKind.SOCKET -> "socket"
                            ElementKind.SWITCH -> "switch"
                            ElementKind.TWO_WAY_SWITCH -> "two-way-switch"
                            else -> null
                        }
                    )
                }
            }
        }

        filtered.filter { it.kind == ElementKind.PANEL }.forEach { e ->
            val q = point(e.start)
            val py=floorBase(e.floorId) + e.heightMeters
            val panelCables=filtered.filter { it.kind==ElementKind.CABLE && e.id in it.connectedElementIds }.take(10)
            panelCables.forEachIndexed { index,c ->
                val xOffset=(index-(panelCables.size-1)/2f)*0.035f
                primitives += Real3DPrimitive.Sphere(
                    id="panel-gland-${e.id}-${c.id}",
                    category=Real3DCategory.GLAND,
                    circuitId=c.circuitId,
                    center=Real3DVec3(q.x+xOffset,py+0.34f,q.z),
                    radiusMeters=(c.conduitDiameterMm/2000f*1.25f).coerceIn(0.009f,0.020f),
                    materialKey=liveCircuitMaterial(c.circuitId,c.id,options),
                    assetKey="conduit-coupler",
                    rotationXDegrees=90f
                )
            }
            primitives += Real3DPrimitive.Box(
                id = "panel-${e.id}", category = Real3DCategory.PANEL,
                center = Real3DVec3(q.x, py, q.z),
                size = Real3DVec3(0.45f, 0.65f, 0.14f), materialKey = "panel", assetKey = "panel"
            )
            // Simplified but volumetric DIN layout: two rails, breakers, N and PE bars.
            listOf(-0.13f,0.08f).forEachIndexed { row, dy ->
                primitives += Real3DPrimitive.Box(
                    id="din-${e.id}-$row", category=Real3DCategory.DIN_RAIL, center=Real3DVec3(q.x,py+dy,q.z-0.078f),
                    size=Real3DVec3(0.37f,0.018f,0.018f), materialKey="din-rail", assetKey="din-rail"
                )
                repeat(6) { b ->
                    primitives += Real3DPrimitive.Box(
                        id="breaker-${e.id}-$row-$b", category=Real3DCategory.BREAKER,
                        center=Real3DVec3(q.x-0.145f+b*0.058f,py+dy,q.z-0.095f),
                        size=Real3DVec3(0.052f,0.09f,0.055f), materialKey="breaker", assetKey="breaker"
                    )
                }
            }
            primitives += Real3DPrimitive.Box(
                id="terminal-n-${e.id}", category=Real3DCategory.TERMINAL, center=Real3DVec3(q.x-0.09f,py+0.23f,q.z-0.09f),
                size=Real3DVec3(0.15f,0.025f,0.025f), materialKey="terminal-neutral", assetKey="terminal-n"
            )
            primitives += Real3DPrimitive.Box(
                id="terminal-pe-${e.id}", category=Real3DCategory.TERMINAL, center=Real3DVec3(q.x+0.09f,py+0.23f,q.z-0.09f),
                size=Real3DVec3(0.15f,0.025f,0.025f), materialKey="terminal-earth", assetKey="terminal-pe"
            )
        }

        filtered.filter { it.kind == ElementKind.RISER }.forEach { e ->
            val q = point(e.start)
            val from = floorBase(e.floorId)
            val to = e.targetFloorId?.let(::floorBase) ?: (from + project.ceilingHeightMeters + 0.3f)
            primitives += Real3DPrimitive.Tube(
                id = "riser-${e.id}", category = Real3DCategory.RISER,
                start = Real3DVec3(q.x, minOf(from, to), q.z),
                end = Real3DVec3(q.x, maxOf(from, to), q.z),
                radiusMeters = 0.025f, materialKey = "riser"
            )
        }

        val widthMeters = ((maxXpx - minXpx) / project.pixelsPerMeter).coerceAtLeast(1f)
        val depthMeters = ((maxZpx - minZpx) / project.pixelsPerMeter).coerceAtLeast(1f)
        val maxElevation = project.floors.maxOfOrNull { it.elevationMeters } ?: 0f
        val heightMeters = maxElevation + project.ceilingHeightMeters
        return Real3DScene(
            primitives = primitives,
            center = Real3DVec3(0f, heightMeters / 2f, 0f),
            widthMeters = widthMeters,
            depthMeters = depthMeters,
            heightMeters = heightMeters.coerceAtLeast(project.ceilingHeightMeters)
        )
    }
}
