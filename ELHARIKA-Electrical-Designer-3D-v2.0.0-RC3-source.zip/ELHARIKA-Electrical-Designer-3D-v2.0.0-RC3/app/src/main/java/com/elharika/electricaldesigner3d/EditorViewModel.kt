package com.elharika.electricaldesigner3d

import android.app.Application
import android.content.ContentValues
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.round
import kotlin.math.sign

class EditorViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ProjectStore(app)

    var project = androidx.compose.runtime.mutableStateOf(store.load() ?: ElectricalProject()); private set
    var tool = androidx.compose.runtime.mutableStateOf(EditorTool.WALL); private set
    var viewMode = androidx.compose.runtime.mutableStateOf(ViewMode.VIEW_3D); private set
    var previewStart = androidx.compose.runtime.mutableStateOf<Offset?>(null); private set
    var previewEnd = androidx.compose.runtime.mutableStateOf<Offset?>(null); private set
    var previewPath = androidx.compose.runtime.mutableStateOf<List<Point2>>(emptyList()); private set
    var selectedId = androidx.compose.runtime.mutableStateOf<Long?>(null); private set
    var selectedIds = androidx.compose.runtime.mutableStateOf<Set<Long>>(emptySet()); private set
    var multiSelectMode = androidx.compose.runtime.mutableStateOf(false); private set
    var statusMessage = androidx.compose.runtime.mutableStateOf(""); private set
    var smartInkEnabled = androidx.compose.runtime.mutableStateOf(true); private set
    var showDimensions = androidx.compose.runtime.mutableStateOf(true); private set
    var sketchPlanMode = androidx.compose.runtime.mutableStateOf(false); private set
    var sketchStrokeCount = androidx.compose.runtime.mutableIntStateOf(0); private set
    var cameraYaw = androidx.compose.runtime.mutableFloatStateOf(35f); private set
    var cameraPitch = androidx.compose.runtime.mutableFloatStateOf(28f); private set
    var cameraZoom = androidx.compose.runtime.mutableFloatStateOf(1f); private set
    var cameraPanX = androidx.compose.runtime.mutableFloatStateOf(0f); private set
    var cameraPanY = androidx.compose.runtime.mutableFloatStateOf(0f); private set
    var wallView3D = androidx.compose.runtime.mutableStateOf(WallView3D.OPAQUE); private set
    var real3DEnabled = androidx.compose.runtime.mutableStateOf(true); private set
    var real3DQuality = androidx.compose.runtime.mutableStateOf(Real3DQuality.BALANCED); private set
    var showAllFloors3D = androidx.compose.runtime.mutableStateOf(true); private set
    var installation3DMode = androidx.compose.runtime.mutableStateOf(true); private set
    var constructionMode3D = androidx.compose.runtime.mutableStateOf(false); private set
    var showConduits3D = androidx.compose.runtime.mutableStateOf(true); private set
    var showDeviceLabels3D = androidx.compose.runtime.mutableStateOf(true); private set
    var isolatedCircuit3D = androidx.compose.runtime.mutableStateOf<Long?>(null); private set
    var hiddenCircuitIds3D = androidx.compose.runtime.mutableStateOf<Set<Long>>(emptySet()); private set
    var showBoxes3D = androidx.compose.runtime.mutableStateOf(true); private set
    var showMeasurements3D = androidx.compose.runtime.mutableStateOf(true); private set
    var cutaway3D = androidx.compose.runtime.mutableStateOf(false); private set
    var routeAnimationRunning = androidx.compose.runtime.mutableStateOf(false); private set
    var routeAnimationProgress = androidx.compose.runtime.mutableFloatStateOf(0f); private set
    var simulationEnabled = androidx.compose.runtime.mutableStateOf(false); private set
    var lastSimulation = androidx.compose.runtime.mutableStateOf(SimulationResult()); private set
    var showChases3D = androidx.compose.runtime.mutableStateOf(true); private set
    var showConductors3D = androidx.compose.runtime.mutableStateOf(true); private set
    var installationStage3D = androidx.compose.runtime.mutableIntStateOf(5); private set
    var selectionBoxStart = androidx.compose.runtime.mutableStateOf<Offset?>(null); private set
    var selectionBoxEnd = androidx.compose.runtime.mutableStateOf<Offset?>(null); private set

    private val undoStack = ArrayDeque<ElectricalProject>()
    private val redoStack = ArrayDeque<ElectricalProject>()
    private var currentStroke = mutableListOf<StrokePoint>()
    private var dragOrigin: Offset? = null
    private var draggedOriginal: DesignElement? = null
    private var cablePoints = mutableListOf<Point2>()
    private var sketchBuffer = mutableListOf<InkStroke>()
    private var draggedHandle: Int? = null
    private var clipboard: List<DesignElement> = emptyList()

    fun setTool(value: EditorTool) { tool.value = value; previewPath.value = emptyList(); if(value != EditorTool.SELECT) selectedIds.value = emptySet() }
    fun setViewMode(value: ViewMode) { viewMode.value = value }
    fun setActiveCircuit(id: Long) { project.value = project.value.copy(activeCircuitId = id); save() }
    fun setActiveFloor(id: Long) { if(project.value.floors.any{it.id==id}) { project.value=project.value.copy(activeFloorId=id); selectedId.value=null; selectedIds.value=emptySet(); save() } }
    fun setActiveLayer(id: Long) { if(project.value.layers.any{it.id==id}) { project.value=project.value.copy(activeLayerId=id); save() } }
    fun setSmartInk(enabled:Boolean){ smartInkEnabled.value=enabled }
    fun setShowDimensions(enabled:Boolean){ showDimensions.value=enabled }
    fun setWallView3D(mode:WallView3D){ wallView3D.value=mode }
    fun setReal3DEnabled(enabled:Boolean){ real3DEnabled.value=enabled }
    fun setReal3DQuality(value:Real3DQuality){ real3DQuality.value=value }
    fun setShowAllFloors3D(enabled:Boolean){ showAllFloors3D.value=enabled }
    fun setInstallation3DMode(enabled:Boolean){ installation3DMode.value=enabled }
    fun setConstructionMode3D(enabled:Boolean){ constructionMode3D.value=enabled }
    fun setShowConduits3D(enabled:Boolean){ showConduits3D.value=enabled }
    fun setShowDeviceLabels3D(enabled:Boolean){ showDeviceLabels3D.value=enabled }
    fun setIsolatedCircuit3D(id:Long?){ isolatedCircuit3D.value=id; routeAnimationProgress.floatValue=0f }
    fun toggleCircuitVisibility3D(id:Long){ hiddenCircuitIds3D.value = if(id in hiddenCircuitIds3D.value) hiddenCircuitIds3D.value - id else hiddenCircuitIds3D.value + id }
    fun showAllCircuits3D(){ hiddenCircuitIds3D.value=emptySet(); isolatedCircuit3D.value=null }
    fun setShowBoxes3D(enabled:Boolean){ showBoxes3D.value=enabled }
    fun setShowMeasurements3D(enabled:Boolean){ showMeasurements3D.value=enabled }
    fun setShowChases3D(enabled:Boolean){ showChases3D.value=enabled }
    fun setShowConductors3D(enabled:Boolean){ showConductors3D.value=enabled }
    fun setInstallationStage3D(stage:Int){ installationStage3D.intValue=stage.coerceIn(0,5) }
    fun setCutaway3D(enabled:Boolean){ cutaway3D.value=enabled }
    fun setRouteAnimationRunning(enabled:Boolean){ routeAnimationRunning.value=enabled; if(enabled) routeAnimationProgress.floatValue=0f }
    fun setRouteAnimationProgress(value:Float){ routeAnimationProgress.floatValue=value.coerceIn(0f,1f) }
    fun setSketchPlanMode(enabled:Boolean){ sketchPlanMode.value=enabled; if(!enabled){ sketchBuffer.clear(); sketchStrokeCount.intValue=0 } }
    fun setMultiSelectMode(enabled:Boolean){ multiSelectMode.value=enabled; if(!enabled && selectedIds.value.size>1){ selectedIds.value=setOfNotNull(selectedId.value) } }
    fun clearSketchBuffer(){ sketchBuffer.clear(); sketchStrokeCount.intValue=0; statusMessage.value="Sketch buffer cleared" }
    fun sketchPreview(): List<InkStroke> = sketchBuffer.toList()

    private fun checkpoint() { undoStack.addLast(project.value); while (undoStack.size > 40) undoStack.removeFirst(); redoStack.clear() }
    private fun save() {
        val p = project.value
        val ids = p.elements.map { it.id }.toSet()
        val cableIds = p.elements.filter { it.kind == ElementKind.CABLE }.map { it.id }.toSet()
        project.value = p.copy(
            wireLinks = p.wireLinks.filter { it.fromElementId in ids && it.toElementId in ids && it.cableId in cableIds },
            simulationStates = p.simulationStates.filter { it.elementId in ids },
            elements = p.elements.map { e -> e.copy(
                connectedElementIds = e.connectedElementIds.filter { it in ids },
                pairedElementId = e.pairedElementId?.takeIf { it in ids },
                controlElementId = e.controlElementId?.takeIf { it in ids },
                targetFloorId = e.targetFloorId?.takeIf { target -> p.floors.any { it.id == target } }
            ) }
        )
        store.save(project.value)
        if (simulationEnabled.value) runSimulation()
    }

    fun cancelInput() {
        currentStroke.clear(); cablePoints.clear()
        previewStart.value = null; previewEnd.value = null; previewPath.value = emptyList()
        selectionBoxStart.value = null; selectionBoxEnd.value = null
        if (draggedOriginal != null && undoStack.isNotEmpty()) project.value = undoStack.removeLast()
        dragOrigin = null; draggedOriginal = null; draggedHandle = null
    }

    fun undo() { if (undoStack.isEmpty()) return; redoStack.addLast(project.value); project.value = undoStack.removeLast(); save() }
    fun redo() { if (redoStack.isEmpty()) return; undoStack.addLast(project.value); project.value = redoStack.removeLast(); save() }
    fun clearProject() { checkpoint(); project.value = ElectricalProject(name = project.value.name); selectedId.value = null; selectedIds.value = emptySet(); save() }

    fun loadElectricalShowcase() {
        checkpoint()
        val walls = listOf(
            DesignElement(101, ElementKind.WALL, Point2(0f,0f), Point2(1000f,0f), wallThicknessMeters=.16f),
            DesignElement(102, ElementKind.WALL, Point2(1000f,0f), Point2(1000f,700f), wallThicknessMeters=.16f),
            DesignElement(103, ElementKind.WALL, Point2(1000f,700f), Point2(0f,700f), wallThicknessMeters=.16f),
            DesignElement(104, ElementKind.WALL, Point2(0f,700f), Point2(0f,0f), wallThicknessMeters=.16f),
            DesignElement(105, ElementKind.WALL, Point2(520f,0f), Point2(520f,700f), wallThicknessMeters=.14f),
            DesignElement(106, ElementKind.WALL, Point2(0f,360f), Point2(520f,360f), wallThicknessMeters=.14f),
            DesignElement(107, ElementKind.WALL, Point2(520f,310f), Point2(1000f,310f), wallThicknessMeters=.14f)
        )
        val openings = listOf(
            DesignElement(130, ElementKind.DOOR, Point2(520f,245f), Point2(520f,325f), label="Porte Salon", hostWallId=105L),
            DesignElement(131, ElementKind.DOOR, Point2(220f,360f), Point2(300f,360f), label="Porte Cuisine", hostWallId=106L),
            DesignElement(132, ElementKind.DOOR, Point2(690f,310f), Point2(770f,310f), label="Porte Chambres", hostWallId=107L),
            DesignElement(133, ElementKind.WINDOW, Point2(140f,0f), Point2(340f,0f), label="Fenêtre Salon", hostWallId=101L),
            DesignElement(134, ElementKind.WINDOW, Point2(660f,0f), Point2(860f,0f), label="Fenêtre Chambre", hostWallId=101L),
            DesignElement(135, ElementKind.WINDOW, Point2(120f,700f), Point2(330f,700f), label="Fenêtre Cuisine", hostWallId=103L),
            DesignElement(136, ElementKind.WINDOW, Point2(690f,700f), Point2(880f,700f), label="Fenêtre Chambre 2", hostWallId=103L)
        )
        val rooms = listOf(
            DesignElement(120, ElementKind.ROOM, Point2(15f,15f), Point2(505f,345f), label="Salon"),
            DesignElement(121, ElementKind.ROOM, Point2(15f,375f), Point2(505f,685f), label="Cuisine"),
            DesignElement(122, ElementKind.ROOM, Point2(535f,15f), Point2(985f,295f), label="Chambre 1"),
            DesignElement(123, ElementKind.ROOM, Point2(535f,325f), Point2(985f,685f), label="Chambre 2")
        )
        val panel = DesignElement(200, ElementKind.PANEL, Point2(520f,345f), label="TD-01", heightMeters=1.45f)
        val devices = listOf(
            DesignElement(210, ElementKind.SOCKET, Point2(110f,0f), label="PC-01", heightMeters=.30f, circuitId=1L, hostWallId=101L, wallMounted=true),
            DesignElement(211, ElementKind.SOCKET, Point2(390f,0f), label="PC-02", heightMeters=.30f, circuitId=1L, hostWallId=101L, wallMounted=true),
            DesignElement(212, ElementKind.SOCKET, Point2(110f,700f), label="PC-Cuisine", heightMeters=1.10f, circuitId=2L, hostWallId=103L, wallMounted=true),
            DesignElement(213, ElementKind.SOCKET, Point2(420f,700f), label="PC-Cuisine-2", heightMeters=1.10f, circuitId=2L, hostWallId=103L, wallMounted=true),
            DesignElement(214, ElementKind.SOCKET, Point2(820f,0f), label="PC-Ch1", heightMeters=.30f, circuitId=3L, hostWallId=101L, wallMounted=true),
            DesignElement(215, ElementKind.SOCKET, Point2(820f,700f), label="PC-Ch2", heightMeters=.30f, circuitId=3L, hostWallId=103L, wallMounted=true),
            DesignElement(216, ElementKind.SWITCH, Point2(520f,220f), label="I-Salon", heightMeters=1.10f, circuitId=4L, hostWallId=105L, wallMounted=true),
            DesignElement(217, ElementKind.SWITCH, Point2(205f,360f), label="I-Cuisine", heightMeters=1.10f, circuitId=4L, hostWallId=106L, wallMounted=true),
            DesignElement(218, ElementKind.TWO_WAY_SWITCH, Point2(675f,310f), label="VV-Chambres-A", heightMeters=1.10f, circuitId=4L, hostWallId=107L, wallMounted=true, pairedElementId=219L),
            DesignElement(219, ElementKind.TWO_WAY_SWITCH, Point2(785f,310f), label="VV-Chambres-B", heightMeters=1.10f, circuitId=4L, hostWallId=107L, wallMounted=true, pairedElementId=218L),
            DesignElement(220, ElementKind.LIGHT, Point2(260f,180f), label="L-Salon", heightMeters=2.62f, circuitId=4L),
            DesignElement(221, ElementKind.LIGHT, Point2(260f,520f), label="L-Cuisine", heightMeters=2.62f, circuitId=4L),
            DesignElement(222, ElementKind.LIGHT, Point2(760f,150f), label="L-Ch1", heightMeters=2.62f, circuitId=4L),
            DesignElement(223, ElementKind.LIGHT, Point2(760f,510f), label="L-Ch2", heightMeters=2.62f, circuitId=4L),
            DesignElement(230, ElementKind.JUNCTION_BOX, Point2(520f,180f), label="BD-01", heightMeters=2.45f, circuitId=1L, hostWallId=105L, wallMounted=true, boxDiameterMm=90f),
            DesignElement(231, ElementKind.JUNCTION_BOX, Point2(520f,520f), label="BD-02", heightMeters=2.45f, circuitId=2L, hostWallId=105L, wallMounted=true, boxDiameterMm=90f)
        )
        val cables = listOf(
            DesignElement(
                id=300, kind=ElementKind.CABLE, start=Point2(520f,345f), end=Point2(110f,0f),
                path=listOf(Point2(520f,345f),Point2(520f,180f),Point2(110f,180f),Point2(110f,0f)),
                label="C1-PC Salon", circuitId=1L, route=CableRoute.CEILING, cableSpec="3×2.5 mm²",
                connectedElementIds=listOf(200,230,210,211), conduitDiameterMm=20f, bendRadiusMm=80f
            ),
            DesignElement(
                id=301, kind=ElementKind.CABLE, start=Point2(520f,345f), end=Point2(110f,700f),
                path=listOf(Point2(520f,345f),Point2(520f,520f),Point2(110f,520f),Point2(110f,700f)),
                label="C2-Cuisine", circuitId=2L, route=CableRoute.CEILING, cableSpec="3×2.5 mm²",
                connectedElementIds=listOf(200,231,212,213), conduitDiameterMm=25f, bendRadiusMm=90f
            ),
            DesignElement(
                id=302, kind=ElementKind.CABLE, start=Point2(520f,345f), end=Point2(820f,0f),
                path=listOf(Point2(520f,345f),Point2(650f,345f),Point2(650f,120f),Point2(820f,120f),Point2(820f,0f),Point2(820f,700f)),
                label="C3-Chambres", circuitId=3L, route=CableRoute.CEILING, cableSpec="3×2.5 mm²",
                connectedElementIds=listOf(200,214,215), conduitDiameterMm=20f, bendRadiusMm=80f
            ),
            DesignElement(
                id=303, kind=ElementKind.CABLE, start=Point2(520f,345f), end=Point2(760f,510f),
                path=listOf(Point2(520f,345f),Point2(520f,260f),Point2(260f,260f),Point2(260f,180f),Point2(760f,180f),Point2(760f,510f)),
                label="C4-Eclairage", circuitId=4L, route=CableRoute.CEILING, cableSpec="3×1.5 mm²",
                connectedElementIds=listOf(200,216,217,218,219,220,221,222,223), conduitDiameterMm=16f, bendRadiusMm=60f
            )
        )
        project.value = ElectricalProject(
            name="Maison Démo Électrique",
            pixelsPerMeter=100f,
            ceilingHeightMeters=2.70f,
            elements=walls+rooms+openings+listOf(panel)+devices+cables,
            circuits=listOf(
                Circuit(1L,"C1 Prises Salon","3×2.5 mm²","C20",CableRoute.CEILING),
                Circuit(2L,"C2 Cuisine","3×2.5 mm²","C20",CableRoute.CEILING),
                Circuit(3L,"C3 Chambres","3×2.5 mm²","C20",CableRoute.CEILING),
                Circuit(4L,"C4 Éclairage","3×1.5 mm²","C10",CableRoute.CEILING)
            ),
            activeCircuitId=1L
        )
        selectedId.value=null
        selectedIds.value=emptySet()
        isolatedCircuit3D.value=null
        hiddenCircuitIds3D.value=emptySet()
        viewMode.value=ViewMode.VIEW_3D
        real3DEnabled.value=true
        showConduits3D.value=true
        showConductors3D.value=true
        showBoxes3D.value=true
        installationStage3D.intValue=5
        real3DQuality.value=Real3DQuality.BALANCED
        save()
    }

    fun onInputDown(pos: Offset, pressure: Float, isStylus: Boolean) {
        when (tool.value) {
            EditorTool.PEN -> currentStroke = mutableListOf(StrokePoint(pos.x, pos.y, pressure.coerceIn(.1f, 1.5f)))
            EditorTool.WALL, EditorTool.ROOM, EditorTool.DOOR, EditorTool.WINDOW, EditorTool.STAIRCASE -> { val sp=if(tool.value==EditorTool.WALL)smartSnapPoint(pos) else snap(pos); previewStart.value = sp; previewEnd.value = sp }
            EditorTool.CABLE -> { val p = snap(pos).toPoint(); cablePoints = mutableListOf(p); previewPath.value = cablePoints.toList() }
            EditorTool.SOCKET, EditorTool.SWITCH, EditorTool.TWO_WAY_SWITCH, EditorTool.CONTACTOR, EditorTool.LIGHT, EditorTool.PANEL, EditorTool.JUNCTION_BOX, EditorTool.RISER -> placeSymbol(pos)
            EditorTool.ERASER -> eraseNearest(pos)
            EditorTool.SELECT -> {
                val found = selectNearest(pos)
                if(found == null){
                    selectionBoxStart.value = pos; selectionBoxEnd.value = pos
                    if(!multiSelectMode.value) clearSelection()
                } else {
                    val selected = project.value.elements.firstOrNull { it.id == selectedId.value }
                    if(selected != null && !project.value.isLocked(selected) && selected.end != null && selected.kind in listOf(ElementKind.WALL,ElementKind.DOOR,ElementKind.WINDOW,ElementKind.STAIRCASE)){
                        val ds=distance(selected.start.offset(),pos); val de=distance(selected.end.offset(),pos)
                        if(minOf(ds,de)<30f){ checkpoint(); draggedOriginal=selected; draggedHandle=if(ds<=de)0 else 1; dragOrigin=pos }
                        else if(distanceTo(selected,pos)<55f){ checkpoint(); dragOrigin=pos; draggedOriginal=selected; draggedHandle=null }
                    } else if (selected != null && !project.value.isLocked(selected) && distanceTo(selected, pos) < 55f) { checkpoint(); dragOrigin = pos; draggedOriginal = selected; draggedHandle=null }
                }
            }
        }
    }

    fun onInputMove(pos: Offset, pressure: Float) {
        when (tool.value) {
            EditorTool.PEN -> if (currentStroke.isNotEmpty()) currentStroke.add(StrokePoint(pos.x, pos.y, pressure.coerceIn(.1f, 1.5f)))
            EditorTool.WALL, EditorTool.ROOM, EditorTool.DOOR, EditorTool.WINDOW, EditorTool.STAIRCASE -> { val raw=smartLine(previewStart.value ?: pos,snap(pos)); previewEnd.value=if(tool.value==EditorTool.WALL)smartSnapPoint(raw) else raw }
            EditorTool.CABLE -> addCablePoint(pos)
            EditorTool.SELECT -> if(selectionBoxStart.value!=null) selectionBoxEnd.value=pos else moveDragged(pos)
            else -> Unit
        }
    }

    fun onInputUp(pos: Offset, pressure: Float) {
        when (tool.value) {
            EditorTool.PEN -> {
                if (currentStroke.size > 1) {
                    if(sketchPlanMode.value){
                        val stroke=InkStroke(System.nanoTime(),currentStroke.toList()); sketchBuffer.add(stroke); sketchStrokeCount.intValue=sketchBuffer.size; statusMessage.value="Sketch stroke ${sketchBuffer.size} captured"
                    } else {
                        val recognized = if(smartInkEnabled.value) recognizeStroke(currentStroke) else null
                        if(recognized != null) { checkpoint(); placeRecognizedSketch(recognized, currentStroke); statusMessage.value = "S Pen recognized: ${recognized.first.name.lowercase()}" }
                        else { checkpoint(); project.value = project.value.copy(ink = project.value.ink + InkStroke(System.nanoTime(), currentStroke.toList())); save(); statusMessage.value = if(smartInkEnabled.value) "Free ink kept" else "Ink stroke saved" }
                    }
                }
                currentStroke.clear()
            }
            EditorTool.WALL, EditorTool.ROOM, EditorTool.DOOR, EditorTool.WINDOW, EditorTool.STAIRCASE -> commitLineOrRoom()
            EditorTool.CABLE -> commitCablePath(pos)
            EditorTool.SELECT -> {
                if(selectionBoxStart.value!=null){ applySelectionBox(); selectionBoxStart.value=null; selectionBoxEnd.value=null }
                else if (draggedOriginal != null) save()
                dragOrigin = null; draggedOriginal = null; draggedHandle=null
            }
            else -> Unit
        }
        previewStart.value = null; previewEnd.value = null; previewPath.value = emptyList()
    }

    private fun commitLineOrRoom() {
        val a = previewStart.value ?: return; val b = previewEnd.value ?: return
        if (hypot((b.x-a.x).toDouble(), (b.y-a.y).toDouble()) < 24.0) return
        checkpoint()
        if (tool.value == EditorTool.ROOM) {
            val x1=minOf(a.x,b.x); val y1=minOf(a.y,b.y); val x2=maxOf(a.x,b.x); val y2=maxOf(a.y,b.y)
            val roomId=System.nanoTime(); val thickness=project.value.defaultWallThicknessMeters
            val walls=listOf(
                DesignElement(roomId+1,ElementKind.WALL,Point2(x1,y1),Point2(x2,y1),"Room wall",wallThicknessMeters=thickness,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId),
                DesignElement(roomId+2,ElementKind.WALL,Point2(x2,y1),Point2(x2,y2),"Room wall",wallThicknessMeters=thickness,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId),
                DesignElement(roomId+3,ElementKind.WALL,Point2(x2,y2),Point2(x1,y2),"Room wall",wallThicknessMeters=thickness,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId),
                DesignElement(roomId+4,ElementKind.WALL,Point2(x1,y2),Point2(x1,y1),"Room wall",wallThicknessMeters=thickness,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId)
            )
            val room=DesignElement(roomId,ElementKind.ROOM,Point2(x1,y1),Point2(x2,y2),"Room ${project.value.activeElements().count{it.kind==ElementKind.ROOM}+1}",floorId=project.value.activeFloorId,layerId=project.value.activeLayerId,roomWallIds=walls.map{it.id})
            project.value=project.value.copy(elements=project.value.elements+room+walls); selectedId.value=room.id; save(); return
        }
        if (tool.value == EditorTool.STAIRCASE) {
            val item=DesignElement(System.nanoTime(),ElementKind.STAIRCASE,a.toPoint(),b.toPoint(),"Staircase",heightMeters=project.value.ceilingHeightMeters,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId,targetFloorId=project.value.floors.sortedBy{it.elevationMeters}.firstOrNull{it.elevationMeters>(project.value.floor(project.value.activeFloorId)?.elevationMeters?:0f)}?.id)
            project.value=project.value.copy(elements=project.value.elements+item); selectedId.value=item.id; save(); return
        }
        val kind = when(tool.value) { EditorTool.WALL -> ElementKind.WALL; EditorTool.DOOR -> ElementKind.DOOR; else -> ElementKind.WINDOW }
        val host = if(kind==ElementKind.DOOR || kind==ElementKind.WINDOW) nearestWallForSegment(a,b) else null
        val (sa,sb) = if(host!=null) projectSegmentOntoWall(a,b,host) else Pair(a,b)
        val item = DesignElement(
            System.nanoTime(), kind, Point2(sa.x,sa.y), Point2(sb.x,sb.y),
            label = when(kind){ ElementKind.WALL->"Wall"; ElementKind.DOOR->"Door"; else->"Window" },
            heightMeters = if(kind==ElementKind.WINDOW) 1.10f else 0f,
            hostWallId = host?.id,
            wallThicknessMeters = project.value.defaultWallThicknessMeters,
            floorId = project.value.activeFloorId,
            layerId = project.value.activeLayerId
        )
        project.value = project.value.copy(elements = project.value.elements + item); selectedId.value = item.id
        if(kind==ElementKind.WALL) detectRectangularRooms()
        save()
    }

    private fun addCablePoint(pos: Offset) {
        if(cablePoints.isEmpty()) return
        val raw=snap(pos); val last=cablePoints.last().offset(); val smart=smartLine(last,raw).toPoint()
        if(distance(last,smart.offset()) >= 25f) {
            if(cablePoints.size==1 || distance(cablePoints.last().offset(),smart.offset())>=25f) cablePoints.add(smart)
            if(cablePoints.size>60) cablePoints.removeAt(1)
        } else if(cablePoints.size==1) { previewPath.value=listOf(cablePoints.first(),smart); return }
        previewPath.value=simplifyOrthogonal(cablePoints)
    }

    private fun commitCablePath(pos: Offset) {
        if(cablePoints.isEmpty()) return
        val end=snap(pos).toPoint(); if(distance(cablePoints.last().offset(),end.offset())>10f) cablePoints.add(end)
        val rawPts=simplifyOrthogonal(cablePoints).distinctAdjacent(); cablePoints.clear()
        val circuit=project.value.circuit(project.value.activeCircuitId)
        val pts=if((circuit?.route?:CableRoute.WALL)==CableRoute.WALL) conformPathToWalls(rawPts,project.value.activeFloorId) else rawPts
        if(pts.size<2 || project.value.pathMeters(pts)<.2f) return
        checkpoint(); val links=findEndpointConnections(pts.first(),pts.last())
        val item=DesignElement(System.nanoTime(),ElementKind.CABLE,pts.first(),pts.last(),circuit?.name?:"Circuit",cableSpec=circuit?.cableSpec.orEmpty(),circuitId=circuit?.id,route=circuit?.route?:CableRoute.WALL,path=pts,connectedElementIds=links,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId,wallMounted=(circuit?.route?:CableRoute.WALL)==CableRoute.WALL,conductorCount=inferConductorCount(circuit?.cableSpec.orEmpty()),conductorSectionMm2=inferSectionMm2(circuit?.cableSpec.orEmpty()))
        project.value=project.value.copy(elements=project.value.elements+item); selectedId.value=item.id; save()
    }

    private fun placeSymbol(pos: Offset) {
        checkpoint(); val kind = when(tool.value){
            EditorTool.SOCKET->ElementKind.SOCKET
            EditorTool.SWITCH->ElementKind.SWITCH
            EditorTool.TWO_WAY_SWITCH->ElementKind.TWO_WAY_SWITCH
            EditorTool.CONTACTOR->ElementKind.CONTACTOR
            EditorTool.LIGHT->ElementKind.LIGHT
            EditorTool.PANEL->ElementKind.PANEL
            EditorTool.JUNCTION_BOX->ElementKind.JUNCTION_BOX
            EditorTool.RISER->ElementKind.RISER
            else->return
        }
        val label = when(kind){ ElementKind.SOCKET->"Prise 2P+T"; ElementKind.SWITCH->"Interrupteur"; ElementKind.TWO_WAY_SWITCH->"Va-et-vient"; ElementKind.CONTACTOR->"Contacteur"; ElementKind.LIGHT->"Point lumineux"; ElementKind.JUNCTION_BOX->"Boîte de dérivation"; ElementKind.RISER->"Vertical riser"; else->"Tableau TD01" }
        val height = when(kind){ ElementKind.SOCKET->.30f; ElementKind.SWITCH->1.10f; ElementKind.TWO_WAY_SWITCH->1.10f; ElementKind.CONTACTOR->1.50f; ElementKind.LIGHT->project.value.ceilingHeightMeters; ElementKind.JUNCTION_BOX->2.20f; ElementKind.RISER->0f; else->1.50f }
        val snapped=snap(pos)
        val host=if(kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.JUNCTION_BOX)) nearestWallForPoint(snapped) else null
        val mountedPoint=host?.let{projectPointOntoWall(snapped,it)} ?: snapped
        val circuitId=if(kind==ElementKind.PANEL || kind==ElementKind.RISER)null else project.value.activeCircuitId
        val item=DesignElement(System.nanoTime(),kind,Point2(mountedPoint.x,mountedPoint.y),label=label,heightMeters=height,circuitId=circuitId,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId,targetFloorId=if(kind==ElementKind.RISER)nextFloorId()else null,hostWallId=host?.id,wallMounted=host!=null,embeddedDepthMm=if(host!=null)minOf(50f,host.wallThicknessMeters*1000f*.75f)else 25f)
        project.value=project.value.copy(elements=project.value.elements+item); selectedId.value=item.id; save()
    }

    private fun selectNearest(pos: Offset): Long? {
        val candidates = project.value.visibleActiveElements().filterNot { project.value.isLocked(it) }
        val foundElement = candidates.minByOrNull { distanceTo(it,pos) }?.takeIf { distanceTo(it,pos)<55f }
        val found = foundElement?.id
        if(foundElement?.groupId != null){
            val groupIds = candidates.filter { it.groupId == foundElement.groupId }.map { it.id }.toSet()
            selectedIds.value = if(multiSelectMode.value) selectedIds.value + groupIds else groupIds
            selectedId.value = found
            return found
        }
        if(multiSelectMode.value){
            if(found==null) return null
            val next=selectedIds.value.toMutableSet(); if(!next.add(found)) next.remove(found)
            selectedIds.value=next; selectedId.value=next.lastOrNull()
        } else {
            selectedId.value = found
            selectedIds.value = if(found==null) emptySet() else setOf(found)
        }
        return found
    }

    private fun applySelectionBox(){
        val a=selectionBoxStart.value?:return; val b=selectionBoxEnd.value?:a
        val left=minOf(a.x,b.x); val right=maxOf(a.x,b.x); val top=minOf(a.y,b.y); val bottom=maxOf(a.y,b.y)
        if(right-left<8f && bottom-top<8f) return
        val hits=project.value.visibleActiveElements().filterNot{project.value.isLocked(it)}.filter{ e ->
            val pts=e.geometryPoints().ifEmpty{listOf(e.start)}
            val minX=pts.minOf{it.x}; val maxX=pts.maxOf{it.x}; val minY=pts.minOf{it.y}; val maxY=pts.maxOf{it.y}
            maxX>=left && minX<=right && maxY>=top && minY<=bottom
        }
        val expanded=hits.flatMap{h-> if(h.groupId==null) listOf(h.id) else project.value.visibleActiveElements().filter{it.groupId==h.groupId}.map{it.id} }.toSet()
        selectedIds.value=if(multiSelectMode.value) selectedIds.value+expanded else expanded
        selectedId.value=expanded.lastOrNull(); statusMessage.value="${expanded.size} element(s) box-selected"
    }

    fun toggleMultiSelect(id: Long) {
        val next = selectedIds.value.toMutableSet()
        if(!next.add(id)) next.remove(id)
        selectedIds.value = next
        selectedId.value = next.lastOrNull()
    }

    fun selectAllOnFloor() {
        val ids = project.value.visibleActiveElements().filterNot{project.value.isLocked(it)}.map { it.id }.toSet()
        selectedIds.value = ids
        selectedId.value = ids.lastOrNull()
        statusMessage.value = "${ids.size} elements selected"
    }

    fun clearSelection() { selectedIds.value = emptySet(); selectedId.value = null }
    private fun eraseNearest(pos: Offset) { val target=project.value.visibleActiveElements().filterNot{project.value.isLocked(it)}.minByOrNull { distanceTo(it,pos) }; if(target!=null&&distanceTo(target,pos)<55f){ checkpoint(); project.value=project.value.copy(elements=project.value.elements.filterNot{it.id==target.id || it.hostWallId==target.id}); selectedId.value=null; selectedIds.value=emptySet(); save() } }

    private fun moveDragged(pos: Offset) {
        val original=draggedOriginal?:return
        val handle=draggedHandle
        if(handle!=null && original.end!=null){
            var np=if(original.kind==ElementKind.WALL) smartSnapPoint(snap(pos)) else snap(pos)
            var updated=if(handle==0) original.copy(start=np.toPoint()) else original.copy(end=np.toPoint())
            if(original.kind in listOf(ElementKind.DOOR,ElementKind.WINDOW) && original.hostWallId!=null){
                val wall=project.value.elements.firstOrNull{it.id==original.hostWallId}
                if(wall?.end!=null){ val pair=projectSegmentOntoWall(updated.start.offset(),updated.end!!.offset(),wall); updated=updated.copy(start=pair.first.toPoint(),end=pair.second.toPoint()) }
            }
            project.value=project.value.copy(elements=project.value.elements.map{ e ->
                when {
                    e.id==original.id -> updated
                    original.kind==ElementKind.WALL && e.hostWallId==original.id -> remapHostedElement(e, original, updated)
                    else -> e
                }
            }); return
        }
        val origin=dragOrigin?:return; val dx=pos.x-origin.x; val dy=pos.y-origin.y
        val moved=original.copy(start=Point2(original.start.x+dx,original.start.y+dy),end=original.end?.let{Point2(it.x+dx,it.y+dy)},path=original.path.map{Point2(it.x+dx,it.y+dy)})
        val roomWalls=if(original.kind==ElementKind.ROOM) original.roomWallIds.toSet() else emptySet()
        project.value=project.value.copy(elements=project.value.elements.map{ e ->
            when {
                e.id==original.id -> moved
                original.kind==ElementKind.WALL && e.hostWallId==original.id -> translateElement(e,dx,dy)
                original.kind==ElementKind.ROOM && e.id in roomWalls -> translateElement(e,dx,dy)
                original.kind==ElementKind.ROOM && e.hostWallId in roomWalls -> translateElement(e,dx,dy)
                else -> e
            }
        })
    }

    private fun translateElement(e:DesignElement,dx:Float,dy:Float)=e.copy(
        start=Point2(e.start.x+dx,e.start.y+dy),
        end=e.end?.let{Point2(it.x+dx,it.y+dy)},
        path=e.path.map{Point2(it.x+dx,it.y+dy)}
    )

    fun copySelected() {
        val ids = expandedSelectionIds()
        clipboard = project.value.elements.filter { it.id in ids }
        statusMessage.value = if(clipboard.isEmpty()) "Nothing selected" else "${clipboard.size} element(s) copied"
    }

    fun cutSelected() {
        copySelected(); if(clipboard.isEmpty()) return
        checkpoint(); val ids=clipboard.map{it.id}.toSet()
        project.value=project.value.copy(elements=project.value.elements.filterNot{ it.id in ids || it.hostWallId in ids })
        clearSelection(); save(); statusMessage.value="${clipboard.size} element(s) cut"
    }

    fun pasteClipboard() {
        if(clipboard.isEmpty()){ statusMessage.value="Clipboard is empty"; return }
        checkpoint()
        val base=System.nanoTime(); val idMap=clipboard.mapIndexed{index,e->e.id to (base+index+1)}.toMap(); val dx=35f; val dy=35f
        val copies=clipboard.map{e->e.copy(
            id=idMap[e.id]!!,
            start=Point2(e.start.x+dx,e.start.y+dy),
            end=e.end?.let{Point2(it.x+dx,it.y+dy)},
            path=e.path.map{Point2(it.x+dx,it.y+dy)},
            connectedElementIds=e.connectedElementIds.mapNotNull{oldId->idMap[oldId]},
            hostWallId=e.hostWallId?.let{idMap[it] ?: it},
            groupId=e.groupId?.let{idMap[it] ?: (base + 100000 + kotlin.math.abs(it % 9999))},
            roomWallIds=e.roomWallIds.mapNotNull{idMap[it]},
            pairedElementId=e.pairedElementId?.let(idMap::get),
            controlElementId=e.controlElementId?.let(idMap::get),
            floorId=project.value.activeFloorId,
            layerId=project.value.activeLayerId,
            isHidden=false
        )}
        project.value=project.value.copy(elements=project.value.elements+copies)
        selectedIds.value=copies.map{it.id}.toSet(); selectedId.value=copies.lastOrNull()?.id; save(); statusMessage.value="${copies.size} element(s) pasted"
    }

    private fun expandedSelectionIds(): Set<Long> {
        val base=if(selectedIds.value.isNotEmpty())selectedIds.value else setOfNotNull(selectedId.value)
        val groupIds=project.value.elements.filter{it.id in base}.mapNotNull{it.groupId}.toSet()
        val grouped=project.value.elements.filter{it.groupId in groupIds}.map{it.id}
        val hosted=project.value.elements.filter{it.hostWallId in base}.map{it.id}
        return (base + grouped + hosted).toSet()
    }

    private fun selectedElements(): List<DesignElement> {
        val ids=expandedSelectionIds()
        return project.value.activeElements().filter{it.id in ids}
    }

    fun groupSelected(){
        val ids=if(selectedIds.value.isNotEmpty())selectedIds.value else setOfNotNull(selectedId.value); if(ids.size<2){statusMessage.value="Select at least 2 elements";return}
        checkpoint(); val gid=System.nanoTime(); project.value=project.value.copy(elements=project.value.elements.map{if(it.id in ids)it.copy(groupId=gid)else it}); save(); statusMessage.value="${ids.size} elements grouped"
    }
    fun ungroupSelected(){
        val ids=expandedSelectionIds(); if(ids.isEmpty())return; checkpoint(); project.value=project.value.copy(elements=project.value.elements.map{if(it.id in ids)it.copy(groupId=null)else it}); save(); statusMessage.value="Selection ungrouped"
    }
    fun setSelectedLocked(locked:Boolean){
        val ids=expandedSelectionIds(); if(ids.isEmpty())return; checkpoint(); project.value=project.value.copy(elements=project.value.elements.map{if(it.id in ids)it.copy(isLocked=locked)else it}); save(); statusMessage.value=if(locked)"Selection locked" else "Selection unlocked"
    }
    fun toggleSelectedLocked(){
        val ids=expandedSelectionIds(); if(ids.isEmpty())return; val lockTo=!project.value.elements.filter{it.id in ids}.all{it.isLocked}; setSelectedLocked(lockTo)
    }
    fun setSelectedHidden(hidden:Boolean){
        val ids=expandedSelectionIds(); if(ids.isEmpty())return; checkpoint(); project.value=project.value.copy(elements=project.value.elements.map{if(it.id in ids)it.copy(isHidden=hidden)else it}); if(hidden) clearSelection(); save(); statusMessage.value=if(hidden)"Selection hidden" else "Selection shown"
    }
    fun unhideAllOnFloor(){ checkpoint(); project.value=project.value.copy(elements=project.value.elements.map{if(it.floorId==project.value.activeFloorId)it.copy(isHidden=false)else it}); save(); statusMessage.value="All elements shown on floor" }

    fun addLayer(name:String="Layer ${project.value.layers.size+1}"){ checkpoint(); val id=System.nanoTime(); project.value=project.value.copy(layers=project.value.layers+DesignLayer(id,name),activeLayerId=id); save() }
    fun toggleLayerVisibility(id:Long){ checkpoint(); project.value=project.value.copy(layers=project.value.layers.map{if(it.id==id)it.copy(visible=!it.visible)else it}); clearSelection(); save() }
    fun toggleLayerLock(id:Long){ checkpoint(); project.value=project.value.copy(layers=project.value.layers.map{if(it.id==id)it.copy(locked=!it.locked)else it}); clearSelection(); save() }
    fun moveSelectedToLayer(id:Long){ if(project.value.layers.none{it.id==id})return; val ids=expandedSelectionIds(); if(ids.isEmpty())return; checkpoint(); project.value=project.value.copy(elements=project.value.elements.map{if(it.id in ids)it.copy(layerId=id)else it}); save(); statusMessage.value="Selection moved to ${project.value.layer(id)?.name ?: "layer"}" }


    fun rotateSelected90() {
        val items=selectedElements(); if(items.isEmpty()) return
        checkpoint(); val cx=items.map{it.start.x}.average().toFloat(); val cy=items.map{it.start.y}.average().toFloat()
        fun rp(p:Point2)=Point2(cx-(p.y-cy),cy+(p.x-cx))
        val ids=items.map{it.id}.toSet()
        project.value=project.value.copy(elements=project.value.elements.map{e->if(e.id in ids)e.copy(start=rp(e.start),end=e.end?.let(::rp),path=e.path.map(::rp))else e}); save(); statusMessage.value="Selection rotated 90°"
    }

    fun alignSelectedLeft() {
        val items=selectedElements(); if(items.size<2)return
        checkpoint(); val x=items.minOf{it.start.x}; val ids=items.map{it.id}.toSet()
        project.value=project.value.copy(elements=project.value.elements.map{e->if(e.id in ids){val d=x-e.start.x;e.copy(start=Point2(e.start.x+d,e.start.y),end=e.end?.let{Point2(it.x+d,it.y)},path=e.path.map{Point2(it.x+d,it.y)})}else e}); save(); statusMessage.value="Aligned left"
    }

    fun alignSelectedTop() {
        val items=selectedElements(); if(items.size<2)return
        checkpoint(); val y=items.minOf{it.start.y}; val ids=items.map{it.id}.toSet()
        project.value=project.value.copy(elements=project.value.elements.map{e->if(e.id in ids){val d=y-e.start.y;e.copy(start=Point2(e.start.x,e.start.y+d),end=e.end?.let{Point2(it.x,it.y+d)},path=e.path.map{Point2(it.x,it.y+d)})}else e}); save(); statusMessage.value="Aligned top"
    }

    fun distributeSelectedHorizontally() {
        val items=selectedElements().sortedBy{it.start.x}; if(items.size<3)return
        checkpoint(); val min=items.first().start.x; val max=items.last().start.x; val step=(max-min)/(items.size-1); val target=items.mapIndexed{i,e->e.id to (min+i*step)}.toMap()
        project.value=project.value.copy(elements=project.value.elements.map{e->target[e.id]?.let{x->val d=x-e.start.x;e.copy(start=Point2(e.start.x+d,e.start.y),end=e.end?.let{Point2(it.x+d,it.y)},path=e.path.map{Point2(it.x+d,it.y)})}?:e}); save(); statusMessage.value="Distributed horizontally"
    }

    fun repairRoomWallLinks() {
        checkpoint(); val floor=project.value.activeFloorId; val walls=project.value.activeElements().filter{it.kind==ElementKind.WALL && it.end!=null}
        var fixed=0
        project.value=project.value.copy(elements=project.value.elements.map{e->
            if(e.floorId!=floor || e.kind!=ElementKind.ROOM || e.end==null) e else {
                val x1=minOf(e.start.x,e.end.x); val x2=maxOf(e.start.x,e.end.x); val y1=minOf(e.start.y,e.end.y); val y2=maxOf(e.start.y,e.end.y)
                val corners=listOf(Point2(x1,y1) to Point2(x2,y1),Point2(x2,y1) to Point2(x2,y2),Point2(x2,y2) to Point2(x1,y2),Point2(x1,y2) to Point2(x1,y1))
                val ids=corners.mapNotNull{(a,b)->walls.minByOrNull{w->distanceToSegment(w.start,w.end!!,a.offset())+distanceToSegment(w.start,w.end!!,b.offset())}?.takeIf{w->distanceToSegment(w.start,w.end!!,a.offset())<18f && distanceToSegment(w.start,w.end!!,b.offset())<18f}?.id}.distinct()
                if(ids.isNotEmpty() && ids!=e.roomWallIds){fixed++;e.copy(roomWallIds=ids)} else e
            }
        }); save(); statusMessage.value="Room-wall links repaired: $fixed"
    }

    fun splitSelectedWall() {
        val wall=project.value.elements.firstOrNull{it.id==selectedId.value && it.kind==ElementKind.WALL && it.end!=null} ?: run { statusMessage.value="Select one wall"; return }
        val end=wall.end!!; val mid=Point2((wall.start.x+end.x)/2f,(wall.start.y+end.y)/2f)
        checkpoint(); val id2=System.nanoTime()
        val a=wall.copy(end=mid); val b=wall.copy(id=id2,start=mid,end=end,hostWallId=null)
        val children=project.value.elements.filter{it.hostWallId==wall.id}
        val mappedChildren=children.map{child->
            val center=child.end?.let{Point2((child.start.x+it.x)/2f,(child.start.y+it.y)/2f)} ?: child.start
            val dA=distanceToSegment(a.start,a.end!!,center.offset()); val dB=distanceToSegment(b.start,b.end!!,center.offset())
            child.copy(hostWallId=if(dA<=dB)a.id else b.id)
        }
        project.value=project.value.copy(elements=project.value.elements.map{e->when{e.id==wall.id->a; children.any{it.id==e.id}->mappedChildren.first{it.id==e.id}; e.kind==ElementKind.ROOM && wall.id in e.roomWallIds->e.copy(roomWallIds=e.roomWallIds.flatMap{if(it==wall.id)listOf(a.id,b.id) else listOf(it)}); else->e}}+b)
        selectedId.value=b.id; selectedIds.value=setOf(a.id,b.id); save(); statusMessage.value="Wall split into 2 segments"
    }

    fun setSelectedWallLengthMeters(meters:Float) {
        val wall=project.value.elements.firstOrNull{it.id==selectedId.value && it.kind==ElementKind.WALL && it.end!=null} ?: return
        val target=meters.coerceIn(.10f,50f)*project.value.pixelsPerMeter; val e=wall.end!!; val dx=e.x-wall.start.x; val dy=e.y-wall.start.y; val len=hypot(dx.toDouble(),dy.toDouble()).toFloat(); if(len<1f)return
        val updated=wall.copy(end=Point2(wall.start.x+dx/len*target,wall.start.y+dy/len*target))
        checkpoint(); project.value=project.value.copy(elements=project.value.elements.map{x->when{ x.id==wall.id->updated; x.hostWallId==wall.id->remapHostedElement(x,wall,updated); else->x }});save();statusMessage.value="Wall length set to ${"%.2f".format(meters)} m"
    }

    fun trimExtendSelectedWallToNearest() {
        val wall=project.value.elements.firstOrNull{it.id==selectedId.value && it.kind==ElementKind.WALL && it.end!=null} ?: run{statusMessage.value="Select one wall";return}
        val candidates=project.value.activeElements().filter{it.kind==ElementKind.WALL && it.id!=wall.id && it.end!=null}
        data class Hit(val p:Point2,val endpoint:Int,val distance:Float)
        val hits=mutableListOf<Hit>()
        for(other in candidates){
            val p=lineIntersection(wall.start,wall.end!!,other.start,other.end!!)?:continue
            if(distanceToSegment(other.start,other.end!!,p.offset())>2f)continue
            val d0=distance(wall.start.offset(),p.offset()); val d1=distance(wall.end!!.offset(),p.offset()); val which=if(d0<=d1)0 else 1; val d=minOf(d0,d1)
            if(d<=project.value.pixelsPerMeter*4f)hits+=Hit(p,which,d)
        }
        val hit=hits.minByOrNull{it.distance}?:run{statusMessage.value="No nearby wall intersection";return}
        val updated=if(hit.endpoint==0)wall.copy(start=hit.p)else wall.copy(end=hit.p)
        checkpoint();project.value=project.value.copy(elements=project.value.elements.map{x->when{x.id==wall.id->updated;x.hostWallId==wall.id->remapHostedElement(x,wall,updated);else->x}});save();statusMessage.value="Wall trimmed/extended to intersection"
    }

    fun offsetSelectedWall(distanceMeters:Float=.15f) {
        val wall=project.value.elements.firstOrNull{it.id==selectedId.value && it.kind==ElementKind.WALL && it.end!=null} ?: run { statusMessage.value="Select one wall"; return }
        val e=wall.end!!; val dx=e.x-wall.start.x; val dy=e.y-wall.start.y; val len=hypot(dx.toDouble(),dy.toDouble()).toFloat(); if(len<1f)return
        val px=(-dy/len)*distanceMeters*project.value.pixelsPerMeter; val py=(dx/len)*distanceMeters*project.value.pixelsPerMeter
        checkpoint(); val copy=wall.copy(id=System.nanoTime(),start=Point2(wall.start.x+px,wall.start.y+py),end=Point2(e.x+px,e.y+py),label="Offset wall",hostWallId=null,roomWallIds=emptyList())
        project.value=project.value.copy(elements=project.value.elements+copy); selectedId.value=copy.id; selectedIds.value=setOf(copy.id); save(); statusMessage.value="Offset wall ${"%.2f".format(distanceMeters)} m created"
    }

    fun joinSelectedWalls() {
        val walls=selectedElements().filter{it.kind==ElementKind.WALL && it.end!=null}; if(walls.size!=2){statusMessage.value="Select exactly 2 walls";return}
        val a=walls[0]; val b=walls[1]; val points=listOf(a.start,a.end!!,b.start,b.end!!); val best=points.flatMapIndexed{i,p1->points.drop(i+1).map{p2->p1 to p2}}.maxByOrNull{(u,v)->distance(u.offset(),v.offset())}?:return
        val v1=Point2(a.end!!.x-a.start.x,a.end!!.y-a.start.y); val v2=Point2(b.end!!.x-b.start.x,b.end!!.y-b.start.y); val cross=abs(v1.x*v2.y-v1.y*v2.x); val scale=(hypot(v1.x.toDouble(),v1.y.toDouble())*hypot(v2.x.toDouble(),v2.y.toDouble())).toFloat().coerceAtLeast(1f)
        if(cross/scale>.12f){statusMessage.value="Walls are not collinear";return}
        checkpoint(); val keep=a.copy(start=best.first,end=best.second); val remove=b.id
        project.value=project.value.copy(elements=project.value.elements.filterNot{it.id==remove}.map{e->when{e.hostWallId==remove->remapHostedElement(e,b,keep).copy(hostWallId=keep.id); e.kind==ElementKind.ROOM && remove in e.roomWallIds->e.copy(roomWallIds=(e.roomWallIds.map{if(it==remove)keep.id else it}).distinct()); e.id==keep.id->keep; else->e}})
        selectedId.value=keep.id; selectedIds.value=setOf(keep.id); save(); statusMessage.value="Walls joined"
    }

    fun renumberElectricalPoints() {
        checkpoint(); val floor=project.value.activeFloorId
        val ordered=project.value.elements.filter{it.floorId==floor && it.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT)}.sortedWith(compareBy<DesignElement>{it.start.y}.thenBy{it.start.x})
        val labels=mutableMapOf<Long,String>(); var pc=0;var sw=0;var li=0
        ordered.forEach{e->labels[e.id]=when(e.kind){ElementKind.SOCKET->"PC-${(++pc).toString().padStart(2,'0')}";ElementKind.SWITCH->"SW-${(++sw).toString().padStart(2,'0')}";ElementKind.TWO_WAY_SWITCH->"VV-${(++sw).toString().padStart(2,'0')}";ElementKind.CONTACTOR->"KM-${e.id.toString().takeLast(2)}";ElementKind.LIGHT->"L-${(++li).toString().padStart(2,'0')}";else->e.label}}
        project.value=project.value.copy(elements=project.value.elements.map{e->labels[e.id]?.let{e.copy(label=it)}?:e});save();statusMessage.value="Renumbered $pc sockets, $sw switches, $li lights"
    }

    fun circuitChecks(): List<CircuitCheck> = project.value.circuits.map{c->
        val loads=project.value.elements.filter{it.circuitId==c.id && it.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT)}
        val cables=project.value.elements.filter{it.kind==ElementKind.CABLE && it.circuitId==c.id}
        val connected=cables.flatMap{it.connectedElementIds}.toSet(); val open=loads.count{it.id !in connected}
        val warnings=buildList{ if(open>0)add("$open point(s) not wired"); if(loads.isNotEmpty()&&cables.isEmpty())add("No cable route"); if(c.name.startsWith("PC",true)&&loads.count{it.kind==ElementKind.SOCKET}>8)add("More than 8 sockets"); if(c.name.startsWith("ECL",true)&&loads.count{it.kind==ElementKind.LIGHT}>8)add("More than 8 light points") }
        CircuitCheck(c.id,c.name,loads.size,cables.size,open,warnings)
    }

    fun validateElectricalProject() {
        val checks=circuitChecks(); val overloaded=circuitLoads().count{it.utilizationPercent>80f}; val warnings=checks.sumOf{it.warnings.size}+overloaded
        statusMessage.value=if(warnings==0)"Electrical validation: no basic warnings" else "Electrical validation: $warnings warning(s)"
    }

    fun setSupplyVoltage(volts:Float){ project.value=project.value.copy(supplyVoltage=volts.coerceIn(100f,500f));save() }

    fun circuitLoads(): List<CircuitLoad> = project.value.circuits.map { c ->
        val watts=project.value.elements.filter{it.circuitId==c.id && it.kind in listOf(ElementKind.SOCKET,ElementKind.LIGHT)}.sumOf { effectivePowerWatts(it).toDouble() }.toFloat()
        val amps=if(project.value.supplyVoltage>1f) watts/project.value.supplyVoltage else 0f
        val breakerAmps=Regex("(\\d+)").find(c.breaker)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 20
        val recommended=when { amps<=8f -> 10; amps<=13f -> 16; amps<=18f -> 20; amps<=23f -> 25; amps<=29f -> 32; else -> 40 }
        val cable=when { recommended<=10 -> "3×1.5 mm²"; recommended<=20 -> "3×2.5 mm²"; recommended<=25 -> "3×4 mm²"; else -> "3×6 mm²" }
        CircuitLoad(c.id,c.name,watts,amps,breakerAmps,"C$recommended",cable,if(breakerAmps>0)amps/breakerAmps*100f else 0f)
    }

    private fun effectivePowerWatts(e:DesignElement):Float = if(e.ratedPowerWatts>0f)e.ratedPowerWatts else when(e.kind){ElementKind.SOCKET->200f;ElementKind.LIGHT->80f;else->0f}

    fun updateSelectedPower(watts:Float){ updateSelected{it.copy(ratedPowerWatts=watts.coerceIn(0f,12000f))} }

    fun applyRecommendedCircuit(circuitId:Long){
        val load=circuitLoads().firstOrNull{it.circuitId==circuitId}?:return
        val c=project.value.circuit(circuitId)?:return; checkpoint()
        project.value=project.value.copy(circuits=project.value.circuits.map{if(it.id==circuitId)it.copy(breaker=load.recommendedBreaker,cableSpec=load.recommendedCable)else it},elements=project.value.elements.map{e->if(e.kind==ElementKind.CABLE&&e.circuitId==circuitId)e.copy(cableSpec=load.recommendedCable)else e})
        save();statusMessage.value="${c.name}: ${load.recommendedBreaker} / ${load.recommendedCable} applied"
    }

    fun autoWireActiveCircuit() {
        val c=project.value.circuit(project.value.activeCircuitId)?:return
        val panel=project.value.activeElements().firstOrNull{it.kind==ElementKind.PANEL}?:run{statusMessage.value="Place a panel first";return}
        val already=project.value.elements.filter{it.kind==ElementKind.CABLE&&it.circuitId==c.id}.flatMap{it.connectedElementIds}.toSet()
        val loads=project.value.activeElements().filter{it.circuitId==c.id&&it.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT)&&it.id !in already}
        if(loads.isEmpty()){statusMessage.value="All points in ${c.name} are already routed";return}
        checkpoint(); val created=loads.mapIndexed{idx,target->
            val corner1=Point2(target.start.x,panel.start.y); val corner2=Point2(panel.start.x,target.start.y)
            val a=listOf(panel.start,corner1,target.start).distinctAdjacent(); val b=listOf(panel.start,corner2,target.start).distinctAdjacent(); val chosen=chooseSmartRoute(a,b,target.floorId); val path=if(c.route==CableRoute.WALL)conformPathToWalls(chosen,target.floorId)else chosen
            val routeHeight=when(c.route){CableRoute.CEILING->project.value.ceilingHeightMeters;CableRoute.FLOOR->0f;CableRoute.WALL->1f;CableRoute.SURFACE->1.5f}; val vertical=abs(panel.heightMeters-routeHeight)+abs(target.heightMeters-routeHeight)
            DesignElement(System.nanoTime()+idx,ElementKind.CABLE,path.first(),path.last(),c.name,cableSpec=c.cableSpec,circuitId=c.id,route=c.route,path=path,connectedElementIds=listOf(panel.id,target.id),verticalMeters=vertical,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId,wallMounted=c.route==CableRoute.WALL,conductorCount=inferConductorCount(c.cableSpec),conductorSectionMm2=inferSectionMm2(c.cableSpec))
        }
        project.value=project.value.copy(elements=project.value.elements+created);save();statusMessage.value="Auto-wired ${created.size} point(s) on ${c.name}"
    }


    private fun conductorRole(index:Int,count:Int,hasPe:Boolean):String {
        if(index==0) return "L"
        if(index==1) return "N"
        if(hasPe && index==2) return "PE"
        return "L${index}"
    }

    private fun defaultTerminal(kind:ElementKind, role:String, incoming:Boolean):String = when(kind){
        ElementKind.PANEL -> if(incoming) "BUS-$role" else "OUT-$role"
        ElementKind.JUNCTION_BOX -> if(incoming) "IN-$role" else "OUT-$role"
        ElementKind.SOCKET -> role
        ElementKind.SWITCH -> if(role=="L") if(incoming)"COM" else "L1" else role
        ElementKind.TWO_WAY_SWITCH -> if(role=="L") if(incoming)"COM" else "T1" else role
        ElementKind.CONTACTOR -> if(role=="L") if(incoming)"L-IN" else "L-OUT" else role
        ElementKind.LIGHT -> role
        else -> role
    }


    fun setSimulationEnabled(enabled:Boolean){
        simulationEnabled.value=enabled
        if(enabled) runSimulation() else lastSimulation.value=SimulationResult()
    }

    fun toggleSwitch(elementId:Long){
        val sw=project.value.elements.firstOrNull{it.id==elementId&&it.kind==ElementKind.SWITCH}?:return
        val current=project.value.simulationStates.firstOrNull{it.elementId==sw.id} ?: SimulationState(sw.id)
        val next=current.copy(switchClosed=!current.switchClosed)
        project.value=project.value.copy(simulationStates=project.value.simulationStates.filterNot{it.elementId==sw.id}+next)
        save()
        if(simulationEnabled.value)runSimulation()
    }

    fun toggleTwoWaySwitch(elementId:Long){
        val sw=project.value.elements.firstOrNull{it.id==elementId&&it.kind==ElementKind.TWO_WAY_SWITCH}?:return
        val current=project.value.simulationStates.firstOrNull{it.elementId==sw.id} ?: SimulationState(sw.id)
        val next=current.copy(switchPosition=if(current.switchPosition==0)1 else 0)
        project.value=project.value.copy(simulationStates=project.value.simulationStates.filterNot{it.elementId==sw.id}+next)
        save(); if(simulationEnabled.value)runSimulation()
    }

    fun toggleContactorCoil(elementId:Long){
        val c=project.value.elements.firstOrNull{it.id==elementId&&it.kind==ElementKind.CONTACTOR}?:return
        val current=project.value.simulationStates.firstOrNull{it.elementId==c.id} ?: SimulationState(c.id)
        val next=current.copy(coilEnergized=!current.coilEnergized)
        project.value=project.value.copy(simulationStates=project.value.simulationStates.filterNot{it.elementId==c.id}+next)
        save(); if(simulationEnabled.value)runSimulation()
    }

    fun pairSelectedTwoWayWith(otherId:Long?){
        val id=selectedId.value?:return
        val a=project.value.elements.firstOrNull{it.id==id&&it.kind==ElementKind.TWO_WAY_SWITCH}?:return
        val b=otherId?.let{id2->project.value.elements.firstOrNull{it.id==id2&&it.kind==ElementKind.TWO_WAY_SWITCH&&it.id!=a.id&&it.circuitId==a.circuitId}}
        checkpoint()
        project.value=project.value.copy(elements=project.value.elements.map{e->
            when(e.id){
                a.id->e.copy(pairedElementId=b?.id)
                b?.id->e.copy(pairedElementId=a.id)
                else->if(e.pairedElementId==a.id || (b!=null && e.pairedElementId==b.id)) e.copy(pairedElementId=null) else e
            }
        })
        save()
    }

    fun setSelectedContactorControl(controlId:Long?){
        val id=selectedId.value?:return
        val c=project.value.elements.firstOrNull{it.id==id&&it.kind==ElementKind.CONTACTOR}?:return
        val valid=controlId?.let{cid->project.value.elements.firstOrNull{it.id==cid&&it.kind in listOf(ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH)}?.id}
        checkpoint()
        project.value=project.value.copy(elements=project.value.elements.map{if(it.id==c.id)it.copy(controlElementId=valid)else it})
        save()
    }

    fun setFault(elementId:Long,fault:String){
        val allowed=setOf("NONE","OPEN","SHORT_LN","SHORT_LE","SHORT_NE")
        val f=if(fault in allowed)fault else "NONE"
        val current=project.value.simulationStates.firstOrNull{it.elementId==elementId} ?: SimulationState(elementId)
        project.value=project.value.copy(simulationStates=project.value.simulationStates.filterNot{it.elementId==elementId}+current.copy(fault=f))
        save()
        if(simulationEnabled.value)runSimulation()
    }

    fun clearSimulationFaults(){
        project.value=project.value.copy(simulationStates=project.value.simulationStates.map{it.copy(fault="NONE")})
        save(); if(simulationEnabled.value)runSimulation()
    }

    private fun stateFor(id:Long)=project.value.simulationStates.firstOrNull{it.elementId==id} ?: SimulationState(id)

    fun runSimulation(){
        val p=project.value
        val energizedLinks=mutableSetOf<Long>()
        val energizedElements=mutableSetOf<Long>()
        val litLights=mutableSetOf<Long>()
        val tripped=mutableSetOf<Long>()
        val voltages=mutableMapOf<String,Float>()
        val messages=mutableListOf<String>()

        p.circuits.forEach { circuit ->
            val circuitLinks=p.wireLinks.filter{it.circuitId==circuit.id}
            val panels=p.elements.filter{it.kind==ElementKind.PANEL}.map{it.id}.toSet()
            val states=p.simulationStates.associateBy{it.elementId}
            val shortOnCircuit=p.elements.any { e ->
                e.circuitId==circuit.id && (states[e.id]?.fault in setOf("SHORT_LN","SHORT_LE","SHORT_NE"))
            }
            if(shortOnCircuit){
                tripped += circuit.id
                messages += "${circuit.name}: protective device tripped by short circuit"
                return@forEach
            }

            fun roleAdj(role:String):Map<Long,Set<Long>>{
                val map=mutableMapOf<Long,MutableSet<Long>>()
                circuitLinks.filter{it.role==role}.forEach { w ->
                    val fromEl=p.elements.firstOrNull{it.id==w.fromElementId}
                    val toEl=p.elements.firstOrNull{it.id==w.toElementId}
                    val fromOpen=fromEl?.let{stateFor(it.id).fault=="OPEN"}==true
                    val toOpen=toEl?.let{stateFor(it.id).fault=="OPEN"}==true
                    val cableOpen=stateFor(w.cableId).fault=="OPEN"
                    if(fromEl!=null && toEl!=null && !fromOpen && !toOpen && !cableOpen){
                        map.getOrPut(w.fromElementId){mutableSetOf()}.add(w.toElementId)
                        map.getOrPut(w.toElementId){mutableSetOf()}.add(w.fromElementId)
                    }
                }
                return map
            }

            fun reachable(role:String):Set<Long>{
                val adj=roleAdj(role)
                val visited=mutableSetOf<Long>(); val q=ArrayDeque<Long>()
                panels.forEach{visited.add(it);q.add(it)}
                while(q.isNotEmpty()){
                    val n=q.removeFirst()
                    adj[n].orEmpty().forEach { next ->
                        val e=p.elements.firstOrNull{it.id==next}
                        if(role=="L" && e!=null){
                            when(e.kind){
                                ElementKind.SWITCH -> {
                                    if(!stateFor(e.id).switchClosed){ energizedElements += e.id; return@forEach }
                                }
                                ElementKind.TWO_WAY_SWITCH -> {
                                    val pair=e.pairedElementId?.let{id->p.elements.firstOrNull{it.id==id&&it.kind==ElementKind.TWO_WAY_SWITCH}}
                                    if(pair!=null){
                                        val same=stateFor(e.id).switchPosition==stateFor(pair.id).switchPosition
                                        if(!same){ energizedElements += e.id; return@forEach }
                                    } else {
                                        messages += "${e.label.ifBlank{"Va-et-vient"}}: not paired, treated as open"
                                        energizedElements += e.id
                                        return@forEach
                                    }
                                }
                                ElementKind.CONTACTOR -> {
                                    val controlClosed=e.controlElementId?.let{cid->
                                        val ce=p.elements.firstOrNull{it.id==cid}
                                        when(ce?.kind){
                                            ElementKind.SWITCH->stateFor(cid).switchClosed
                                            ElementKind.TWO_WAY_SWITCH->stateFor(cid).switchPosition==1
                                            else->stateFor(e.id).coilEnergized
                                        }
                                    } ?: stateFor(e.id).coilEnergized
                                    if(!controlClosed){ energizedElements += e.id; return@forEach }
                                }
                                else -> Unit
                            }
                        }
                        if(visited.add(next))q.add(next)
                    }
                }
                return visited
            }

            val live=reachable("L")
            val neutral=reachable("N")
            val pe=reachable("PE")
            energizedElements += live
            circuitLinks.forEach { w ->
                if(w.role=="L" && w.fromElementId in live && w.toElementId in live) energizedLinks += w.id
                if(w.role=="N" && w.fromElementId in neutral && w.toElementId in neutral) energizedLinks += w.id
                if(w.role=="PE" && w.fromElementId in pe && w.toElementId in pe) energizedLinks += w.id
            }

            p.elements.filter{it.circuitId==circuit.id}.forEach { e ->
                val key="${e.id}:L"
                voltages[key]=if(e.id in live) p.supplyVoltage else 0f
                voltages["${e.id}:N"]=0f
                voltages["${e.id}:PE"]=0f
                if(e.kind==ElementKind.LIGHT){
                    val on=e.id in live && e.id in neutral && stateFor(e.id).fault!="OPEN"
                    if(on) litLights += e.id
                }
            }
        }

        lastSimulation.value=SimulationResult(
            energizedElementIds=energizedElements,
            energizedWireLinkIds=energizedLinks,
            litLightIds=litLights,
            trippedCircuitIds=tripped,
            terminalVoltages=voltages,
            messages=messages
        )
        statusMessage.value=when{
            tripped.isNotEmpty()->"Simulation: ${tripped.size} circuit(s) tripped"
            litLights.isNotEmpty()->"Simulation: ${litLights.size} light(s) ON"
            else->"Simulation updated"
        }
    }

    fun rebuildTerminalNetwork() {
        checkpoint()
        val links=mutableListOf<WireLink>()
        project.value.elements.filter{it.kind==ElementKind.CABLE && it.circuitId!=null}.forEach { cable ->
            val endpoints=cable.connectedElementIds.mapNotNull{id->project.value.elements.firstOrNull{it.id==id}}
            if(endpoints.size>=2){
                val from=endpoints.first()
                endpoints.drop(1).forEach { to ->
                    val count=cable.conductorCount.coerceIn(2,7)
                    for(i in 0 until count){
                        val role=conductorRole(i,count,cable.hasProtectiveEarth)
                        links += WireLink(
                            id=System.nanoTime()+links.size,
                            circuitId=cable.circuitId!!,
                            cableId=cable.id,
                            conductorIndex=i,
                            role=role,
                            fromElementId=from.id,
                            toElementId=to.id,
                            fromTerminal=defaultTerminal(from.kind,role,false),
                            toTerminal=defaultTerminal(to.kind,role,true)
                        )
                    }
                }
            }
        }
        project.value=project.value.copy(wireLinks=links)
        save()
        statusMessage.value="Terminal network rebuilt • ${links.size} conductor links"
    }

    fun wiringIssues():List<WiringIssue>{
        val p=project.value
        val issues=mutableListOf<WiringIssue>()
        p.circuits.forEach { circuit ->
            val panelIds=p.elements.filter{it.kind==ElementKind.PANEL}.map{it.id}.toSet()
            val loads=p.elements.filter{
                it.circuitId==circuit.id && it.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT,ElementKind.JUNCTION_BOX)
            }
            val links=p.wireLinks.filter{it.circuitId==circuit.id}
            if(loads.isNotEmpty() && links.isEmpty()){
                issues += WiringIssue(circuit.id,"ERROR","${circuit.name}: no terminal links generated")
                return@forEach
            }
            listOf("L","N").forEach { requiredRole ->
                val adjacency=mutableMapOf<Long,MutableSet<Long>>()
                links.filter{it.role==requiredRole}.forEach { w ->
                    adjacency.getOrPut(w.fromElementId){mutableSetOf()}.add(w.toElementId)
                    adjacency.getOrPut(w.toElementId){mutableSetOf()}.add(w.fromElementId)
                }
                val visited=mutableSetOf<Long>()
                val queue=ArrayDeque<Long>()
                panelIds.forEach{queue.add(it);visited.add(it)}
                while(queue.isNotEmpty()){
                    val n=queue.removeFirst()
                    adjacency[n].orEmpty().forEach{if(visited.add(it))queue.add(it)}
                }
                loads.filter{it.kind!=ElementKind.JUNCTION_BOX}.forEach { load ->
                    if(load.id !in visited){
                        issues += WiringIssue(circuit.id,"ERROR","${circuit.name}: ${load.label.ifBlank{load.kind.name}} missing $requiredRole continuity",load.id)
                    }
                }
            }
            if(loads.any{it.kind==ElementKind.SOCKET}){
                val adjacency=mutableMapOf<Long,MutableSet<Long>>()
                links.filter{it.role=="PE"}.forEach { w ->
                    adjacency.getOrPut(w.fromElementId){mutableSetOf()}.add(w.toElementId)
                    adjacency.getOrPut(w.toElementId){mutableSetOf()}.add(w.fromElementId)
                }
                val visited=mutableSetOf<Long>(); val queue=ArrayDeque<Long>()
                panelIds.forEach{queue.add(it);visited.add(it)}
                while(queue.isNotEmpty()){val n=queue.removeFirst();adjacency[n].orEmpty().forEach{if(visited.add(it))queue.add(it)}}
                loads.filter{it.kind==ElementKind.SOCKET}.forEach { load ->
                    if(load.id !in visited) issues += WiringIssue(circuit.id,"WARN","${circuit.name}: ${load.label.ifBlank{"Socket"}} missing PE continuity",load.id)
                }
            }
            links.groupBy{Triple(it.toElementId,it.toTerminal,it.role)}.filterValues{it.size>1}.forEach{(k,v)->
                if(p.elements.firstOrNull{it.id==k.first}?.kind!=ElementKind.JUNCTION_BOX)
                    issues += WiringIssue(circuit.id,"WARN","${circuit.name}: multiple ${k.third} conductors on terminal ${k.second}",k.first)
            }
        }
        project.value.elements.filter{it.kind==ElementKind.TWO_WAY_SWITCH}.forEach{sw->
            if(sw.pairedElementId==null || project.value.elements.none{it.id==sw.pairedElementId&&it.kind==ElementKind.TWO_WAY_SWITCH})
                issues += WiringIssue(sw.circuitId?:project.value.activeCircuitId,"WARN","${sw.label.ifBlank{"Va-et-vient"}} is not paired",sw.id)
        }
        project.value.elements.filter{it.kind==ElementKind.CONTACTOR}.forEach{c->
            if(c.controlElementId==null)
                issues += WiringIssue(c.circuitId?:project.value.activeCircuitId,"WARN","${c.label.ifBlank{"Contactor"}} has no control switch assigned",c.id)
        }
        return issues.distinctBy{Triple(it.circuitId,it.message,it.elementId)}
    }

    fun autoBuildAndValidateWiring(){
        rebuildTerminalNetwork()
        val issues=wiringIssues()
        statusMessage.value=if(issues.isEmpty())"Wiring validation passed" else "Wiring validation: ${issues.count{it.severity=="ERROR"}} errors • ${issues.count{it.severity=="WARN"}} warnings"
    }

    fun convertSketchPlan(){
        if(sketchBuffer.isEmpty()){statusMessage.value="No sketch strokes to convert";return}
        checkpoint(); val unrecognized=mutableListOf<InkStroke>(); var walls=0; var roomsBefore=project.value.activeElements().count{it.kind==ElementKind.ROOM}
        for(stroke in sketchBuffer){
            val pts=stroke.points; if(pts.size<2){unrecognized+=stroke;continue}
            val minX=pts.minOf{it.x};val maxX=pts.maxOf{it.x};val minY=pts.minOf{it.y};val maxY=pts.maxOf{it.y}; val w=maxX-minX;val h=maxY-minY
            val first=pts.first();val last=pts.last(); val pathLen=pts.zipWithNext().sumOf{(a,b)->hypot((b.x-a.x).toDouble(),(b.y-a.y).toDouble())}.toFloat(); val chord=hypot((last.x-first.x).toDouble(),(last.y-first.y).toDouble()).toFloat(); val straight=if(pathLen>1f)chord/pathLen else 0f
            val closed=hypot((last.x-first.x).toDouble(),(last.y-first.y).toDouble())<maxOf(24f,maxOf(w,h)*.20f)
            if(closed && w>110f && h>90f){ createRoomFromBounds(smartSnapPoint(Offset(minX,minY)),smartSnapPoint(Offset(maxX,maxY)),"Room ${project.value.activeElements().count{it.kind==ElementKind.ROOM}+1}"); continue }
            if(maxOf(w,h)>90f && straight>.82f){
                val a=smartSnapPoint(Offset(first.x,first.y)); val b=smartSnapPoint(smartLine(a,snap(Offset(last.x,last.y))))
                if(distance(a,b)>35f){ val id=System.nanoTime()+walls; val item=DesignElement(id,ElementKind.WALL,a.toPoint(),b.toPoint(),"Wall",wallThicknessMeters=project.value.defaultWallThicknessMeters,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId);project.value=project.value.copy(elements=project.value.elements+item);walls++;continue }
            }
            unrecognized+=stroke
        }
        if(unrecognized.isNotEmpty()) project.value=project.value.copy(ink=project.value.ink+unrecognized)
        detectRectangularRooms(); val roomsAfter=project.value.activeElements().count{it.kind==ElementKind.ROOM}; sketchBuffer.clear();sketchStrokeCount.intValue=0;save();statusMessage.value="Sketch converted • $walls walls • ${roomsAfter-roomsBefore} rooms • ${unrecognized.size} kept as ink"
    }

    fun updateSelectedHeight(value:Float){ updateSelected{it.copy(heightMeters=value.coerceIn(0f,6f))} }
    fun updateSelectedVerticalMeters(value:Float){ updateSelected{it.copy(verticalMeters=value.coerceIn(0f,20f))} }
    fun updateSelectedRoute(route:CableRoute){ updateSelected{it.copy(route=route)} }
    fun updateSelectedWallThickness(value:Float){ updateSelected{it.copy(wallThicknessMeters=value.coerceIn(.05f,.60f))} }
    fun updateSelectedConduitDiameter(value:Float){ updateSelected{it.copy(conduitDiameterMm=value.coerceIn(10f,50f))} }
    fun updateSelectedBoxDiameter(value:Float){ updateSelected{it.copy(boxDiameterMm=value.coerceIn(40f,100f))} }
    fun updateSelectedBoxDepth(value:Float){ updateSelected{it.copy(boxDepthMm=value.coerceIn(25f,100f))} }
    fun updateSelectedChaseWidth(value:Float){ updateSelected{it.copy(chaseWidthMm=value.coerceIn(20f,80f))} }
    fun updateSelectedChaseDepth(value:Float){ updateSelected{it.copy(chaseDepthMm=value.coerceIn(10f,60f))} }
    fun updateSelectedConductorCount(value:Int){ updateSelected{it.copy(conductorCount=value.coerceIn(2,7))} }
    fun updateSelectedBendRadius(value:Float){ updateSelected{it.copy(bendRadiusMm=value.coerceIn(20f,150f))} }
    fun updateSelectedEmbeddedDepth(value:Float){ updateSelected{it.copy(embeddedDepthMm=value.coerceIn(5f,80f))} }
    fun updateSelectedConductorSection(value:Float){ updateSelected{it.copy(conductorSectionMm2=value.coerceIn(.5f,35f))} }
    fun setSelectedProtectiveEarth(enabled:Boolean){ updateSelected{it.copy(hasProtectiveEarth=enabled)} }
    fun conformSelectedCableToWalls(){
        val id=selectedId.value?:return
        val e=project.value.elements.firstOrNull{it.id==id&&it.kind==ElementKind.CABLE}?:return
        val pts=conformPathToWalls(e.geometryPoints(),e.floorId)
        if(pts.size<2)return
        checkpoint()
        project.value=project.value.copy(elements=project.value.elements.map{if(it.id==id)it.copy(start=pts.first(),end=pts.last(),path=pts,wallMounted=true)else it})
        save();statusMessage.value="Cable conformed to nearby walls"
    }
    fun assignSelectedCircuit(circuitId:Long){
        val circuit=project.value.circuit(circuitId)?:return
        updateSelected{ e -> if(e.kind==ElementKind.CABLE)e.copy(circuitId=circuitId,label=circuit.name,cableSpec=circuit.cableSpec,route=circuit.route) else e.copy(circuitId=circuitId) }
    }
    fun renameSelected(name:String){ val clean=name.trim(); if(clean.isBlank())return; updateSelected{it.copy(label=clean)} }

    private fun updateSelected(block:(DesignElement)->DesignElement){ val id=selectedId.value?:return; project.value=project.value.copy(elements=project.value.elements.map{if(it.id==id)block(it)else it}); save() }

    fun addCircuit(name: String, cableSpec: String, breaker: String, route: CableRoute) {
        val clean=name.trim().ifBlank{"CIR-${project.value.circuits.size+1}"}; checkpoint(); val id=System.nanoTime()
        project.value=project.value.copy(circuits=project.value.circuits+Circuit(id,clean,cableSpec.trim().ifBlank{"3×2.5 mm²"},breaker.trim().ifBlank{"C20"},route),activeCircuitId=id); save()
    }
    fun updateCircuit(id: Long, name: String, cableSpec: String, breaker: String, route: CableRoute) {
        checkpoint(); project.value=project.value.copy(circuits=project.value.circuits.map{if(it.id==id)it.copy(name=name.trim().ifBlank{it.name},cableSpec=cableSpec.trim().ifBlank{it.cableSpec},breaker=breaker.trim().ifBlank{it.breaker},route=route)else it},elements=project.value.elements.map{e->if(e.circuitId==id && e.kind==ElementKind.CABLE)e.copy(label=name.trim().ifBlank{e.label},cableSpec=cableSpec.trim().ifBlank{e.cableSpec},route=route)else e}); save()
    }
    fun deleteCircuit(id: Long) {
        if(project.value.circuits.size<=1)return; checkpoint(); val remaining=project.value.circuits.filterNot{it.id==id}; val fallback=remaining.first().id
        project.value=project.value.copy(circuits=remaining,activeCircuitId=if(project.value.activeCircuitId==id)fallback else project.value.activeCircuitId,elements=project.value.elements.map{if(it.circuitId==id)it.copy(circuitId=fallback)else it},wireLinks=project.value.wireLinks.filterNot{it.circuitId==id}); save()
    }

    fun autoRouteSelectedToPanel() {
        val target=project.value.elements.firstOrNull{it.id==selectedId.value && it.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT)} ?: run { statusMessage.value="Select a socket, switch or light"; return }
        val panel=project.value.activeElements().filter{it.kind==ElementKind.PANEL}.minByOrNull{distance(it.start.offset(),target.start.offset())} ?: run { statusMessage.value="Place a panel first"; return }
        val circuit=project.value.circuit(target.circuitId ?: project.value.activeCircuitId) ?: return
        val cornerA=Point2(target.start.x,panel.start.y); val cornerB=Point2(panel.start.x,target.start.y)
        val pathA=listOf(panel.start,cornerA,target.start).distinctAdjacent(); val pathB=listOf(panel.start,cornerB,target.start).distinctAdjacent()
        val chosen=chooseSmartRoute(pathA,pathB,target.floorId); val path=if(circuit.route==CableRoute.WALL)conformPathToWalls(chosen,target.floorId)else chosen
        val routeHeight=when(circuit.route){CableRoute.CEILING->project.value.ceilingHeightMeters;CableRoute.FLOOR->0f;CableRoute.WALL->1f;CableRoute.SURFACE->1.5f}
        val vertical=abs(panel.heightMeters-routeHeight)+abs(target.heightMeters-routeHeight)
        checkpoint(); val cable=DesignElement(System.nanoTime(),ElementKind.CABLE,path.first(),path.last(),circuit.name,cableSpec=circuit.cableSpec,circuitId=circuit.id,route=circuit.route,path=path,connectedElementIds=listOf(panel.id,target.id),verticalMeters=vertical,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId,wallMounted=circuit.route==CableRoute.WALL,conductorCount=inferConductorCount(circuit.cableSpec),conductorSectionMm2=inferSectionMm2(circuit.cableSpec))
        project.value=project.value.copy(elements=project.value.elements+cable); selectedId.value=cable.id; save(); statusMessage.value="Auto route created • ${"%.1f".format(project.value.cableMeters(cable))} m"
    }

    fun addFloor(name:String = "Floor ${project.value.floors.size}") {
        checkpoint(); val id=System.nanoTime(); val elevation=(project.value.floors.maxOfOrNull{it.elevationMeters}?:0f)+project.value.ceilingHeightMeters+.30f
        project.value=project.value.copy(floors=project.value.floors+BuildingFloor(id,name,elevation),activeFloorId=id); selectedId.value=null; save(); statusMessage.value="Floor added"
    }

    fun renameActiveFloor(name:String) {
        val clean=name.trim(); if(clean.isBlank())return; checkpoint(); val id=project.value.activeFloorId
        project.value=project.value.copy(floors=project.value.floors.map{if(it.id==id)it.copy(name=clean)else it}); save()
    }

    fun deleteActiveFloor() {
        if(project.value.floors.size<=1)return; checkpoint(); val id=project.value.activeFloorId; val remaining=project.value.floors.filterNot{it.id==id};
        project.value=project.value.copy(floors=remaining,activeFloorId=remaining.first().id,elements=project.value.elements.filterNot{it.floorId==id}); selectedId.value=null; save(); statusMessage.value="Floor deleted"
    }

    private fun nextFloorId(): Long? {
        val active=project.value.floor(project.value.activeFloorId) ?: return null
        return project.value.floors.filter{it.elevationMeters>active.elevationMeters}.minByOrNull{it.elevationMeters}?.id
    }

    fun duplicateActiveFloor() {
        val source=project.value.floor(project.value.activeFloorId) ?: return
        checkpoint()
        val newId=System.nanoTime(); val newFloor=BuildingFloor(newId,"${source.name} copy",(project.value.floors.maxOfOrNull{it.elevationMeters}?:source.elevationMeters)+project.value.ceilingHeightMeters+.30f)
        val src=project.value.activeElements(); val idMap=src.associate{it.id to (System.nanoTime()+it.id.hashCode())}
        val copies=src.map{e->e.copy(id=idMap[e.id]!!,floorId=newId,connectedElementIds=e.connectedElementIds.mapNotNull{oldId->idMap[oldId]},hostWallId=e.hostWallId?.let(idMap::get),roomWallIds=e.roomWallIds.mapNotNull{idMap[it]},pairedElementId=e.pairedElementId?.let(idMap::get),controlElementId=e.controlElementId?.let(idMap::get),targetFloorId=null)}
        project.value=project.value.copy(floors=project.value.floors+newFloor,elements=project.value.elements+copies,activeFloorId=newId); selectedId.value=null; save(); statusMessage.value="Floor duplicated • ${copies.size} elements"
    }

    fun setSelectedTargetFloor(id:Long?) {
        val sid=selectedId.value?:return; checkpoint(); project.value=project.value.copy(elements=project.value.elements.map{if(it.id==sid)it.copy(targetFloorId=id)else it}); save()
    }

    fun rotateCamera(deltaYaw:Float, deltaPitch:Float){ cameraYaw.floatValue=(cameraYaw.floatValue+deltaYaw)%360f; cameraPitch.floatValue=(cameraPitch.floatValue+deltaPitch).coerceIn(8f,75f) }
    fun zoomCamera(factor:Float){ cameraZoom.floatValue=(cameraZoom.floatValue*factor).coerceIn(.45f,2.5f) }
    fun panCamera(dx:Float,dy:Float){ cameraPanX.floatValue+=dx; cameraPanY.floatValue+=dy }
    fun resetCamera(){ cameraYaw.floatValue=35f; cameraPitch.floatValue=28f; cameraZoom.floatValue=1f; cameraPanX.floatValue=0f; cameraPanY.floatValue=0f }

    private fun recognizeStroke(points:List<StrokePoint>): Pair<ElementKind,Point2>? {
        if(points.size<5)return null
        val minX=points.minOf{it.x}; val maxX=points.maxOf{it.x}; val minY=points.minOf{it.y}; val maxY=points.maxOf{it.y}; val w=maxX-minX; val h=maxY-minY
        val center=Point2((minX+maxX)/2f,(minY+maxY)/2f); val first=points.first(); val last=points.last(); val diag=hypot(w,h)
        val close=hypot(last.x-first.x,last.y-first.y) < maxOf(18f,maxOf(w,h)*.25f)
        val pathLength=points.zipWithNext().sumOf{(a,b)->hypot((b.x-a.x).toDouble(),(b.y-a.y).toDouble())}.toFloat()
        val straightness=if(pathLength>1f)hypot(last.x-first.x,last.y-first.y)/pathLength else 0f
        val ratio=if(h>1f)w/h else 99f
        var turns=0; var lastSign=0
        for(i in 2 until points.size){
            val ax=points[i-1].x-points[i-2].x; val ay=points[i-1].y-points[i-2].y; val bx=points[i].x-points[i-1].x; val by=points[i].y-points[i-1].y
            val cross=ax*by-ay*bx; val sign=when{cross>20f->1;cross< -20f->-1;else->0}; if(sign!=0&&lastSign!=0&&sign!=lastSign)turns++; if(sign!=0)lastSign=sign
        }
        // Architectural gestures are intentionally larger than electrical symbols.
        if(close && w>120f && h>100f && ratio in .35f..3.0f && pathLength>diag*2.4f) return ElementKind.ROOM to center
        if(!close && maxOf(w,h)>150f && straightness>.88f) return ElementKind.WALL to center
        if(close && maxOf(w,h) in 55f..150f && minOf(w,h) in 12f..45f && (ratio>2.2f || ratio<.45f)) return ElementKind.WINDOW to center
        if(!close && maxOf(w,h) in 60f..150f && minOf(w,h)>30f && turns<=3 && straightness<.86f) return ElementKind.DOOR to center
        if(w<18f || h<18f || w>180f || h>180f)return null
        val perimeter=2f*(w+h); val compactness=if(perimeter>0f)pathLength/perimeter else 0f
        if(close && ratio in .65f..1.55f && compactness in .55f..1.35f) return ElementKind.SOCKET to center
        if(turns>=4 && pathLength>diag*2.1f) return ElementKind.LIGHT to center
        if(!close && turns in 0..3 && maxOf(w,h) in 25f..120f && pathLength>diag*1.05f) return ElementKind.SWITCH to center
        return null
    }

    private fun placeRecognizedSketch(recognition:Pair<ElementKind,Point2>, points:List<StrokePoint>) {
        val kind=recognition.first
        if(kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT)){ placeRecognizedSymbol(kind,recognition.second); return }
        val rawFirst=Offset(points.first().x,points.first().y); val rawLast=Offset(points.last().x,points.last().y)
        val minX=points.minOf{it.x}; val maxX=points.maxOf{it.x}; val minY=points.minOf{it.y}; val maxY=points.maxOf{it.y}
        when(kind){
            ElementKind.WALL -> {
                val a=smartSnapPoint(rawFirst); val b=smartSnapPoint(smartLine(a,snap(rawLast)))
                if(distance(a,b)>24f){ val item=DesignElement(System.nanoTime(),ElementKind.WALL,a.toPoint(),b.toPoint(),"Wall",wallThicknessMeters=project.value.defaultWallThicknessMeters,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId); project.value=project.value.copy(elements=project.value.elements+item); selectedId.value=item.id; detectRectangularRooms(); save() }
            }
            ElementKind.ROOM -> {
                val a=smartSnapPoint(Offset(minX,minY)); val b=smartSnapPoint(Offset(maxX,maxY)); createRoomFromBounds(a,b,"Room ${project.value.activeElements().count{it.kind==ElementKind.ROOM}+1}")
            }
            ElementKind.DOOR, ElementKind.WINDOW -> {
                val wall=project.value.visibleActiveElements().filter{it.kind==ElementKind.WALL}.minByOrNull{distanceTo(it,recognition.second.offset())}
                if(wall!=null && distanceTo(wall,recognition.second.offset())<80f){
                    val we=wall.end?:return; val horizontal=abs(we.x-wall.start.x)>=abs(we.y-wall.start.y); val half=if(kind==ElementKind.DOOR)45f else 55f
                    val c=projectPointOnSegment(recognition.second.offset(),wall.start.offset(),we.offset())
                    val a=if(horizontal)Offset(c.x-half,c.y) else Offset(c.x,c.y-half); val b=if(horizontal)Offset(c.x+half,c.y) else Offset(c.x,c.y+half)
                    val pair=projectSegmentOntoWall(a,b,wall); val item=DesignElement(System.nanoTime(),kind,pair.first.toPoint(),pair.second.toPoint(),if(kind==ElementKind.DOOR)"Door" else "Window",heightMeters=if(kind==ElementKind.WINDOW)1.10f else 0f,hostWallId=wall.id,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId); project.value=project.value.copy(elements=project.value.elements+item);selectedId.value=item.id;save()
                } else { project.value=project.value.copy(ink=project.value.ink+InkStroke(System.nanoTime(),points));save() }
            }
            else -> Unit
        }
    }

    private fun placeRecognizedSymbol(kind:ElementKind, center:Point2) {
        val circuitId=project.value.activeCircuitId; val label=when(kind){ElementKind.SOCKET->"Prise 2P+T";ElementKind.SWITCH->"Interrupteur";ElementKind.LIGHT->"Point lumineux";else->kind.name}
        val height=when(kind){ElementKind.SOCKET->.30f;ElementKind.SWITCH->1.10f;ElementKind.LIGHT->project.value.ceilingHeightMeters;else->0f}
        val p=smartSnapPoint(center.offset()).toPoint(); val item=DesignElement(System.nanoTime(),kind,p,label=label,heightMeters=height,circuitId=circuitId,floorId=project.value.activeFloorId,layerId=project.value.activeLayerId)
        project.value=project.value.copy(elements=project.value.elements+item); selectedId.value=item.id; save()
    }

    private fun createRoomFromBounds(a:Offset,b:Offset,label:String){
        val x1=minOf(a.x,b.x);val y1=minOf(a.y,b.y);val x2=maxOf(a.x,b.x);val y2=maxOf(a.y,b.y); if(x2-x1<60f||y2-y1<60f)return
        val id=System.nanoTime(); val floor=project.value.activeFloorId; val t=project.value.defaultWallThicknessMeters
        val walls=listOf(DesignElement(id+1,ElementKind.WALL,Point2(x1,y1),Point2(x2,y1),"Room wall",wallThicknessMeters=t,floorId=floor,layerId=project.value.activeLayerId),DesignElement(id+2,ElementKind.WALL,Point2(x2,y1),Point2(x2,y2),"Room wall",wallThicknessMeters=t,floorId=floor,layerId=project.value.activeLayerId),DesignElement(id+3,ElementKind.WALL,Point2(x2,y2),Point2(x1,y2),"Room wall",wallThicknessMeters=t,floorId=floor,layerId=project.value.activeLayerId),DesignElement(id+4,ElementKind.WALL,Point2(x1,y2),Point2(x1,y1),"Room wall",wallThicknessMeters=t,floorId=floor,layerId=project.value.activeLayerId))
        val room=DesignElement(id,ElementKind.ROOM,Point2(x1,y1),Point2(x2,y2),label,floorId=floor,layerId=project.value.activeLayerId,roomWallIds=walls.map{it.id})
        project.value=project.value.copy(elements=project.value.elements+room+walls);selectedId.value=room.id;save()
    }

    private fun detectRectangularRooms(){
        val p=project.value; val walls=p.activeElements().filter{it.kind==ElementKind.WALL&&it.end!=null}; if(walls.size<4)return
        val xs=(walls.flatMap{listOf(it.start.x,it.end!!.x)}).distinct().sorted(); val ys=(walls.flatMap{listOf(it.start.y,it.end!!.y)}).distinct().sorted()
        val rooms=p.activeElements().filter{it.kind==ElementKind.ROOM}
        fun covered(a:Point2,b:Point2):Boolean = walls.any{w-> val e=w.end!!; distanceToSegment(w.start,e,a.offset())<14f && distanceToSegment(w.start,e,b.offset())<14f }
        val additions=mutableListOf<DesignElement>()
        for(i in 0 until xs.size-1) for(j in i+1 until xs.size){ val x1=xs[i];val x2=xs[j];if(x2-x1<80f)continue
            for(k in 0 until ys.size-1) for(l in k+1 until ys.size){ val y1=ys[k];val y2=ys[l];if(y2-y1<80f)continue
                val a=Point2(x1,y1);val b=Point2(x2,y1);val c=Point2(x2,y2);val d=Point2(x1,y2)
                if(covered(a,b)&&covered(b,c)&&covered(c,d)&&covered(d,a)){
                    val exists=rooms.any{r->val e=r.end; e!=null&&abs(r.start.x-x1)<20f&&abs(r.start.y-y1)<20f&&abs(e.x-x2)<20f&&abs(e.y-y2)<20f} || additions.any{r->val e=r.end!!;abs(r.start.x-x1)<20f&&abs(r.start.y-y1)<20f&&abs(e.x-x2)<20f&&abs(e.y-y2)<20f}
                    if(!exists){
                        val boundary=listOf(a to b,b to c,c to d,d to a).mapNotNull{(u,v)->walls.minByOrNull{w->distanceToSegment(w.start,w.end!!,u.offset())+distanceToSegment(w.start,w.end!!,v.offset())}?.takeIf{w->distanceToSegment(w.start,w.end!!,u.offset())<14f&&distanceToSegment(w.start,w.end!!,v.offset())<14f}?.id}.distinct()
                        val id=System.nanoTime()+additions.size;additions+=DesignElement(id,ElementKind.ROOM,a,c,"Auto room ${rooms.size+additions.size+1}",floorId=p.activeFloorId,layerId=p.activeLayerId,roomWallIds=boundary)
                    }
                }
            }
        }
        if(additions.isNotEmpty()){project.value=project.value.copy(elements=project.value.elements+additions);statusMessage.value="${additions.size} room(s) detected automatically"}
    }

    fun totalCableMeters(): Float = project.value.elements.filter{it.kind==ElementKind.CABLE}.sumOf { project.value.cableMeters(it).toDouble() }.toFloat()
    fun circuitCableMeters(id: Long): Float = project.value.elements.filter{it.kind==ElementKind.CABLE&&it.circuitId==id}.sumOf{project.value.cableMeters(it).toDouble()}.toFloat()
    fun panelLines(): List<PanelLine> = project.value.circuits.map { c -> PanelLine(c.name,c.breaker,c.cableSpec,project.value.elements.count{it.circuitId==c.id && it.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT)},circuitCableMeters(c.id)) }
    fun bom(): List<BomLine> {
        val p=project.value; val lines=mutableListOf<BomLine>()
        lines += BomLine("Rooms", p.elements.count{it.kind==ElementKind.ROOM}.toString()); lines += BomLine("Staircases",p.elements.count{it.kind==ElementKind.STAIRCASE}.toString()); lines += BomLine("Vertical risers",p.elements.count{it.kind==ElementKind.RISER}.toString()); lines += BomLine("Doors", p.elements.count{it.kind==ElementKind.DOOR}.toString()); lines += BomLine("Windows", p.elements.count{it.kind==ElementKind.WINDOW}.toString())
        lines += BomLine("Prises 2P+T", p.elements.count{it.kind==ElementKind.SOCKET}.toString()); lines += BomLine("Interrupteurs", p.elements.count{it.kind==ElementKind.SWITCH}.toString()); lines += BomLine("Points lumineux", p.elements.count{it.kind==ElementKind.LIGHT}.toString())
        lines += BomLine("Va-et-vient", p.elements.count{it.kind==ElementKind.TWO_WAY_SWITCH}.toString())
        lines += BomLine("Contacteurs", p.elements.count{it.kind==ElementKind.CONTACTOR}.toString())
        lines += BomLine("Boîtes de dérivation", p.elements.count{it.kind==ElementKind.JUNCTION_BOX}.toString())
        p.circuits.forEach { c -> val m=circuitCableMeters(c.id); if(m>0f) lines += BomLine("${c.cableSpec} • ${c.name}", "${"%.1f".format(m)} m") }
        return lines
    }

    fun exportCsv() {
        runCatching {
            val rows=mutableListOf("Type,Name,Quantity,Watts,Amps,Breaker,Cable")
            bom().forEach{rows += csvRow(listOf("BOM",it.name,it.quantity,"","","",""))}
            circuitLoads().forEach{l->rows += csvRow(listOf("Circuit",l.circuitName,"",String.format(Locale.US,"%.0f",l.watts),String.format(Locale.US,"%.2f",l.amps),l.recommendedBreaker,l.recommendedCable))}
            val values=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,"ELHARIKA-Electrical-${System.currentTimeMillis()}.csv");put(MediaStore.Downloads.MIME_TYPE,"text/csv");put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/ELHARIKA")}
            val resolver=getApplication<Application>().contentResolver; val uri=resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)?:error("Cannot create CSV")
            resolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(rows.joinToString("\n"))}?:error("Cannot write CSV");statusMessage.value="CSV exported to Downloads/ELHARIKA"
        }.onFailure{statusMessage.value="CSV export failed: ${it.message ?: "unknown error"}"}
    }

    fun exportPdf() {
        runCatching {
            val p=project.value; val doc=PdfDocument()
            val title=Paint().apply{isAntiAlias=true;textSize=34f;color=android.graphics.Color.rgb(35,45,58);isFakeBoldText=true}
            val text=Paint().apply{isAntiAlias=true;textSize=21f;color=android.graphics.Color.DKGRAY}
            val small=Paint().apply{isAntiAlias=true;textSize=16f;color=android.graphics.Color.DKGRAY}
            val thin=Paint().apply{isAntiAlias=true;strokeWidth=3f;style=Paint.Style.STROKE;color=android.graphics.Color.rgb(80,90,104)}
            val cable=Paint().apply{isAntiAlias=true;strokeWidth=5f;style=Paint.Style.STROKE;color=android.graphics.Color.rgb(36,87,214)}
            p.floors.forEachIndexed { index,floor ->
                val page=doc.startPage(PdfDocument.PageInfo.Builder(1240,1754,index+1).create()); val c=page.canvas
                c.drawText("ELHARIKA Electrical Designer 3D",60f,65f,title); c.drawText("${p.name} • ${floor.name}",60f,105f,text)
                val items=p.elements.filter{it.floorId==floor.id && p.isVisible(it)}
                val points=items.flatMap{it.geometryPoints()}
                val minX=points.minOfOrNull{it.x}?:0f; val minY=points.minOfOrNull{it.y}?:0f
                val width=((points.maxOfOrNull{it.x}?:minX)-minX).coerceAtLeast(1f)
                val height=((points.maxOfOrNull{it.y}?:minY)-minY).coerceAtLeast(1f)
                val scale=minOf(1050f/width,1400f/height,1f)
                val left=80f-minX*scale; val top=180f-minY*scale
                items.filter{it.kind==ElementKind.ROOM}.forEach{r->val b=r.end?:return@forEach; val fill=Paint().apply{color=android.graphics.Color.rgb(247,248,250);style=Paint.Style.FILL}; c.drawRect(left+r.start.x*scale,top+r.start.y*scale,left+b.x*scale,top+b.y*scale,fill)}
                items.filter{it.kind==ElementKind.WALL}.forEach{e->val b=e.end?:return@forEach;c.drawLine(left+e.start.x*scale,top+e.start.y*scale,left+b.x*scale,top+b.y*scale,thin)}
                items.filter{it.kind==ElementKind.CABLE}.forEach{e->e.geometryPoints().zipWithNext().forEach{(a,b)->c.drawLine(left+a.x*scale,top+a.y*scale,left+b.x*scale,top+b.y*scale,cable)}}
                items.filter{it.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.JUNCTION_BOX,ElementKind.LIGHT,ElementKind.PANEL)}.forEach{e->c.drawCircle(left+e.start.x*scale,top+e.start.y*scale,7f,thin);c.drawText(e.label.ifBlank{e.kind.name},left+e.start.x*scale+10f,top+e.start.y*scale-7f,small)}
                c.drawText("Floor cable: ${"%.1f".format(items.filter{it.kind==ElementKind.CABLE}.sumOf{p.cableMeters(it).toDouble()})} m",60f,1660f,text)
                doc.finishPage(page)
            }
            var pageNumber=p.floors.size+1
            var summary=doc.startPage(PdfDocument.PageInfo.Builder(1240,1754,pageNumber).create())
            var c=summary.canvas
            var y=70f
            fun row(label:String, value:String="", heading:Boolean=false) {
                if(y>1610f) {
                    doc.finishPage(summary); pageNumber++
                    summary=doc.startPage(PdfDocument.PageInfo.Builder(1240,1754,pageNumber).create())
                    c=summary.canvas; y=70f
                }
                c.drawText(label.take(110),60f,y,if(heading)title else text)
                if(value.isNotBlank()) c.drawText(value,900f,y,text)
                y+=if(heading)48f else 31f
            }
            row("Project summary",heading=true)
            row("${p.name} • ${p.floors.size} floor(s) • ${"%.1f".format(totalCableMeters())} m cable")
            row("Bill of materials",heading=true)
            bom().forEach{line->row(line.name,line.quantity)}
            row("Electrical load analysis",heading=true)
            circuitLoads().forEach{l->row("${l.circuitName}: ${"%.0f".format(l.watts)} W • ${"%.2f".format(l.amps)} A • ${l.recommendedBreaker} • ${l.recommendedCable}")}
            row("Tableau TD01",heading=true)
            panelLines().forEach{line->row("${line.breaker}  ${line.circuitName}   ${line.cable}   ${line.loadCount} pts   ${"%.1f".format(line.cableMeters)} m")}
            doc.finishPage(summary)
            val values=ContentValues().apply{put(MediaStore.Downloads.DISPLAY_NAME,"ELHARIKA-Electrical-${System.currentTimeMillis()}.pdf");put(MediaStore.Downloads.MIME_TYPE,"application/pdf");put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/ELHARIKA")}
            val resolver=getApplication<Application>().contentResolver; val uri=resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)?:error("Cannot create PDF")
            try { resolver.openOutputStream(uri)?.use{doc.writeTo(it)}?:error("Cannot write PDF") } finally { doc.close() }; statusMessage.value="Multi-page PDF exported to Downloads/ELHARIKA"
        }.onFailure{statusMessage.value="PDF export failed: ${it.message ?: "unknown error"}"}
    }

    private fun findEndpointConnections(a:Point2,b:Point2):List<Long>{ val candidates=project.value.visibleActiveElements().filter{it.kind in listOf(ElementKind.SOCKET,ElementKind.SWITCH,ElementKind.TWO_WAY_SWITCH,ElementKind.CONTACTOR,ElementKind.LIGHT,ElementKind.PANEL,ElementKind.JUNCTION_BOX)}; return listOfNotNull(candidates.minByOrNull{distance(it.start.offset(),a.offset())}?.takeIf{distance(it.start.offset(),a.offset())<70f}?.id,candidates.minByOrNull{distance(it.start.offset(),b.offset())}?.takeIf{distance(it.start.offset(),b.offset())<70f}?.id).distinct() }
    private fun remapHostedElement(child:DesignElement, oldWall:DesignElement, newWall:DesignElement):DesignElement {
        val oldEnd=oldWall.end?:return child; val newEnd=newWall.end?:return child
        fun tOf(p:Point2):Float{ val dx=oldEnd.x-oldWall.start.x; val dy=oldEnd.y-oldWall.start.y; val den=dx*dx+dy*dy; return if(den<.001f)0f else (((p.x-oldWall.start.x)*dx+(p.y-oldWall.start.y)*dy)/den).coerceIn(0f,1f) }
        fun at(t:Float)=Point2(newWall.start.x+(newEnd.x-newWall.start.x)*t,newWall.start.y+(newEnd.y-newWall.start.y)*t)
        return child.copy(start=at(tOf(child.start)),end=child.end?.let{at(tOf(it))},path=child.path.map{at(tOf(it))})
    }

    private fun inferSectionMm2(spec:String):Float{
        val normalized=spec.replace(',', '.')
        val matches=Regex("""(\d+(?:\.\d+)?)""").findAll(normalized).mapNotNull{it.value.toFloatOrNull()}.toList()
        return matches.lastOrNull()?.coerceIn(.5f,35f) ?: 2.5f
    }

    private fun inferConductorCount(spec:String):Int{
        val m=Regex("""^\s*(\d+)""").find(spec)
        return m?.groupValues?.getOrNull(1)?.toIntOrNull()?.coerceIn(2,7) ?: 3
    }

    private fun chooseSmartRoute(a:List<Point2>,b:List<Point2>,floorId:Long):List<Point2>{
        fun score(path:List<Point2>):Float{
            val crossings=path.zipWithNext().sumOf{(u,v)->project.value.elements.count{w->w.floorId==floorId&&w.kind==ElementKind.WALL&&w.end!=null&&segmentsIntersect(u,v,w.start,w.end!!)}}
            return project.value.pathMeters(path)+crossings*5f
        }
        return if(score(a)<=score(b))a else b
    }
    private fun segmentsIntersect(a:Point2,b:Point2,c:Point2,d:Point2):Boolean{
        val p=lineIntersection(a,b,c,d)?:return false
        fun inside(v:Float,x:Float,y:Float)=v>=minOf(x,y)-1f&&v<=maxOf(x,y)+1f
        return inside(p.x,a.x,b.x)&&inside(p.y,a.y,b.y)&&inside(p.x,c.x,d.x)&&inside(p.y,c.y,d.y)
    }

    private fun nearestWallForPoint(p:Offset):DesignElement? =
        project.value.visibleActiveElements().filter{it.kind==ElementKind.WALL&&it.end!=null}
            .minByOrNull{distanceTo(it,p)}?.takeIf{distanceTo(it,p)<55f}

    private fun projectPointOntoWall(p:Offset,w:DesignElement):Offset{
        val e=w.end?:return p
        val ax=w.start.x;val ay=w.start.y;val bx=e.x;val by=e.y
        val abx=bx-ax;val aby=by-ay;val den=abx*abx+aby*aby
        val t=if(den<=.001f)0f else (((p.x-ax)*abx+(p.y-ay)*aby)/den).coerceIn(0f,1f)
        return Offset(ax+abx*t,ay+aby*t)
    }

    private fun conformPathToWalls(input:List<Point2>,floorId:Long):List<Point2>{
        if(input.size<2)return input
        val walls=project.value.elements.filter{it.floorId==floorId&&it.kind==ElementKind.WALL&&it.end!=null}
        if(walls.isEmpty())return input
        val out=input.mapIndexed{index,p->
            val near=walls.minByOrNull{distanceTo(it,p.offset())}
            if(near!=null&&distanceTo(near,p.offset())<70f) projectPointOntoWall(p.offset(),near).toPoint() else p
        }.distinctAdjacent()
        return simplifyOrthogonal(out).distinctAdjacent()
    }

    private fun nearestWallForSegment(a:Offset,b:Offset):DesignElement?{ val mid=Offset((a.x+b.x)/2f,(a.y+b.y)/2f); return project.value.visibleActiveElements().filter{it.kind==ElementKind.WALL}.minByOrNull{distanceTo(it,mid)}?.takeIf{distanceTo(it,mid)<65f} }
    private fun projectSegmentOntoWall(a:Offset,b:Offset,w:DesignElement):Pair<Offset,Offset>{ val e=w.end?:return Pair(a,b); fun project(p:Offset):Offset{val ax=w.start.x;val ay=w.start.y;val bx=e.x;val by=e.y;val abx=bx-ax;val aby=by-ay;val den=abx*abx+aby*aby;val t=if(den<=.001f)0f else (((p.x-ax)*abx+(p.y-ay)*aby)/den).coerceIn(0f,1f);return Offset(ax+abx*t,ay+aby*t)}; return Pair(project(a),project(b)) }
    private fun simplifyOrthogonal(input:List<Point2>):List<Point2>{ if(input.size<3)return input; val out=mutableListOf(input.first()); for(i in 1 until input.lastIndex){val a=out.last();val b=input[i];val c=input[i+1];val sameX=abs(a.x-b.x)<1f&&abs(b.x-c.x)<1f;val sameY=abs(a.y-b.y)<1f&&abs(b.y-c.y)<1f;if(!sameX&&!sameY) out+=b};out+=input.last();return out }
    private fun List<Point2>.distinctAdjacent():List<Point2>{ val out=mutableListOf<Point2>();forEach{p->if(out.lastOrNull()!=p)out+=p};return out }
    private fun distanceTo(e:DesignElement,p:Offset):Float { val pts=e.geometryPoints(); if(pts.size<2)return distance(e.start.offset(),p); return pts.zipWithNext().minOf{(a,b)->distanceToSegment(a,b,p)} }
    private fun distanceToSegment(a:Point2,b:Point2,p:Offset):Float { val ax=a.x;val ay=a.y;val bx=b.x;val by=b.y;val abx=bx-ax;val aby=by-ay;val den=abx*abx+aby*aby;val t=if(den<=.001f)0f else(((p.x-ax)*abx+(p.y-ay)*aby)/den).coerceIn(0f,1f);return hypot((p.x-(ax+abx*t)).toDouble(),(p.y-(ay+aby*t)).toDouble()).toFloat() }
    private fun distance(a:Offset,b:Offset)=hypot((a.x-b.x).toDouble(),(a.y-b.y).toDouble()).toFloat()
    private fun snap(p:Offset):Offset { val grid=project.value.pixelsPerMeter*project.value.gridMeters; return Offset(round(p.x/grid)*grid,round(p.y/grid)*grid) }
    private fun smartSnapPoint(p:Offset):Offset {
        val grid=snap(p); val candidates=project.value.visibleActiveElements().filter{it.kind==ElementKind.WALL}.flatMap{listOfNotNull(it.start.offset(),it.end?.offset())}
        val near=candidates.minByOrNull{distance(it,p)}; return if(near!=null&&distance(near,p)<28f)near else grid
    }
    private fun lineIntersection(a:Point2,b:Point2,c:Point2,d:Point2):Point2?{
        val den=(a.x-b.x)*(c.y-d.y)-(a.y-b.y)*(c.x-d.x); if(abs(den)<.001f)return null
        val det1=a.x*b.y-a.y*b.x; val det2=c.x*d.y-c.y*d.x
        return Point2((det1*(c.x-d.x)-(a.x-b.x)*det2)/den,(det1*(c.y-d.y)-(a.y-b.y)*det2)/den)
    }

    private fun projectPointOnSegment(p:Offset,a:Offset,b:Offset):Offset{ val abx=b.x-a.x;val aby=b.y-a.y;val den=abx*abx+aby*aby;if(den<.001f)return a;val t=(((p.x-a.x)*abx+(p.y-a.y)*aby)/den).coerceIn(0f,1f);return Offset(a.x+abx*t,a.y+aby*t) }
    private fun smartLine(a:Offset,b:Offset):Offset { val dx=b.x-a.x;val dy=b.y-a.y;return when{abs(dx)<22f->Offset(a.x,b.y);abs(dy)<22f->Offset(b.x,a.y);abs(abs(dx)-abs(dy))<28f->Offset(b.x,a.y+sign(dy)*abs(dx));else->b} }
    private fun Offset.toPoint()=Point2(x,y)
}
