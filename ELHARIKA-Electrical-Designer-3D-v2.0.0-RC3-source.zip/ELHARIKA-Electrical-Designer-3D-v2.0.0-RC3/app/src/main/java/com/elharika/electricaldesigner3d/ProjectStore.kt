package com.elharika.electricaldesigner3d

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ProjectStore(context: Context) {
    private val prefs = context.getSharedPreferences("electrical_designer", Context.MODE_PRIVATE)

    fun save(project: ElectricalProject) {
        val root = JSONObject()
            .put("name", project.name)
            .put("gridMeters", project.gridMeters)
            .put("pixelsPerMeter", project.pixelsPerMeter)
            .put("ceilingHeightMeters", project.ceilingHeightMeters)
            .put("defaultWallThicknessMeters", project.defaultWallThicknessMeters)
            .put("activeCircuitId", project.activeCircuitId)
            .put("activeFloorId", project.activeFloorId)
            .put("activeLayerId", project.activeLayerId)
            .put("supplyVoltage", project.supplyVoltage)

        val circuits = JSONArray()
        project.circuits.forEach { c ->
            circuits.put(JSONObject().put("id", c.id).put("name", c.name).put("cableSpec", c.cableSpec).put("breaker", c.breaker).put("route", c.route.name))
        }
        root.put("circuits", circuits)

        val floors = JSONArray()
        project.floors.forEach { f -> floors.put(JSONObject().put("id", f.id).put("name", f.name).put("elevationMeters", f.elevationMeters)) }
        root.put("floors", floors)

        val layers = JSONArray()
        project.layers.forEach { l -> layers.put(JSONObject().put("id", l.id).put("name", l.name).put("visible", l.visible).put("locked", l.locked)) }
        root.put("layers", layers)

        val elements = JSONArray()
        project.elements.forEach { e ->
            val path = JSONArray(); e.path.forEach { p -> path.put(JSONObject().put("x", p.x).put("y", p.y)) }
            val links = JSONArray(); e.connectedElementIds.forEach { links.put(it) }
            val roomWalls = JSONArray(); e.roomWallIds.forEach { roomWalls.put(it) }
            elements.put(JSONObject()
                .put("id", e.id).put("kind", e.kind.name)
                .put("sx", e.start.x).put("sy", e.start.y)
                .put("ex", e.end?.x).put("ey", e.end?.y)
                .put("label", e.label).put("height", e.heightMeters)
                .put("cableSpec", e.cableSpec).put("circuitId", e.circuitId)
                .put("route", e.route.name).put("path", path).put("links", links)
                .put("hostWallId", e.hostWallId)
                .put("wallThicknessMeters", e.wallThicknessMeters)
                .put("verticalMeters", e.verticalMeters)
                .put("floorId", e.floorId)
                .put("targetFloorId", e.targetFloorId)
                .put("groupId", e.groupId)
                .put("layerId", e.layerId)
                .put("isLocked", e.isLocked)
                .put("isHidden", e.isHidden)
                .put("roomWallIds", roomWalls)
                .put("ratedPowerWatts", e.ratedPowerWatts)
                .put("conduitDiameterMm", e.conduitDiameterMm)
                .put("boxDiameterMm", e.boxDiameterMm)
                .put("boxDepthMm", e.boxDepthMm)
                .put("chaseWidthMm", e.chaseWidthMm)
                .put("chaseDepthMm", e.chaseDepthMm)
                .put("conductorCount", e.conductorCount)
                .put("bendRadiusMm", e.bendRadiusMm)
                .put("embeddedDepthMm", e.embeddedDepthMm)
                .put("wallMounted", e.wallMounted)
                .put("conductorSectionMm2", e.conductorSectionMm2)
                .put("hasProtectiveEarth", e.hasProtectiveEarth)
                .put("pairedElementId", e.pairedElementId)
                .put("controlElementId", e.controlElementId))
        }
        root.put("elements", elements)

        val wireLinks = JSONArray()
        project.wireLinks.forEach { w ->
            wireLinks.put(JSONObject()
                .put("id", w.id)
                .put("circuitId", w.circuitId)
                .put("cableId", w.cableId)
                .put("conductorIndex", w.conductorIndex)
                .put("role", w.role)
                .put("fromElementId", w.fromElementId)
                .put("toElementId", w.toElementId)
                .put("fromTerminal", w.fromTerminal)
                .put("toTerminal", w.toTerminal))
        }
        root.put("wireLinks", wireLinks)

        val simulationStates = JSONArray()
        project.simulationStates.forEach { st ->
            simulationStates.put(JSONObject()
                .put("elementId", st.elementId)
                .put("switchClosed", st.switchClosed)
                .put("fault", st.fault)
                .put("switchPosition", st.switchPosition)
                .put("coilEnergized", st.coilEnergized))
        }
        root.put("simulationStates", simulationStates)

        val ink = JSONArray()
        project.ink.forEach { stroke ->
            val points = JSONArray(); stroke.points.forEach { p -> points.put(JSONObject().put("x",p.x).put("y",p.y).put("pressure",p.pressure)) }
            ink.put(JSONObject().put("id", stroke.id).put("points", points))
        }
        root.put("ink", ink)
        prefs.edit().putString("active_project", root.toString()).apply()
    }

    fun load(): ElectricalProject? {
        val raw = prefs.getString("active_project", null) ?: return null
        return runCatching {
            val root = JSONObject(raw)
            val circuitsJson = root.optJSONArray("circuits") ?: JSONArray()
            val circuits = buildList {
                for (i in 0 until circuitsJson.length()) {
                    val c=circuitsJson.getJSONObject(i)
                    add(Circuit(c.getLong("id"), c.optString("name","Circuit"), c.optString("cableSpec","3×2.5 mm²"), c.optString("breaker","C20"), runCatching{CableRoute.valueOf(c.optString("route","WALL"))}.getOrDefault(CableRoute.WALL)))
                }
            }.ifEmpty { ElectricalProject().circuits }

            val floorsJson=root.optJSONArray("floors")?:JSONArray()
            val floors=buildList { for(i in 0 until floorsJson.length()){ val f=floorsJson.getJSONObject(i); add(BuildingFloor(f.getLong("id"),f.optString("name","Floor ${i+1}"),f.optDouble("elevationMeters", i*3.0).toFloat())) } }.ifEmpty { listOf(BuildingFloor(1L,"Ground floor",0f)) }

            val layersJson=root.optJSONArray("layers")?:JSONArray()
            val layers=buildList { for(i in 0 until layersJson.length()){ val l=layersJson.getJSONObject(i); add(DesignLayer(l.getLong("id"),l.optString("name","Layer ${i+1}"),l.optBoolean("visible",true),l.optBoolean("locked",false))) } }.ifEmpty { listOf(DesignLayer(1L,"Electrical")) }

            val elementsJson=root.optJSONArray("elements")?:JSONArray()
            val elements=buildList {
                for(i in 0 until elementsJson.length()){
                    val o=elementsJson.getJSONObject(i); val hasEnd=!o.isNull("ex")&&!o.isNull("ey")
                    val pathJson=o.optJSONArray("path")?:JSONArray(); val path=buildList {
                        for(j in 0 until pathJson.length()) { val p=pathJson.getJSONObject(j); add(Point2(p.getDouble("x").toFloat(),p.getDouble("y").toFloat())) }
                    }
                    val linksJson=o.optJSONArray("links")?:JSONArray(); val links=buildList { for(j in 0 until linksJson.length()) add(linksJson.optLong(j)) }
                    val roomWallsJson=o.optJSONArray("roomWallIds")?:JSONArray(); val roomWallIds=buildList { for(j in 0 until roomWallsJson.length()) add(roomWallsJson.optLong(j)) }
                    add(DesignElement(
                        id=o.getLong("id"), kind=runCatching{ElementKind.valueOf(o.getString("kind"))}.getOrDefault(ElementKind.WALL),
                        start=Point2(o.getDouble("sx").toFloat(),o.getDouble("sy").toFloat()),
                        end=if(hasEnd)Point2(o.getDouble("ex").toFloat(),o.getDouble("ey").toFloat())else null,
                        label=o.optString("label"), heightMeters=o.optDouble("height",.30).toFloat(),
                        cableSpec=o.optString("cableSpec"), circuitId=if(o.isNull("circuitId"))null else o.optLong("circuitId"),
                        route=runCatching{CableRoute.valueOf(o.optString("route","WALL"))}.getOrDefault(CableRoute.WALL),
                        path=path, connectedElementIds=links,
                        hostWallId=if(o.isNull("hostWallId")) null else o.optLong("hostWallId"),
                        wallThicknessMeters=o.optDouble("wallThicknessMeters",.15).toFloat(),
                        verticalMeters=o.optDouble("verticalMeters",0.0).toFloat(),
                        floorId=o.optLong("floorId", floors.first().id),
                        targetFloorId=if(o.isNull("targetFloorId")) null else o.optLong("targetFloorId"),
                        groupId=if(o.isNull("groupId")) null else o.optLong("groupId"),
                        layerId=o.optLong("layerId", layers.first().id),
                        isLocked=o.optBoolean("isLocked", false),
                        isHidden=o.optBoolean("isHidden", false),
                        roomWallIds=roomWallIds,
                        ratedPowerWatts=o.optDouble("ratedPowerWatts",0.0).toFloat(),
                        conduitDiameterMm=o.optDouble("conduitDiameterMm",20.0).toFloat(),
                        boxDiameterMm=o.optDouble("boxDiameterMm",67.0).toFloat(),
                        boxDepthMm=o.optDouble("boxDepthMm",50.0).toFloat(),
                        chaseWidthMm=o.optDouble("chaseWidthMm",35.0).toFloat(),
                        chaseDepthMm=o.optDouble("chaseDepthMm",25.0).toFloat(),
                        conductorCount=o.optInt("conductorCount",3).coerceIn(2,7),
                        bendRadiusMm=o.optDouble("bendRadiusMm",60.0).toFloat(),
                        embeddedDepthMm=o.optDouble("embeddedDepthMm",25.0).toFloat(),
                        wallMounted=o.optBoolean("wallMounted",false),
                        conductorSectionMm2=o.optDouble("conductorSectionMm2",2.5).toFloat(),
                        hasProtectiveEarth=o.optBoolean("hasProtectiveEarth",true),
                        pairedElementId=if(o.isNull("pairedElementId")) null else o.optLong("pairedElementId"),
                        controlElementId=if(o.isNull("controlElementId")) null else o.optLong("controlElementId")
                    ))
                }
            }
            val inkJson=root.optJSONArray("ink")?:JSONArray(); val ink=buildList {
                for(i in 0 until inkJson.length()){
                    val s=inkJson.getJSONObject(i); val ptsJson=s.getJSONArray("points"); val pts=buildList {
                        for(j in 0 until ptsJson.length()){ val p=ptsJson.getJSONObject(j); add(StrokePoint(p.getDouble("x").toFloat(),p.getDouble("y").toFloat(),p.optDouble("pressure",1.0).toFloat())) }
                    }; add(InkStroke(s.getLong("id"),pts))
                }
            }
            val wireLinksJson=root.optJSONArray("wireLinks")?:JSONArray()
            val wireLinks=buildList {
                for(i in 0 until wireLinksJson.length()){
                    val w=wireLinksJson.getJSONObject(i)
                    add(WireLink(
                        id=w.optLong("id",System.nanoTime()+i),
                        circuitId=w.optLong("circuitId"),
                        cableId=w.optLong("cableId"),
                        conductorIndex=w.optInt("conductorIndex",0),
                        role=w.optString("role","L"),
                        fromElementId=w.optLong("fromElementId"),
                        toElementId=w.optLong("toElementId"),
                        fromTerminal=w.optString("fromTerminal","L"),
                        toTerminal=w.optString("toTerminal","L")
                    ))
                }
            }
            val simulationStatesJson=root.optJSONArray("simulationStates")?:JSONArray()
            val simulationStates=buildList {
                for(i in 0 until simulationStatesJson.length()){
                    val st=simulationStatesJson.getJSONObject(i)
                    add(SimulationState(
                        elementId=st.optLong("elementId"),
                        switchClosed=st.optBoolean("switchClosed",false),
                        fault=st.optString("fault","NONE"),
                        switchPosition=st.optInt("switchPosition",0).coerceIn(0,1),
                        coilEnergized=st.optBoolean("coilEnergized",false)
                    ))
                }
            }
            ElectricalProject(
                name=root.optString("name","Maison 01"), gridMeters=root.optDouble("gridMeters",.25).toFloat(),
                pixelsPerMeter=root.optDouble("pixelsPerMeter",100.0).toFloat(), ceilingHeightMeters=root.optDouble("ceilingHeightMeters",2.70).toFloat(),
                defaultWallThicknessMeters=root.optDouble("defaultWallThicknessMeters",.15).toFloat(),
                elements=elements, ink=ink, circuits=circuits,
                activeCircuitId=root.optLong("activeCircuitId",circuits.first().id).takeIf{id->circuits.any{it.id==id}}?:circuits.first().id,
                floors=floors,
                activeFloorId=root.optLong("activeFloorId",floors.first().id).takeIf{id->floors.any{it.id==id}}?:floors.first().id,
                layers=layers,
                activeLayerId=root.optLong("activeLayerId",layers.first().id).takeIf{id->layers.any{it.id==id}}?:layers.first().id,
                supplyVoltage=root.optDouble("supplyVoltage",230.0).toFloat(),
                wireLinks=wireLinks,
                simulationStates=simulationStates
            )
        }.getOrNull()
    }
}
