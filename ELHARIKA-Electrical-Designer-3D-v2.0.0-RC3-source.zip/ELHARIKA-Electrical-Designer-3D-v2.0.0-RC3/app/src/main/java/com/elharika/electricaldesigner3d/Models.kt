package com.elharika.electricaldesigner3d

import androidx.compose.ui.geometry.Offset
import kotlin.math.hypot

enum class EditorTool(val label: String) {
    SELECT("Select"), PEN("Pen"), WALL("Wall"), ROOM("Room"), DOOR("Door"), WINDOW("Window"),
    CABLE("Cable Path"), SOCKET("Socket"), SWITCH("Switch"), TWO_WAY_SWITCH("Va-et-vient"), CONTACTOR("Contactor"), LIGHT("Light"), PANEL("Panel"), JUNCTION_BOX("Junction box"), STAIRCASE("Staircase"), RISER("Riser"), ERASER("Eraser")
}

enum class ViewMode { PLAN_2D, VIEW_3D }
enum class WallView3D { OPAQUE, TRANSPARENT, HIDDEN }
enum class ElementKind { WALL, ROOM, DOOR, WINDOW, CABLE, SOCKET, SWITCH, TWO_WAY_SWITCH, CONTACTOR, LIGHT, PANEL, JUNCTION_BOX, STAIRCASE, RISER }
enum class CableRoute(val label: String) { WALL("Wall"), CEILING("Ceiling"), FLOOR("Floor"), SURFACE("Surface") }

data class BuildingFloor(val id: Long, val name: String, val elevationMeters: Float = 0f)
data class DesignLayer(val id: Long, val name: String, val visible: Boolean = true, val locked: Boolean = false)

data class Point2(val x: Float, val y: Float) { fun offset() = Offset(x, y) }
data class StrokePoint(val x: Float, val y: Float, val pressure: Float = 1f)
data class InkStroke(val id: Long, val points: List<StrokePoint>)

data class WireLink(
    val id: Long,
    val circuitId: Long,
    val cableId: Long,
    val conductorIndex: Int,
    val role: String,
    val fromElementId: Long,
    val toElementId: Long,
    val fromTerminal: String,
    val toTerminal: String
)

data class SimulationState(
    val elementId: Long,
    val switchClosed: Boolean = false,
    val fault: String = "NONE",
    val switchPosition: Int = 0,
    val coilEnergized: Boolean = false
)

data class SimulationResult(
    val energizedElementIds: Set<Long> = emptySet(),
    val energizedWireLinkIds: Set<Long> = emptySet(),
    val litLightIds: Set<Long> = emptySet(),
    val trippedCircuitIds: Set<Long> = emptySet(),
    val terminalVoltages: Map<String, Float> = emptyMap(),
    val messages: List<String> = emptyList()
)

data class WiringIssue(
    val circuitId: Long,
    val severity: String,
    val message: String,
    val elementId: Long? = null
)


data class Circuit(
    val id: Long,
    val name: String,
    val cableSpec: String = "3×2.5 mm²",
    val breaker: String = "C20",
    val route: CableRoute = CableRoute.WALL
)

data class DesignElement(
    val id: Long,
    val kind: ElementKind,
    val start: Point2,
    val end: Point2? = null,
    val label: String = "",
    val heightMeters: Float = 0.30f,
    val cableSpec: String = "",
    val circuitId: Long? = null,
    val route: CableRoute = CableRoute.WALL,
    val path: List<Point2> = emptyList(),
    val connectedElementIds: List<Long> = emptyList(),
    val hostWallId: Long? = null,
    val wallThicknessMeters: Float = 0.15f,
    val verticalMeters: Float = 0f,
    val floorId: Long = 1L,
    val targetFloorId: Long? = null,
    val groupId: Long? = null,
    val layerId: Long = 1L,
    val isLocked: Boolean = false,
    val isHidden: Boolean = false,
    val roomWallIds: List<Long> = emptyList(),
    val ratedPowerWatts: Float = 0f,
    val conduitDiameterMm: Float = 20f,
    val boxDiameterMm: Float = 67f,
    val boxDepthMm: Float = 50f,
    val chaseWidthMm: Float = 35f,
    val chaseDepthMm: Float = 25f,
    val conductorCount: Int = 3,
    val bendRadiusMm: Float = 60f,
    val embeddedDepthMm: Float = 25f,
    val wallMounted: Boolean = false,
    val conductorSectionMm2: Float = 2.5f,
    val hasProtectiveEarth: Boolean = true,
    val pairedElementId: Long? = null,
    val controlElementId: Long? = null
) {
    fun geometryPoints(): List<Point2> = if (path.size >= 2) path else listOfNotNull(start, end)
}

data class ElectricalProject(
    val name: String = "Maison 01",
    val gridMeters: Float = 0.25f,
    val pixelsPerMeter: Float = 100f,
    val ceilingHeightMeters: Float = 2.70f,
    val defaultWallThicknessMeters: Float = 0.15f,
    val elements: List<DesignElement> = emptyList(),
    val ink: List<InkStroke> = emptyList(),
    val circuits: List<Circuit> = listOf(
        Circuit(1L, "PC-01"),
        Circuit(2L, "ECL-01", "3×1.5 mm²", "C10", CableRoute.CEILING)
    ),
    val activeCircuitId: Long = 1L,
    val floors: List<BuildingFloor> = listOf(BuildingFloor(1L, "Ground floor", 0f)),
    val activeFloorId: Long = 1L,
    val layers: List<DesignLayer> = listOf(DesignLayer(1L, "Electrical")),
    val activeLayerId: Long = 1L,
    val supplyVoltage: Float = 230f,
    val wireLinks: List<WireLink> = emptyList(),
    val simulationStates: List<SimulationState> = emptyList()
) {
    init {
        require(pixelsPerMeter.isFinite() && pixelsPerMeter > 0f) { "Invalid drawing scale" }
        require(gridMeters.isFinite() && gridMeters > 0f) { "Invalid grid size" }
    }
    fun metersBetween(a: Point2, b: Point2): Float = hypot(b.x - a.x, b.y - a.y) / pixelsPerMeter
    fun pathMeters(points: List<Point2>): Float = points.zipWithNext().sumOf { (a,b) -> metersBetween(a,b).toDouble() }.toFloat()
    fun cableMeters(element: DesignElement): Float = pathMeters(element.geometryPoints()) + element.verticalMeters.coerceAtLeast(0f)
    fun circuit(id: Long?): Circuit? = circuits.firstOrNull { it.id == id }
    fun floor(id: Long?): BuildingFloor? = floors.firstOrNull { it.id == id }
    fun activeElements(): List<DesignElement> = elements.filter { it.floorId == activeFloorId }
    fun layer(id: Long?): DesignLayer? = layers.firstOrNull { it.id == id }
    fun isVisible(element: DesignElement): Boolean = !element.isHidden && (layer(element.layerId)?.visible != false)
    fun isLocked(element: DesignElement): Boolean = element.isLocked || (layer(element.layerId)?.locked == true)
    fun visibleActiveElements(): List<DesignElement> = activeElements().filter(::isVisible)
    fun visibleElements(): List<DesignElement> = elements.filter(::isVisible)
}

data class BomLine(val name: String, val quantity: String)
data class PanelLine(val circuitName: String, val breaker: String, val cable: String, val loadCount: Int, val cableMeters: Float)

data class CircuitCheck(val circuitId: Long, val circuitName: String, val loadCount: Int, val cableCount: Int, val openLoads: Int, val warnings: List<String>)
data class CircuitLoad(val circuitId:Long,val circuitName:String,val watts:Float,val amps:Float,val breakerAmps:Int,val recommendedBreaker:String,val recommendedCable:String,val utilizationPercent:Float)

internal fun csvRow(values: List<String>): String = values.joinToString(",") { value ->
    val safe = if(value.trimStart().firstOrNull() in listOf('=', '+', '-', '@')) "'" + value else value
    "\"" + safe.replace("\"", "\"\"") + "\""
}
