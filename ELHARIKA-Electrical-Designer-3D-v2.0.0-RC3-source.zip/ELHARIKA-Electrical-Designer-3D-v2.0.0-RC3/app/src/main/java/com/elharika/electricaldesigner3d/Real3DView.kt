package com.elharika.electricaldesigner3d

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.filament.MaterialInstance
import io.github.sceneview.Scene
import io.github.sceneview.rememberCameraManipulator
import io.github.sceneview.rememberCameraNode
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberEnvironmentLoader
import io.github.sceneview.rememberMaterialLoader
import io.github.sceneview.rememberModelLoader
import io.github.sceneview.math.Position
import io.github.sceneview.math.Rotation
import io.github.sceneview.math.Size
import io.github.sceneview.node.CubeNode
import io.github.sceneview.node.CylinderNode
import io.github.sceneview.node.Node
import io.github.sceneview.node.ModelNode
import io.github.sceneview.node.SphereNode
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.hypot

/**
 * Real 3D renderer backed by SceneView 2.3.0 + Google Filament.
 *
 * The existing 2D editor remains untouched. This screen consumes a pure Real3DScene generated
 * from ElectricalProject, so replacing/upgrading the renderer later doesn't change project data.
 */
@Composable
fun Real3DView(
    vm: EditorViewModel,
    showControls: Boolean = true,
    workspaceBackground: Color = Color(0xFFE9EDF2)
) {
    val project = vm.project.value
    val simulationResult = vm.lastSimulation.value
    val energizedCableIds = remember(project.wireLinks, simulationResult.energizedWireLinkIds) {
        project.wireLinks.asSequence()
            .filter { it.id in simulationResult.energizedWireLinkIds }
            .map { it.cableId }
            .toSet()
    }
    val options = Real3DOptions(
        showAllFloors = vm.showAllFloors3D.value,
        wallView = vm.wallView3D.value,
        cutaway = vm.cutaway3D.value,
        installationMode = vm.installation3DMode.value,
        constructionMode = vm.constructionMode3D.value,
        installationStage = vm.installationStage3D.intValue,
        showChases = vm.showChases3D.value,
        showConduits = vm.showConduits3D.value,
        showConductors = vm.showConductors3D.value,
        showBoxes = vm.showBoxes3D.value,
        isolatedCircuitId = vm.isolatedCircuit3D.value,
        hiddenCircuitIds = vm.hiddenCircuitIds3D.value,
        simulationHighlight = vm.simulationEnabled.value,
        energizedCableIds = energizedCableIds,
        energizedElementIds = simulationResult.energizedElementIds,
        trippedCircuitIds = simulationResult.trippedCircuitIds,
        quality = vm.real3DQuality.value
    )
    val sceneSpec = remember(project, options) { Real3DSceneBuilder.build(project, options) }

    // SceneView 2.3.0 is deliberately used here because the validated app currently targets
    // Kotlin 2.0.21 / Java 17. SceneView 4.x requires a newer Android/Kotlin/JDK toolchain.
    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine)
    val materialLoader = rememberMaterialLoader(engine)
    val environmentLoader = rememberEnvironmentLoader(engine)
    val context = LocalContext.current
    val availableAssets = remember(context) {
        ElectricalAssetCatalog.requiredPaths().filterTo(mutableSetOf()) { path ->
            runCatching { context.assets.open(path).use { true } }.getOrDefault(false)
        }
    }

    val materials = remember(materialLoader) { createReal3DMaterials(materialLoader) }
    val childNodes = remember(sceneSpec, engine, materials, modelLoader, availableAssets) {
        sceneSpec.primitives.mapNotNull { primitive ->
            runCatching {
                primitive.toSceneViewNode(engine, materials, modelLoader, availableAssets)
            }.getOrElse {
                runCatching { primitive.toProceduralSceneViewNode(engine, materials) }.getOrNull()
            }
        }
    }
    DisposableEffect(childNodes) {
        onDispose { childNodes.forEach(Node::destroy) }
    }

    val cameraNode = rememberCameraNode(engine)
    val cameraDistance = remember(sceneSpec) {
        maxOf(sceneSpec.widthMeters, sceneSpec.depthMeters, sceneSpec.heightMeters).coerceAtLeast(4f) * 1.35f
    }
    LaunchedEffect(cameraDistance, sceneSpec.center) {
        cameraNode.position = Position(cameraDistance, cameraDistance * 0.72f, cameraDistance)
        cameraNode.lookAt(Position(sceneSpec.center.x, sceneSpec.heightMeters * 0.35f, sceneSpec.center.z))
    }
    val cameraManipulator = rememberCameraManipulator(
        orbitHomePosition = cameraNode.worldPosition,
        targetPosition = Position(sceneSpec.center.x, sceneSpec.heightMeters * 0.35f, sceneSpec.center.z)
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(workspaceBackground, RoundedCornerShape(12.dp))
    ) {
        Scene(
            modifier = Modifier.fillMaxSize(),
            engine = engine,
            modelLoader = modelLoader,
            materialLoader = materialLoader,
            environmentLoader = environmentLoader,
            cameraNode = cameraNode,
            cameraManipulator = cameraManipulator,
            childNodes = childNodes
        )

        if (showControls) {
        Column(
            Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .widthIn(max = 350.dp)
                .background(Color.White.copy(alpha = 0.94f), RoundedCornerShape(12.dp))
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Real 3D • Filament", style = MaterialTheme.typography.titleSmall)
                AssistChip(onClick = {}, label = { Text("SceneView 2.3", fontSize = 9.sp) })
            }
            Text(
                "${sceneSpec.primitives.size} meshes • ${vm.real3DQuality.value.label} • ${"%.1f".format(sceneSpec.widthMeters)} × ${"%.1f".format(sceneSpec.depthMeters)} m",
                fontSize = 10.sp,
                color = Color.Gray
            )
            Text(
                "Photoreal assets: ${availableAssets.size}/${ElectricalAssetCatalog.all.size} GLB",
                fontSize = 9.sp,
                color = if (availableAssets.isEmpty()) Color(0xFFB26A00) else Color(0xFF2B7A3D)
            )
            if (vm.simulationEnabled.value) {
                Text(
                    "LIVE 3D • ${energizedCableIds.size} energized route(s) • ${simulationResult.trippedCircuitIds.size} trip(s)",
                    fontSize = 9.sp,
                    color = if (simulationResult.trippedCircuitIds.isEmpty()) Color(0xFFB26A00) else Color(0xFFC62828)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(
                    selected = vm.installation3DMode.value,
                    onClick = { vm.setInstallation3DMode(true) },
                    label = { Text("Installation", fontSize = 9.sp) }
                )
                FilterChip(
                    selected = !vm.installation3DMode.value,
                    onClick = { vm.setInstallation3DMode(false) },
                    label = { Text("Architecture", fontSize = 9.sp) }
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = vm.constructionMode3D.value, onCheckedChange = vm::setConstructionMode3D)
                Spacer(Modifier.width(4.dp)); Text("Construction", fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = vm.cutaway3D.value, onCheckedChange = vm::setCutaway3D)
                Spacer(Modifier.width(4.dp)); Text("Cutaway", fontSize = 10.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = vm.showAllFloors3D.value, onCheckedChange = vm::setShowAllFloors3D)
                Spacer(Modifier.width(4.dp)); Text("All floors", fontSize = 10.sp)
            }
            Text("Walls", fontSize = 9.sp, color = Color.Gray)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                WallView3D.entries.forEach { mode ->
                    FilterChip(
                        selected = vm.wallView3D.value == mode,
                        onClick = { vm.setWallView3D(mode) },
                        label = { Text(mode.name.lowercase(), fontSize = 8.sp) }
                    )
                }
            }
            Text("3D quality", fontSize = 9.sp, color = Color.Gray)
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                Real3DQuality.entries.forEach { quality ->
                    FilterChip(
                        selected = vm.real3DQuality.value == quality,
                        onClick = { vm.setReal3DQuality(quality) },
                        label = { Text(quality.label, fontSize = 8.sp) }
                    )
                }
            }
            if (vm.installation3DMode.value) {
                Text("Execution stage", fontSize = 9.sp, color = Color.Gray)
                val stages = listOf("Tableau", "Saignées", "Gaines", "Boîtes", "Fils", "Appareils")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    stages.forEachIndexed { index, name ->
                        FilterChip(
                            selected = vm.installationStage3D.intValue == index,
                            onClick = { vm.setInstallationStage3D(index) },
                            label = { Text(name, fontSize = 8.sp) }
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = vm.showConduits3D.value, onCheckedChange = vm::setShowConduits3D)
                    Spacer(Modifier.width(4.dp)); Text("Gaines", fontSize = 10.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = vm.showConductors3D.value, onCheckedChange = vm::setShowConductors3D)
                    Spacer(Modifier.width(4.dp)); Text("Fils L/N/PE", fontSize = 10.sp)
                }
            }
            Text("Circuit", fontSize = 9.sp, color = Color.Gray)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                FilterChip(
                    selected = vm.isolatedCircuit3D.value == null,
                    onClick = { vm.setIsolatedCircuit3D(null) },
                    label = { Text("All", fontSize = 8.sp) }
                )
                project.circuits.forEach { circuit ->
                    FilterChip(
                        selected = vm.isolatedCircuit3D.value == circuit.id,
                        onClick = { vm.setIsolatedCircuit3D(circuit.id) },
                        label = { Text(circuit.name, fontSize = 8.sp) }
                    )
                }
            }
            OutlinedButton(
                onClick = { vm.setReal3DEnabled(false) },
                modifier = Modifier.widthIn(min = 180.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
            ) { Text("Legacy 3D fallback", fontSize = 9.sp) }
        }
        }
    }
}

private fun createReal3DMaterials(loader: io.github.sceneview.loaders.MaterialLoader): Map<String, MaterialInstance> = mapOf(
    "default" to loader.createColorInstance(Color(0xFFD3D7DC), roughness = 0.75f),
    "wall" to loader.createColorInstance(Color(0xFFE7E4DC), roughness = 0.92f),
    "wall-transparent" to loader.createColorInstance(Color(0x55D8DCE2), roughness = 0.8f),
    "concrete" to loader.createColorInstance(Color(0xFFBFC3C6), roughness = 1.0f),
    "floor" to loader.createColorInstance(Color(0xFFD7D0C5), roughness = 0.86f),
    "door" to loader.createColorInstance(Color(0xFF7A5235), roughness = 0.7f),
    "window" to loader.createColorInstance(Color(0x886DB7D8), roughness = 0.18f, reflectance = 0.7f),
    "chase" to loader.createColorInstance(Color(0xFF8A715D), roughness = 1f),
    "conduit" to loader.createColorInstance(Color(0xFF8C9298), metallic = 0.03f, roughness = 0.42f),
    "energized-orange" to loader.createColorInstance(Color(0xFFFF8A22), metallic = 0.02f, roughness = 0.22f, reflectance = 0.9f),
    "trip-red" to loader.createColorInstance(Color(0xFFE02020), metallic = 0.02f, roughness = 0.28f, reflectance = 0.9f),
    "energized-device" to loader.createColorInstance(Color(0xFFFFC247), metallic = 0.03f, roughness = 0.20f, reflectance = 0.95f),
    "bundle-rail" to loader.createColorInstance(Color(0xFF6F747A), metallic = 0.72f, roughness = 0.30f),
    "conduit-fitting" to loader.createColorInstance(Color(0xFF777D83), metallic = 0.04f, roughness = 0.38f),
    "circuit-red" to loader.createColorInstance(Color(0xFFD83232), roughness = 0.34f, reflectance = 0.55f),
    "circuit-blue" to loader.createColorInstance(Color(0xFF245FD6), roughness = 0.34f, reflectance = 0.55f),
    "circuit-yellow" to loader.createColorInstance(Color(0xFFE2A91B), roughness = 0.34f, reflectance = 0.55f),
    "circuit-green" to loader.createColorInstance(Color(0xFF2F9A5E), roughness = 0.34f, reflectance = 0.55f),
    "circuit-orange" to loader.createColorInstance(Color(0xFFE06A2E), roughness = 0.34f, reflectance = 0.55f),
    "circuit-violet" to loader.createColorInstance(Color(0xFF7551C9), roughness = 0.34f, reflectance = 0.55f),
    "support-metal" to loader.createColorInstance(Color(0xFF4E5359), metallic = 0.62f, roughness = 0.32f),
    "support-clamp" to loader.createColorInstance(Color(0xFF858B91), metallic = 0.48f, roughness = 0.36f),
    "screw-metal" to loader.createColorInstance(Color(0xFFB9BEC3), metallic = 0.78f, roughness = 0.24f),
    "phase" to loader.createColorInstance(Color(0xFFC64232), roughness = 0.45f),
    "neutral" to loader.createColorInstance(Color(0xFF2466A8), roughness = 0.45f),
    "earth" to loader.createColorInstance(Color(0xFF2E8A4C), roughness = 0.45f),
    "box" to loader.createColorInstance(Color(0xFF656B72), roughness = 0.65f),
    "recessed-box" to loader.createColorInstance(Color(0xFF4F77A8), roughness = 0.58f),
    "junction-box" to loader.createColorInstance(Color(0xFFB9B8AC), roughness = 0.62f),
    "branch-box" to loader.createColorInstance(Color(0xFF8FA3B5), roughness = 0.52f),
    "junction-gland" to loader.createColorInstance(Color(0xFF5E6872), metallic = 0.18f, roughness = 0.42f),
    "box-rim" to loader.createColorInstance(Color(0xFF3F6595), roughness = 0.5f),
    "device" to loader.createColorInstance(Color(0xFFF7F7F5), roughness = 0.35f),
    "light" to loader.createColorInstance(Color(0xFFFFD76A), roughness = 0.25f, reflectance = 0.8f),
    "contactor" to loader.createColorInstance(Color(0xFFD8D9D6), roughness = 0.55f),
    "panel" to loader.createColorInstance(Color(0xFF42474D), metallic = 0.15f, roughness = 0.5f),
    "din-rail" to loader.createColorInstance(Color(0xFFB8BDC2), metallic = 0.72f, roughness = 0.28f),
    "breaker" to loader.createColorInstance(Color(0xFFE5E7E8), roughness = 0.45f),
    "terminal-neutral" to loader.createColorInstance(Color(0xFF2466A8), metallic = 0.1f, roughness = 0.4f),
    "terminal-earth" to loader.createColorInstance(Color(0xFF4A9B55), metallic = 0.08f, roughness = 0.42f),
    "riser" to loader.createColorInstance(Color(0xFFB35C44), roughness = 0.5f)
)

private fun Real3DPrimitive.assetKeyOrNull(): String? = when (this) {
    is Real3DPrimitive.Box -> assetKey
    is Real3DPrimitive.Sphere -> assetKey
    is Real3DPrimitive.Tube -> assetKey
}

private fun Real3DPrimitive.worldPosition(): Position = when (this) {
    is Real3DPrimitive.Box -> Position(center.x, center.y, center.z)
    is Real3DPrimitive.Sphere -> Position(center.x, center.y, center.z)
    is Real3DPrimitive.Tube -> Position(
        (start.x + end.x) / 2f,
        (start.y + end.y) / 2f,
        (start.z + end.z) / 2f
    )
}

private fun Real3DPrimitive.worldYawDegrees(): Float = when (this) {
    is Real3DPrimitive.Box -> yawDegrees
    is Real3DPrimitive.Sphere -> 0f
    is Real3DPrimitive.Tube -> {
        val dx=end.x-start.x; val dz=end.z-start.z
        if (kotlin.math.abs(dx)+kotlin.math.abs(dz) < 0.0001f) 0f
        else -Math.toDegrees(atan2(dz.toDouble(), dx.toDouble())).toFloat()
    }
}

/** Prefer a real GLB model when bundled; otherwise preserve the tested procedural renderer. */
private fun Real3DPrimitive.toSceneViewNode(
    engine: com.google.android.filament.Engine,
    materials: Map<String, MaterialInstance>,
    modelLoader: io.github.sceneview.loaders.ModelLoader,
    availableAssets: Set<String>
): Node {
    val spec = ElectricalAssetCatalog[assetKeyOrNull()]
    if (spec != null && spec.assetPath in availableAssets) {
        val instance = modelLoader.createModelInstance(assetFileLocation = spec.assetPath)
        return ModelNode(
            modelInstance = instance,
            scaleToUnits = spec.scaleToUnitsMeters
        ).apply {
            name = this@toSceneViewNode.id
            position = this@toSceneViewNode.worldPosition()
            rotation = when (val p=this@toSceneViewNode) {
                is Real3DPrimitive.Sphere -> Rotation(
                    x = p.rotationXDegrees,
                    y = p.rotationYDegrees + spec.yawOffsetDegrees,
                    z = p.rotationZDegrees
                )
                else -> Rotation(y = p.worldYawDegrees() + spec.yawOffsetDegrees)
            }
            isHittable = false
            isTouchable = false
        }
    }
    return toProceduralSceneViewNode(engine, materials)
}

private fun Real3DPrimitive.toProceduralSceneViewNode(
    engine: com.google.android.filament.Engine,
    materials: Map<String, MaterialInstance>
): Node = when (this) {
    is Real3DPrimitive.Box -> CubeNode(
        engine = engine,
        size = Size(size.x, size.y, size.z),
        materialInstance = materials[materialKey] ?: materials.getValue("default")
    ).apply {
        name = id
        position = Position(center.x, center.y, center.z)
        rotation = Rotation(y = yawDegrees)
        isHittable = false
        isTouchable = false
    }

    is Real3DPrimitive.Sphere -> SphereNode(
        engine = engine,
        radius = radiusMeters,
        materialInstance = materials[materialKey] ?: materials.getValue("device")
    ).apply {
        name = id
        position = Position(center.x, center.y, center.z)
        isHittable = false
        isTouchable = false
    }

    is Real3DPrimitive.Tube -> {
        val dx = end.x - start.x
        val dy = end.y - start.y
        val dz = end.z - start.z
        val length = kotlin.math.sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(0.001f)
        val horizontal = hypot(dx.toDouble(), dz.toDouble()).toFloat()
        val alpha = acos((dy / length).coerceIn(-1f, 1f))
        val beta = if (horizontal < 0.0001f) 0f else atan2(dz.toDouble(), (-dx).toDouble()).toFloat()
        val alphaDeg = Math.toDegrees(alpha.toDouble()).toFloat()
        val betaDeg = Math.toDegrees(beta.toDouble()).toFloat()
        CylinderNode(
            engine = engine,
            radius = radiusMeters,
            height = length,
            sideCount = 16,
            materialInstance = materials[materialKey] ?: materials.getValue("conduit")
        ).apply {
            name = id
            position = Position(
                (start.x + end.x) / 2f,
                (start.y + end.y) / 2f,
                (start.z + end.z) / 2f
            )
            // Cylinder local axis is +Y. Z then Y rotation aligns it to the segment vector.
            rotation = Rotation(y = betaDeg, z = alphaDeg)
            isHittable = false
            isTouchable = false
        }
    }
}
