# ELHARIKA Electrical 3D Asset Licenses

## Embedded alpha6 mobile GLB pack
The 15 GLB files under `models/electrical/` in this source package were generated for this project from procedural geometry and are part of the ELHARIKA project source.

They are not redistributed Poly Haven binaries.

## External replacements
Future higher-detail CC0 replacements may be imported from Poly Haven or another source. When that happens, retain the original asset name, source URL and license in this file and in the manifest.
