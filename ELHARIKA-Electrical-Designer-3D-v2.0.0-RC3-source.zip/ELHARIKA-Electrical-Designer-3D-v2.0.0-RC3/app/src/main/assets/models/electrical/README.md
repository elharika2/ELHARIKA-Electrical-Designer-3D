# Photoreal electrical GLB assets

Place optimized GLB models here. The app checks each file at runtime and uses it only when present; otherwise the procedural Real3D node remains visible.

Expected filenames:
- conduit_elbow_90.glb
- conduit_coupler.glb
- conduit_t_branch.glb
- conduit_clamp.glb
- junction_box.glb
- recessed_box_67.glb
- socket_eu.glb
- switch_1gang.glb
- switch_two_way.glb
- contactor_din.glb
- distribution_panel.glb
- breaker_1p.glb
- din_rail.glb
- terminal_bar_n.glb
- terminal_bar_pe.glb

Recommended source priority:
1. Poly Haven CC0: Modular Pipes Plastic 01 / Modular Pipes for pipes, elbows, clamps and fittings.
2. Poly Haven CC0: Power Box 01 for a realistic distribution/power-box reference.
3. Custom-authored or manufacturer-approved assets for sockets, switches, recessed boxes, breakers and DIN hardware.

Mobile target:
- Prefer GLB, not loose glTF dependencies.
- 1K or 2K textures for frequently repeated parts.
- Aim below 10 MB per interactive model.
- Strip unused animations/materials and use mesh/texture compression where compatible.
