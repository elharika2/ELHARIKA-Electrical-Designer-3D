package com.elharika.electricaldesigner3d

import android.app.Application
import android.content.ContentUris
import android.graphics.pdf.PdfRenderer
import android.provider.MediaStore
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith

/** Runs on a real Android device/emulator: Robolectric 4.14 lacks PdfDocument support. */
@RunWith(AndroidJUnit4::class)
class NativePdfExportTest {
    @Test fun largePlanProducesReadableTwoPagePdf() = exportAndCheck(2) { vm ->
        vm.project.value=ElectricalProject(elements=listOf(DesignElement(1,ElementKind.WALL,Point2(-500f,-300f),Point2(5000f,4000f))))
    }
    @Test fun longSummaryCreatesAdditionalPages() = exportAndCheck(4) { vm ->
        vm.project.value=ElectricalProject(circuits=(1L..80L).map{Circuit(it,"Circuit $it")})
    }
    private fun exportAndCheck(minPages:Int, setup:(EditorViewModel)->Unit) {
        val instrumentation=InstrumentationRegistry.getInstrumentation()
        val app=instrumentation.targetContext.applicationContext as Application
        val resolver=app.contentResolver
        val collection=MediaStore.Downloads.EXTERNAL_CONTENT_URI
        fun ids():Set<Long> = buildSet {
            resolver.query(collection,arrayOf(MediaStore.Downloads._ID),null,null,null)?.use { c ->
                while(c.moveToNext()) add(c.getLong(0))
            }
        }
        val before=ids()
        instrumentation.runOnMainSync {
            val vm=EditorViewModel(app); setup(vm); vm.exportPdf()
            assertTrue(vm.statusMessage.value,vm.statusMessage.value.startsWith("Multi-page PDF exported"))
        }
        val newIds=ids()-before
        assertEquals(1,newIds.size)
        val uri=ContentUris.withAppendedId(collection,newIds.single())
        try {
            PdfRenderer(resolver.openFileDescriptor(uri,"r")!!).use { pdf ->
                assertTrue("Expected at least $minPages pages, found ${pdf.pageCount}",pdf.pageCount>=minPages)
                pdf.openPage(0).use { page -> assertTrue(page.width>0 && page.height>0) }
            }
        } finally { resolver.delete(uri,null,null) }
    }
}
