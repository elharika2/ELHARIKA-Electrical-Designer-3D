plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.elharika.electricaldesigner3d"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.elharika.electricaldesigner3d"
        minSdk = 29
        targetSdk = 35
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        versionCode = 209
        versionName = "2.0.0-rc3"
    }

    val keyPath = System.getenv("ELHARIKA_KEYSTORE")
    if (!keyPath.isNullOrBlank()) {
        signingConfigs {
            create("release") {
                storeFile = file(keyPath)
                storePassword = System.getenv("ELHARIKA_STORE_PASSWORD")
                keyAlias = System.getenv("ELHARIKA_KEY_ALIAS") ?: "elharika"
                keyPassword = System.getenv("ELHARIKA_KEY_PASSWORD") ?: System.getenv("ELHARIKA_STORE_PASSWORD")
            }
        }
        buildTypes.getByName("release").signingConfig = signingConfigs.getByName("release")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    testOptions { unitTests.isIncludeAndroidResources = true }
    buildFeatures { compose = true }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    // Real 3D engine: SceneView 2.3.0 (Filament 1.56) matches the existing Kotlin 2.0.x toolchain.
    implementation("io.github.sceneview:sceneview:2.3.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
}

// Forward explicitly configured JVM network settings to Robolectric's SDK resolver.
tasks.withType<Test>().configureEach {
    systemProperty("robolectric.dependency.repo.url", "https://repo.maven.apache.org/maven2")
    listOf("https.proxyHost", "https.proxyPort", "http.proxyHost", "http.proxyPort",
        "javax.net.ssl.trustStore", "javax.net.ssl.trustStorePassword").forEach { key ->
        System.getProperty(key)?.let { systemProperty(key, it) }
    }
}
